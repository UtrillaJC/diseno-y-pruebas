package utilities;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class TestStoredProcedure {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory;
		EntityManager entitymanager;

		entityManagerFactory = Persistence.createEntityManagerFactory("Acme-Pad-Thai");
		entitymanager = entityManagerFactory.createEntityManager();
		Query query = entitymanager.createNativeQuery("call stats()");
		List<Object> result = (List<Object>) query.getResultList();
		String newLine = System.lineSeparator();

		for (Object object : result) {
			Object obje[] = new Object[10];
			obje = (Object[]) object;
			System.out.println(newLine);
			System.out.println("### USER_ID: " + obje[0] + " ###");
			System.out.println("Number of recipes authored: "+obje[1]);
			System.out.println("Average of recipe likes: "+obje[2]);
			System.out.println("Standard deviation of recipe likes: "+obje[3]);
			System.out.println("Average of recipe dislikes: "+obje[4]);
			System.out.println("Standard deviation of recipe dislikes: "+obje[5]);
			System.out.println("Average of recipe steps: "+obje[6]);
			System.out.println("Standard deviation of recipe steps: "+obje[7]);
			System.out.println("Average of recipe ingredients: "+obje[8]);
			System.out.println("Standard deviation of recipe ingredients: "+obje[9]);
			System.out.println("Top 3 ingredients: "+obje[10]);
		}
		entitymanager.close();
		entityManagerFactory.close();
	}

}
