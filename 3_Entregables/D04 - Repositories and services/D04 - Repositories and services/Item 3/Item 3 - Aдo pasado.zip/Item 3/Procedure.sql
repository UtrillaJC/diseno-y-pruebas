DROP PROCEDURE `acme-pad-thai`.`stats`;

DELIMITER $$
CREATE PROCEDURE `acme-pad-thai`.`stats` ()
BEGIN
SELECT user_id,
COUNT(*) AS num_recipes,
AVG(avg_tastelikes) AS avg_of_likes,
AVG(stddev_tastelikes) AS std_of_likes,
AVG(avg_tastedislikes) AS avg_of_dislikes,
AVG(stddev_tastedislikes) AS std_of_dislikes,
AVG(recipes.num_steps) AS avg_steps_per_recipe,
STDDEV(recipes.num_steps) AS std_steps_per_recipe,
AVG(recipes.num_ingredients) AS avg_ingredients_per_recipe,
STDDEV(recipes.num_ingredients) AS std_ingredients_per_recipe,
concat(ingredients.name) AS top_3_ingredients
FROM
	(SELECT user_id,
		recipe.id,
		AVG(case tasteLike when true then 1 else 0 end) AS avg_tastelikes,
		STDDEV(case tasteLike when true then 1 else 0 end) AS stddev_tastelikes,
		AVG(case tasteLike when true then 0 else 1 end) AS avg_tastedislikes,
		STDDEV(case tasteLike when true then 0 else 1 end) AS stddev_tastedislikes,
		COUNT(DISTINCT step.id) AS num_steps,
		COUNT(DISTINCT ingredientquantity_recipe.ingredientQuantity_id) AS num_ingredients
	FROM recipe
		LEFT JOIN customertaste ON recipe.id = customertaste.recipe_id
		LEFT JOIN step ON recipe.id = step.recipe_id
		LEFT JOIN ingredientquantity_recipe ON recipe.id = ingredientquantity_recipe.recipes_id
	GROUP BY recipe.id) AS recipes
	LEFT JOIN
	(SELECT user_id AS userid, name, count(recipes_id) AS num_recipes
	FROM `ingredient`
		INNER JOIN ingredientquantity ON ingredient.id = ingredientquantity.ingredient_id
		INNER JOIN ingredientquantity_recipe ON ingredientquantity.id = ingredientQuantity_id
		INNER JOIN recipe ON recipes_id = recipe.id
	GROUP BY userid
	ORDER BY num_recipes
	LIMIT 3) AS ingredients ON recipes.user_id = ingredients.userid
GROUP BY user_id;
END$$
DELIMITER ;

CALL stats();