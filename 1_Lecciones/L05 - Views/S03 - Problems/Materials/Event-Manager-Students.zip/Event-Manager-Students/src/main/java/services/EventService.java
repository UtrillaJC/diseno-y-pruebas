/*
 * EventService.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package services;

import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.EventRepository;
import domain.Customer;
import domain.Event;
import domain.Organiser;

@Service
@Transactional
public class EventService {

	// Managed repository -------------------------------------------------

	@Autowired
	private EventRepository		eventRepository;

	// Supporting services ------------------------------------------------

	@Autowired
	private CustomerService		customerService;
	@Autowired
	private OrganiserService	organiserService;


	// Constructors -------------------------------------------------------

	public EventService() {
		super();
	}

	// Simple CRUD methods ------------------------------------------------

	public Event create() {
		Event result;
		Organiser organiser;
		Date moment;

		organiser = this.organiserService.findByPrincipal();
		moment = new Date();

		result = new Event();
		result.setTitle("New event");
		result.setMoment(moment);
		result.setDescription("");
		result.setPrice(0.00);
		result.setOrganiser(organiser);

		return result;
	}

	public Collection<Event> findAll() {
		Collection<Event> result;

		result = this.eventRepository.findAll();

		return result;
	}

	public Event findOne(final int eventId) {
		Event result;

		result = this.eventRepository.findOne(eventId);

		return result;
	}

	public void save(final Event event) {
		assert event != null;

		this.checkPrincipal(event);
		this.eventRepository.save(event);
	}

	public void delete(final Event event) {
		assert event != null;

		this.checkPrincipal(event);
		Assert.isTrue(event.getCustomers().isEmpty());
		this.eventRepository.delete(event.getId());
	}

	// Other business methods ---------------------------------------------

	public Event findOneToEdit(final int id) {
		Event result;

		result = this.eventRepository.findOne(id);
		this.checkPrincipal(result);

		return result;
	}

	public Collection<Event> findRegistered() {
		Collection<Event> result;
		Customer customer;

		customer = this.customerService.findByPrincipal();
		result = this.eventRepository.findByCustomerId(customer.getId());

		return result;
	}

	public Collection<Event> findNotRegistered() {
		Collection<Event> result;
		Customer customer;

		customer = this.customerService.findByPrincipal();
		result = this.eventRepository.findByNotCustomerId(customer.getId());

		return result;
	}

	public Collection<Event> findOrganised() {
		Collection<Event> result;
		Organiser organiser;

		organiser = this.organiserService.findByPrincipal();
		result = this.eventRepository.findByOrganiserId(organiser.getId());

		return result;
	}

	public void register(final int eventId) {
		Customer customer;
		Collection<Customer> customers;
		Event event;
		Collection<Event> events;
		Date currentMoment;

		customer = this.customerService.findByPrincipal();
		events = customer.getEvents();
		event = this.eventRepository.findOne(eventId);
		customers = event.getCustomers();

		Assert.isTrue(!events.contains(event));
		currentMoment = new Date();
		Assert.isTrue(currentMoment.before(event.getMoment()));

		events.add(event);
		customers.add(customer);
		// Not necessary: customerService.save(customer);
		this.eventRepository.save(event);
	}

	public void unregister(final int eventId) {
		Customer customer;
		Collection<Customer> customers;
		Event event;
		Collection<Event> events;
		Date currentMoment;

		customer = this.customerService.findByPrincipal();
		events = customer.getEvents();
		event = this.eventRepository.findOne(eventId);
		customers = event.getCustomers();

		Assert.isTrue(events.contains(event));
		currentMoment = new Date();
		Assert.isTrue(currentMoment.before(event.getMoment()));

		events.remove(event);
		customers.remove(customer);
		// Not necessary: customerService.save(customer);	
		this.eventRepository.save(event);
	}

	protected void checkPrincipal(final Event event) {
		assert event != null;

		Organiser organiser;

		organiser = this.organiserService.findByPrincipal();
		Assert.isTrue(event.getOrganiser().equals(organiser));
	}

}
