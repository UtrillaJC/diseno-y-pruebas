/* BulletinService.java
 *
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the 
 * TDG Licence, a copy of which you may download from 
 * http://www.tdg-seville.info/License.html
 * 
 */

package services;

import java.util.Collection;

import domain.Bulletin;

// TODO: this file provides an incomplete template; complete it with the appropriate annotations and method implementations.
// TODO: do not forget to add appropriate sectioning comments, e.g., "Managed repository", "Constructors", "Simple CRUD methods", and "Other business methods". 

public class BulletinService {

	public Bulletin create() {
		// TODO Auto-generated method stub
		return null;
	}

	public Collection<Bulletin> findAllOrderByMomentDescending() {
		// TODO Auto-generated method stub
		return null;
	}

	public Bulletin findOne(int bulletinId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Bulletin save(Bulletin bulletin) {
		// TODO Auto-generated method stub
		return null;
	}

	public void delete(Bulletin bulletin) {
		// TODO Auto-generated method stub
	}

}
