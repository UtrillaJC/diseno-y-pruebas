/* CustomerService.java
 *
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the 
 * TDG Licence, a copy of which you may download from 
 * http://www.tdg-seville.info/License.html
 * 
 */

package services;

import domain.Customer;

// TODO: this file provides an incomplete template; complete it with the appropriate annotations and method implementations.
// TODO: do not forget to add appropriate sectioning comments, e.g., "Managed repository", "Constructors", "Simple CRUD methods", and "Other business methods".

public class CustomerService {

	public Customer findByPrincipal() {
		// TODO Auto-generated method stub
		return null;
	}

}
