/* CustomerServiceTest.java
 *
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the 
 * TDG Licence, a copy of which you may download from 
 * http://www.tdg-seville.info/License.html
 * 
 */

package services;

import utilities.AbstractTest;

// TODO: this file provides an incomplete template; complete it with the appropriate annotations 
// TODO: and method implementations.  Do not forget to add appropriate sectioning comments, e.g., 
// TODO: "System under test" and "Tests".

public class CustomerServiceTest extends AbstractTest {

	public void testFindByPrincipal() {
		// TODO Auto-generated method stub
	}

}
