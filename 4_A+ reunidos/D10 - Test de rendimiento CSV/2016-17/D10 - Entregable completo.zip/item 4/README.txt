- Todas las pruebas funcionales se encuentran en la carpeta src/test/java/services.
- Nuestras pruebas funcionales, son dependientes de los ids de la Base de datos. Por tanto, lo comentamos con el profesor y nos dijo que los notificaramos
ya que si por alg�n casual, al realizar un Test funcional no sale en verde, puede deberse a que interactuando con nuestro Sistema de Informaci�n Web, al crear
una entidad nueva los ids hayan efectuado cambios en el resto de Ids de la base de datos. Por ello, rogamos que si as� sucediera se populara de nuevo la base de datos.

