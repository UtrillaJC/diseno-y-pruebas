
package services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Administrator;
import domain.Brand;
import domain.Cache;
import domain.Chirp;
import domain.Chorbi;
import domain.CreditCard;
import domain.LikeStore;
import domain.SearchTemplate;
import forms.CreditCardForm;
import forms.RegisterForm;
import repositories.ChorbiRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;

@Service
@Transactional
public class ChorbiService {

	//Managed Repository =============================================================================

	@Autowired
	private ChorbiRepository		chorbiRepository;

	//Supported Services =============================================================================

	@Autowired
	private SearchTemplateService	searchTemplateService;

	@Autowired
	private AdministratorService	administratorService;

	@Autowired
	private CacheService			cacheService;


	//Constructor methods ============================================================================

	public ChorbiService() {
		super();
	}

	//Simple CRUD methods ============================================================================

	public Chorbi findOne(final int chorbiId) {
		Chorbi result;

		result = this.chorbiRepository.findOne(chorbiId);

		return result;
	}

	public Collection<Chorbi> findAll() {
		Collection<Chorbi> result;

		result = this.chorbiRepository.findAll();

		return result;
	}

	public Chorbi create() {
		Chorbi result;
		UserAccount userAccount;
		Authority authority;

		Collection<Chirp> sentChirps;
		Collection<Chirp> receivedChirps;
		Collection<LikeStore> likerStore;
		Collection<LikeStore> likedStore;
		SearchTemplate searchTemplate;
		SearchTemplate searchTemplateSaved;
		CreditCard creditCard;

		authority = new Authority();
		userAccount = new UserAccount();

		sentChirps = new ArrayList<Chirp>();
		receivedChirps = new ArrayList<Chirp>();
		likerStore = new ArrayList<LikeStore>();
		likedStore = new ArrayList<LikeStore>();
		creditCard = new CreditCard();

		authority.setAuthority("CHORBI");
		userAccount.addAuthority(authority);

		searchTemplate = this.searchTemplateService.create();
		searchTemplateSaved = this.searchTemplateService.save(searchTemplate);
		creditCard.setBrandName(Arrays.asList(Brand.values()).get(0));
		creditCard.setNumber("0");
		creditCard.setHolderName("");

		result = new Chorbi();

		result.setUserAccount(userAccount);
		result.setSentChirps(sentChirps);
		result.setReceivedChirps(receivedChirps);
		result.setLikerStore(likerStore);
		result.setLikedStore(likedStore);
		result.setSearchTemplate(searchTemplateSaved);
		result.setBanned(false);
		result.setCreditCard(creditCard);

		return result;
	}

	@SuppressWarnings("deprecation")
	public Chorbi save(final Chorbi chorbi) {
		Assert.notNull(chorbi);
		Chorbi result;
		Date moment;
		int year;

		moment = new Date(System.currentTimeMillis() - 1000);
		year = moment.getYear() - 18;
		moment.setYear(year);

		Assert.isTrue(moment.after(chorbi.getBirthDate()));

		String password = chorbi.getUserAccount().getPassword();
		final Md5PasswordEncoder encoder = new Md5PasswordEncoder();
		password = encoder.encodePassword(password, null);
		chorbi.getUserAccount().setPassword(password);

		result = this.chorbiRepository.saveAndFlush(chorbi);

		return result;
	}

	//Other Business Methods =========================================================================

	public Chorbi findByPrincipal() {
		Chorbi result;
		UserAccount userAccount;

		userAccount = LoginService.getPrincipal();
		Assert.notNull(userAccount);
		result = this.findByUserAccount(userAccount);
		Assert.notNull(result);

		return result;
	}

	public Chorbi findByUserAccount(final UserAccount userAccount) {
		Chorbi result;

		result = this.chorbiRepository.findByUserAccountId(userAccount.getId());

		return result;
	}

	public void checkPrincipal() {
		final UserAccount userAccount = LoginService.getPrincipal();
		Assert.notNull(userAccount);

		final Collection<Authority> authorities = userAccount.getAuthorities();
		Assert.notNull(authorities);

		final Authority auth = new Authority();
		auth.setAuthority("CHORBI");

		Assert.isTrue(authorities.contains(auth));

	}

	public Chorbi reconstruct(final RegisterForm form) {
		Chorbi chorbi;

		chorbi = this.create();

		chorbi.getUserAccount().setUsername(form.getUsername());
		chorbi.getUserAccount().setPassword(form.getPassword());
		chorbi.getUserAccount().setEnabled(true);
		chorbi.setName(form.getName());
		chorbi.setSurname(form.getSurname());
		chorbi.setEmail(form.getEmail());
		chorbi.setPhone(form.getPhone());
		chorbi.setPicture(form.getPicture());
		chorbi.setBirthDate(form.getBirthDate());
		chorbi.setDescription(form.getDescription());
		chorbi.setCoordinates(form.getCoordinates());
		chorbi.setRelationship(form.getRelationship());
		chorbi.setGenre(form.getGenre());

		return chorbi;

	}

	public Collection<Chorbi> findLikesByLiked(final Chorbi c) {
		Assert.notNull(c);
		Collection<Chorbi> result;

		result = this.chorbiRepository.findLikesByLikedId(c.getId());

		return result;
	}

	public void banChorbi(final int chorbiId) {
		Administrator principal;
		final Chorbi chorbi = this.findOne(chorbiId);

		principal = this.administratorService.findByPrincipal();
		Assert.isInstanceOf(Administrator.class, principal);

		chorbi.setBanned(true);

		Assert.notNull(this.administratorService.findByPrincipal());
		Assert.notNull(chorbi);
		final UserAccount userAccount = chorbi.getUserAccount();
		userAccount.setEnabled(false);
		chorbi.setUserAccount(userAccount);
		this.chorbiRepository.saveAndFlush(chorbi);
	}

	public void unbanChorbi(final int chorbiId) {
		Administrator principal;
		final Chorbi chorbi = this.findOne(chorbiId);

		principal = this.administratorService.findByPrincipal();
		Assert.isInstanceOf(Administrator.class, principal);

		chorbi.setBanned(false);

		Assert.notNull(this.administratorService.findByPrincipal());
		Assert.notNull(chorbi);
		final UserAccount userAccount = chorbi.getUserAccount();
		userAccount.setEnabled(true);
		chorbi.setUserAccount(userAccount);
		this.chorbiRepository.saveAndFlush(chorbi);

		this.chorbiRepository.saveAndFlush(chorbi);
	}

	public Chorbi update(final Chorbi chorbi) {
		Assert.notNull(chorbi);
		Chorbi result;
		Chorbi principal;

		principal = this.findByPrincipal();
		//Assert.isTrue(principal.equals(chorbi));
		result = this.chorbiRepository.saveAndFlush(chorbi);

		return result;

	}

	public Chorbi updateCreditCard(final CreditCardForm form) {
		Assert.notNull(form);
		Chorbi principal;
		Chorbi result;
		int actualMonth, actualYear;
		principal = this.findByPrincipal();

		principal.getCreditCard().setBrandName(form.getBrandName());
		principal.getCreditCard().setcvvCode(form.getcvvCode());
		principal.getCreditCard().setExpirationMonth(form.getExpirationMonth());
		principal.getCreditCard().setExpirationYear(form.getExpirationYear());
		principal.getCreditCard().setHolderName(form.getHolderName());
		principal.getCreditCard().setNumber(form.getNumber());

		actualMonth = DateTime.now().getMonthOfYear();
		actualYear = DateTime.now().getYear();

		Assert.isTrue(principal.getCreditCard().getExpirationYear() > actualYear || ((principal.getCreditCard().getExpirationYear() == actualYear) && (principal.getCreditCard().getExpirationMonth() >= actualMonth)));

		result = this.chorbiRepository.saveAndFlush(principal);

		return result;
	}

	public void validCreditCard() {
		Chorbi principal;
		int actualMonth, actualYear;
		principal = this.findByPrincipal();
		actualMonth = DateTime.now().getMonthOfYear();
		actualYear = DateTime.now().getYear();
		Assert.isTrue(principal.getCreditCard().getNumber() != "0");
		Assert.isTrue(principal.getCreditCard().getExpirationYear() > actualYear || ((principal.getCreditCard().getExpirationYear() == actualYear) && (principal.getCreditCard().getExpirationMonth() >= actualMonth)));

	}

	public Collection<Chorbi> findAllBySearchTemplate(final SearchTemplate searchTemplate) {
		Assert.notNull(searchTemplate);
		Collection<Chorbi> result;
		Chorbi principal;
		Date momentActual;
		Date lastSearch;
		Cache cache;
		Double cacheMinutes;

		principal = this.findByPrincipal();
		Assert.isTrue(searchTemplate.equals(principal.getSearchTemplate()));
		momentActual = new Date(System.currentTimeMillis() - 1000);
		lastSearch = searchTemplate.getLastSearch();

		result = searchTemplate.getChorbies();

		long minutes;
		long miliseconds;

		cache = this.cacheService.findCache();
		cacheMinutes = (double) (cache.getHours() * 60 + cache.getMinutes() + cache.getSeconds() / 60 - 1);

		if (lastSearch == null)
			minutes = 0;
		else {
			miliseconds = ChorbiService.getDateDiff(lastSearch, momentActual, TimeUnit.MILLISECONDS);
			minutes = miliseconds / 60000;
		}

		System.out.println(minutes);
		System.out.println(cacheMinutes);
		if (minutes > cacheMinutes)
			searchTemplate.getChorbies().removeAll(result);
		this.searchTemplateService.save(searchTemplate);

		return result;
	}

	@SuppressWarnings("deprecation")
	public Collection<Chorbi> search(final SearchTemplate searchTemplate) {
		Assert.notNull(searchTemplate);
		this.validCreditCard();

		Collection<Chorbi> result;
		Collection<Chorbi> rangeAges;
		Collection<Chorbi> coordinates;
		Collection<Chorbi> genre;
		Collection<Chorbi> relationship;
		Collection<Chorbi> keyword;
		Chorbi principal;
		Date momentActual;
		Date lastSearch;
		Cache cache;
		Double cacheMinutes;

		rangeAges = new ArrayList<Chorbi>();
		coordinates = new ArrayList<Chorbi>();
		relationship = new ArrayList<Chorbi>();
		keyword = new ArrayList<Chorbi>();

		cache = this.cacheService.findCache();
		cacheMinutes = (double) (cache.getHours() * 60 + cache.getMinutes() + cache.getSeconds() / 60 - 1);

		principal = this.findByPrincipal();
		Assert.isTrue(searchTemplate.equals(principal.getSearchTemplate()));
		momentActual = new Date(System.currentTimeMillis() - 1000);
		lastSearch = searchTemplate.getLastSearch();

		long minutes;
		long miliseconds;

		if (lastSearch == null)
			minutes = (long) (cacheMinutes + 1);
		else {
			miliseconds = ChorbiService.getDateDiff(lastSearch, momentActual, TimeUnit.MILLISECONDS);
			minutes = miliseconds / 60000;
		}

		if (minutes > cacheMinutes) {

			if (searchTemplate.getApproximateAge() != null) {
				final Date searchMin = new Date(System.currentTimeMillis() - 1000);
				final Date searchMax = new Date(System.currentTimeMillis() - 1000);
				searchMin.setYear(momentActual.getYear() - searchTemplate.getApproximateAge());
				searchMax.setYear(momentActual.getYear() - searchTemplate.getApproximateAge());

				final Date minAge = searchMin;
				final Date maxAge = searchMax;

				minAge.setYear(searchMin.getYear() - 5);

				maxAge.setYear(searchMax.getYear() + 5);
				rangeAges = this.chorbiRepository.chorbiByAge(minAge, maxAge);
			} else
				rangeAges = this.chorbiRepository.findAll();

			if (searchTemplate.getCoordinates() != null) {
				Collection<Chorbi> country;
				final Collection<Chorbi> city;
				final Collection<Chorbi> state;
				final Collection<Chorbi> province;
				if (!searchTemplate.getCoordinates().getCountry().equals(""))
					country = this.chorbiRepository.chorbiByCoordinatesCountry(searchTemplate.getCoordinates().getCountry());
				else
					country = this.chorbiRepository.findAll();

				if (!searchTemplate.getCoordinates().getCity().equals(""))
					city = this.chorbiRepository.chorbiByCoordinatesCity(searchTemplate.getCoordinates().getCity());
				else
					city = this.chorbiRepository.findAll();

				if (!searchTemplate.getCoordinates().getState().equals(""))
					state = this.chorbiRepository.chorbiByCoordinatesState(searchTemplate.getCoordinates().getState());
				else
					state = this.chorbiRepository.findAll();

				if (!searchTemplate.getCoordinates().getProvince().equals(""))
					province = this.chorbiRepository.chorbiByCoordinatesProvince(searchTemplate.getCoordinates().getProvince());
				else
					province = this.chorbiRepository.findAll();

				country.retainAll(city);
				state.retainAll(country);
				province.retainAll(state);

				coordinates = province;
			} else
				coordinates = this.chorbiRepository.findAll();

			if (searchTemplate.getGenre() != null)
				genre = this.chorbiRepository.chorbiByGenre(searchTemplate.getGenre());
			else
				genre = this.chorbiRepository.findAll();

			if (searchTemplate.getRelationship() != null)
				relationship = this.chorbiRepository.chorbiByRelationship(searchTemplate.getRelationship());
			else
				relationship = this.chorbiRepository.findAll();

			if (searchTemplate.getKeyword() != null && !searchTemplate.getKeyword().equals(""))
				keyword = this.chorbiRepository.getChorbiByDescription(searchTemplate.getKeyword());
			else
				keyword = this.chorbiRepository.findAll();

			rangeAges.retainAll(coordinates);
			genre.retainAll(rangeAges);
			relationship.retainAll(genre);
			keyword.retainAll(relationship);

			result = keyword;

		} else if (searchTemplate.getLastSearch() != null)
			result = searchTemplate.getChorbies();
		else
			result = this.findAll();
		searchTemplate.setLastSearch(momentActual);
		searchTemplate.setChorbies(result);
		this.searchTemplateService.saveSearch(searchTemplate);

		return result;
	}

	public static long getDateDiff(final Date date1, final Date date2, final TimeUnit timeUnit) {
		final long diffInMillies = date2.getTime() - date1.getTime();
		return timeUnit.convert(diffInMillies, TimeUnit.MILLISECONDS);
	}

	public Collection<String> countChorbiByCountry() {
		this.administratorService.checkPrincipal();

		final Collection<String> result = new ArrayList<String>();
		final List<String> countries = this.chorbiRepository.countries();
		final List<Integer> numbers = this.chorbiRepository.countChorbiByCountry();
		int i = 0;

		for (final String country : countries) {

			final String s = country + " / " + numbers.get(i);
			result.add(s);
			i++;
		}

		return result;
	}

	public Collection<String> countChorbiByCity() {
		this.administratorService.checkPrincipal();

		final Collection<String> result = new ArrayList<String>();
		final List<String> cities = this.chorbiRepository.cities();
		final List<Integer> numbers = this.chorbiRepository.countChorbiByCity();
		int i = 0;

		for (final String city : cities) {

			final String s = city + " / " + numbers.get(i);
			result.add(s);
			i++;
		}

		return result;
	}

	public Integer minAges() {
		this.administratorService.checkPrincipal();
		return this.chorbiRepository.minAges();
	}

	public Integer maxAges() {
		this.administratorService.checkPrincipal();
		return this.chorbiRepository.maxAges();
	}

	public Double avgAges() {
		Double result;
		this.administratorService.checkPrincipal();
		result = this.chorbiRepository.avgAges();
		if (result == null)
			result = 0.0;
		return result;
	}

	public Double ratioCreditCardNoValid() {
		Double result;
		this.administratorService.checkPrincipal();
		result = this.chorbiRepository.ratioCreditCardNoValid();
		return result;
	}

	public Double ratioActivities() {
		Double result;
		this.administratorService.checkPrincipal();
		result = this.chorbiRepository.ratioActivities();
		if (result == null)
			result = 0.0;
		return result;
	}

	public Double ratioFriendship() {
		Double result;
		this.administratorService.checkPrincipal();
		result = this.chorbiRepository.ratioFriendship();
		if (result == null)
			result = 0.0;
		return result;
	}

	public Double ratioLove() {
		Double result;
		this.administratorService.checkPrincipal();
		result = this.chorbiRepository.ratioLove();
		if (result == null)
			result = 0.0;
		return result;
	}

	public Integer minLikes() {
		this.administratorService.checkPrincipal();
		return this.chorbiRepository.minLike();
	}

	public Integer maxLikes() {
		this.administratorService.checkPrincipal();
		return this.chorbiRepository.maxLike();
	}

	public Double avgLikes() {
		Double result;
		this.administratorService.checkPrincipal();
		result = this.chorbiRepository.avgLike();
		if (result == null)
			result = 0.0;
		return result;
	}

	public Collection<Chorbi> chorbiOrdermoreLike() {
		this.administratorService.checkPrincipal();
		return this.chorbiRepository.chorbiOrdermoreLike();
	}

	public Integer minChirpReceiver() {
		this.administratorService.checkPrincipal();
		return this.chorbiRepository.minChirpReceiver();
	}

	public Integer maxChirpReceiver() {
		this.administratorService.checkPrincipal();
		return this.chorbiRepository.maxChirpReceiver();
	}

	public Double avgChirpReceiver() {
		Double result;
		this.administratorService.checkPrincipal();
		result = this.chorbiRepository.avgChirpReceiver();
		if (result == null)
			result = 0.0;
		return result;
	}

	public Integer minChirpSent() {
		this.administratorService.checkPrincipal();
		return this.chorbiRepository.minChirpSent();
	}

	public Integer maxChirpSent() {
		this.administratorService.checkPrincipal();
		return this.chorbiRepository.maxChirpSent();
	}

	public Double avgChirpSent() {
		Double result;
		this.administratorService.checkPrincipal();
		result = this.chorbiRepository.avgChirpSent();
		if (result == null)
			result = 0.0;
		return result;
	}

	public Collection<Chorbi> chorbiMoreChirpReceiver() {
		this.administratorService.checkPrincipal();
		return this.chorbiRepository.chorbiMoreChirpReceiver();
	}

	public Collection<Chorbi> chorbiMoreChirpSent() {
		this.administratorService.checkPrincipal();
		return this.chorbiRepository.chorbiMoreChirpSent();
	}
}
