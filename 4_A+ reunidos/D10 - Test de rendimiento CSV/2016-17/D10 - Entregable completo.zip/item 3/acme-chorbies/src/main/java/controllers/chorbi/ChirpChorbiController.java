
package controllers.chorbi;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ChirpService;
import services.ChorbiService;
import controllers.AbstractController;
import domain.Chirp;
import domain.Chorbi;

@Controller
@RequestMapping("/chirp/chorbi")
public class ChirpChorbiController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private ChirpService	chirpService;

	@Autowired
	private ChorbiService	chorbiService;


	// Constructors ========================================================================

	public ChirpChorbiController() {
		super();
	}

	//Show chirp ============================================================

	@RequestMapping(value = "/showChirp", method = RequestMethod.GET)
	public ModelAndView showChirp(@RequestParam final int chirpId) {
		ModelAndView result;
		Chirp row;

		row = this.chirpService.findOne(chirpId);

		result = new ModelAndView("chirp/chorbi/showChirp");

		final String subject = row.getSubject();
		final String d1 = subject.replaceAll("([+]\\d+\\s)?(\\d){6,}", "***");
		row.setSubject(d1.replaceAll("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,6}", "***"));

		final String text = row.getText();
		final String d2 = text.replaceAll("([+]\\d+\\s)?(\\d){6,}", "***");
		row.setText(d2.replaceAll("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,6}", "***"));

		result.addObject("row", row);

		return result;
	}

	//List my sendChirps ========================================================================================

	@RequestMapping(value = "/listSentChirps", method = RequestMethod.GET)
	public ModelAndView listSendChirps() {
		ModelAndView result;
		Collection<Chirp> chirps;
		boolean ownerReply;
		boolean ownerResend;

		ownerReply = false;
		ownerResend = true;
		chirps = this.chirpService.findSentChirpsByChorbi();

		result = new ModelAndView("chirp/chorbi/list");

		for (final Chirp c : chirps) {
			final String subject = c.getSubject();
			final String d1 = subject.replaceAll("([+]\\d+\\s)?(\\d){6,}", "***");
			c.setSubject(d1.replaceAll("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,6}", "***"));
		}

		result.addObject("chirps", chirps);
		result.addObject("requestURI", "chirp/chorbi/listSentChirps.do");
		result.addObject("ownerReply", ownerReply);
		result.addObject("ownerResend", ownerResend);

		return result;
	}

	@RequestMapping(value = "/listReceivedChirps", method = RequestMethod.GET)
	public ModelAndView listReceivedChirps() {
		ModelAndView result;
		Collection<Chirp> chirps;
		boolean ownerReply;
		boolean ownerResend;

		ownerReply = true;
		ownerResend = false;
		chirps = this.chirpService.findReceivedChirpsByChorbi();

		result = new ModelAndView("chirp/chorbi/list");

		for (final Chirp c : chirps) {
			final String subject = c.getSubject();
			final String d1 = subject.replaceAll("([+]\\d+\\s)?(\\d){6,}", "***");
			c.setSubject(d1.replaceAll("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,6}", "***"));
		}

		result.addObject("chirps", chirps);
		result.addObject("requestURI", "chirp/chorbi/listReceivedChirps.do");
		result.addObject("ownerReply", ownerReply);
		result.addObject("ownerResend", ownerResend);

		return result;
	}

	//Create ===========================================================================================

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		Chirp chirpSender;
		Chorbi sender;
		Collection<Chorbi> chorbies;

		sender = this.chorbiService.findByPrincipal();
		chirpSender = this.chirpService.create();
		chorbies = this.chorbiService.findAll();
		chorbies.remove(sender);

		result = new ModelAndView("chirp/chorbi/edit");

		result.addObject("chirpSender", chirpSender);
		result.addObject("chorbies", chorbies);

		return result;
	}

	//Reply ===========================================================================================

	@RequestMapping(value = "/reply", method = RequestMethod.GET)
	public ModelAndView reply(@RequestParam final int chirpId) {
		ModelAndView result;
		Chirp chirpSender;

		chirpSender = this.chirpService.createReply(chirpId);

		result = new ModelAndView("chirp/chorbi/editReply");

		result.addObject("chirpSender", chirpSender);

		return result;
	}

	//Resend ===========================================================================================

	@RequestMapping(value = "/resend", method = RequestMethod.GET)
	public ModelAndView forward(@RequestParam final int chirpId) {
		ModelAndView result;
		Chirp chirpSender;
		Chorbi sender;
		Collection<Chorbi> chorbies;

		sender = this.chorbiService.findByPrincipal();
		chirpSender = this.chirpService.createResend(chirpId);
		chorbies = this.chorbiService.findAll();
		chorbies.remove(sender);

		result = new ModelAndView("chirp/chorbi/edit");
		result.addObject("chirpSender", chirpSender);
		result.addObject("chorbies", chorbies);

		return result;
	}

	//Save ===========================================================================================

	@RequestMapping(value = "/create", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@ModelAttribute("chirpSender") @Valid final Chirp chirpSender, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(chirpSender);
		else
			try {
				chirpSender.setCopy(false);
				this.chirpService.save(chirpSender);
				chirpSender.setCopy(true);
				this.chirpService.save(chirpSender);

				result = new ModelAndView("redirect:listSentChirps.do");

			} catch (final Throwable oops) {
				result = this.createEditModelAndView(chirpSender, "chirpSender.commit.error");
			}
		return result;

	}

	//Delete ===========================================================================================

	@RequestMapping(value = "/create", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(@ModelAttribute final Chirp row, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(row);
		else
			try {
				this.chirpService.delete(row);

				result = new ModelAndView("redirect:listSentChirps.do");

			} catch (final Throwable oops) {
				result = this.createEditModelAndView(row, "chirpSender.commit.error");
			}
		return result;

	}

	// Ancillary methods: Create ===========================================================================================

	protected ModelAndView createEditModelAndView(final Chirp chirpSender) {
		ModelAndView result;
		result = this.createEditModelAndView(chirpSender, null);
		return result;

	}

	protected ModelAndView createEditModelAndView(final Chirp chirpSender, final String chirp) {
		ModelAndView result;
		Collection<Chorbi> chorbies;
		Chorbi sender;

		sender = this.chorbiService.findByPrincipal();
		chorbies = this.chorbiService.findAll();
		chorbies.remove(sender);

		result = new ModelAndView("chirp/chorbi/edit");

		result.addObject("chorbies", chorbies);
		result.addObject("chirpSender", chirpSender);
		result.addObject("chirp", chirp);

		return result;
	}

}
