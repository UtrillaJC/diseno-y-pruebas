
package domain;

import java.util.Collection;
import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.Valid;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Access(AccessType.PROPERTY)
@Table(indexes = {
	@Index(columnList = "relationship")
})
public class SearchTemplate extends DomainEntity {

	//Attributes ====================================================================================

	private Relationship	relationship;
	private Integer			approximateAge;
	private Genre			genre;
	private Coordinates		coordinates;
	private String			keyword;
	private Date			lastSearch;


	//Constructor ====================================================================================

	public SearchTemplate() {
		super();
	}

	//Getters & setters================================================================================

	public Relationship getRelationship() {
		return this.relationship;
	}

	public void setRelationship(final Relationship relationship) {
		this.relationship = relationship;
	}

	@Range(min = 18, max = 110)
	public Integer getApproximateAge() {
		return this.approximateAge;
	}

	public void setApproximateAge(final Integer approximateAge) {
		this.approximateAge = approximateAge;
	}

	public Genre getGenre() {
		return this.genre;
	}

	public void setGenre(final Genre genre) {
		this.genre = genre;
	}

	public Coordinates getCoordinates() {
		return this.coordinates;
	}

	public void setCoordinates(final Coordinates coordinates) {
		this.coordinates = coordinates;
	}

	public String getKeyword() {
		return this.keyword;
	}

	public void setKeyword(final String keyword) {
		this.keyword = keyword;
	}

	@Past
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	public Date getLastSearch() {
		return this.lastSearch;
	}

	public void setLastSearch(final Date lastSearch) {
		this.lastSearch = lastSearch;
	}


	// Relationships ====================================================================================

	private Collection<Chorbi>	chorbies;


	@Valid
	@ManyToMany
	public Collection<Chorbi> getChorbies() {
		return this.chorbies;
	}

	public void setChorbies(final Collection<Chorbi> chorbies) {
		this.chorbies = chorbies;
	}

}
