
package controllers.actor;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ActorService;
import services.ChorbiService;
import controllers.AbstractController;
import domain.Actor;
import domain.Chorbi;

@Controller
@RequestMapping("/chorbi/actor")
public class ChorbiActorController extends AbstractController {

	// Services -------------------------------------------------------------------

	@Autowired
	private ChorbiService	chorbiService;

	@Autowired
	private ActorService	actorService;


	// Constructors ---------------------------------------------------------------

	public ChorbiActorController() {
		super();
	}

	// CRUD methods -----------------------------------------------------------

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Chorbi> chorbies;

		chorbies = this.chorbiService.findAll();

		result = new ModelAndView("chorbi/actor/list");
		final Actor a = this.actorService.findByPrincipal();
		if (a instanceof Chorbi)
			result.addObject("principal", this.chorbiService.findByPrincipal());
		for (final Chorbi c : chorbies) {
			c.setEmail("***");
			c.setPhone("***");
			final String description = c.getDescription();
			final String d1 = description.replaceAll("([+]\\d+\\s)?(\\d){6,}", "***");
			c.setDescription(d1.replaceAll("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,6}", "***"));
		}

		result.addObject("chorbies", chorbies);
		result.addObject("requestURI", "chorbi/actor/list.do");

		return result;

	}

	// List of Chorbies who like it-----------------------------------------------------------
	@RequestMapping(value = "/listWhoLikeIt", method = RequestMethod.GET)
	public ModelAndView listWhoLikeMe(@RequestParam final int chorbiId) {
		ModelAndView result;
		Collection<Chorbi> chorbies;
		Chorbi chorbi;

		chorbi = this.chorbiService.findOne(chorbiId);
		chorbies = this.chorbiService.findLikesByLiked(chorbi);

		result = new ModelAndView("chorbi/actor/list");
		Actor a = actorService.findByPrincipal();
		if(a instanceof Chorbi){
		result.addObject("principal",chorbiService.findByPrincipal());
		}
		for (final Chorbi c : chorbies) {
			c.setEmail("***");
			c.setPhone("***");
			final String description = c.getDescription();
			final String d1 = description.replaceAll("([+]\\d+\\s)?(\\d){6,}", "***");
			c.setDescription(d1.replaceAll("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,6}", "***"));
		}

		result.addObject("chorbies", chorbies);
		result.addObject("requestURI", "chorbi/actor/listWhoLikeIt.do");

		return result;

	}

}
