/*
 * QueryDatabase.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package utilities;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.apache.commons.lang.RandomStringUtils;

import domain.Genre;
import domain.Relationship;

public class CSVGenerator {

	public static void main(final String[] args) throws Throwable {
		
		 FileWriter fichero = null;
	     PrintWriter pw = null;
	     List<Relationship> rel = new ArrayList<Relationship>();
	     rel.add(Relationship.friendship);
	     rel.add(Relationship.activities);
	     rel.add(Relationship.love);
	     List<Genre> gen = new ArrayList<Genre>();
	     gen.add(Genre.man);
	     gen.add(Genre.woman);
	     try
	     {
	         fichero = new FileWriter("../prueba.csv");
	         pw = new PrintWriter(fichero);

	         for (int i = 10; i < 210; i++){
	        	 	        	 
	        	 pw.print("user" + i+",");
	        	 pw.print("password" + i+",");
	             pw.print("password" + i+",");
	             pw.print("Name" + i+","); 
	             pw.print("Surname" + i+",");         
	             pw.print("email" + i+"@email.com,");
	             pw.print(RandomStringUtils.randomNumeric(9)+",");
	             pw.print("http://www.imagen.com.mx/assets/img/imagen_share.png" +",");
	             pw.print("Description" + i+",");
	             pw.print(rel.get((int) (Math.random() * 3))+",");
	             pw.print(gen.get((int) (Math.random() * 2))+",");
	             pw.print(randomDate()+",");
	             pw.print("Country"+",");
	             pw.print("State"+",");
	             pw.print("Province"+",");
	             pw.print("City"+",");
	             
	             pw.println("true");
	         }
	     	
	      
	    	
	         		

	     } catch (Exception e) {
	         e.printStackTrace();
	     } finally {
	        try {
	        // Nuevamente aprovechamos el finally para 
	        // asegurarnos que se cierra el fichero.
	        if (null != fichero)
	           fichero.close();
	        } catch (Exception e2) {
	           e2.printStackTrace();
	        }
	     }
	     
	}
	
	  public static String randomDate(){
		  
		  Random r = new Random();
		  int dia =  r.nextInt((31 - 1) + 1) + 1;
		  int mes =  r.nextInt((12 - 1) + 1) + 1;
		  int ano =  r.nextInt((1999 - 1940) + 1) + 1940;
		  return dia+"/"+mes+"/"+ano;
	 	}
	
	
	
	
}
