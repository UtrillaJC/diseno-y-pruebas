
package domain;

import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Access(AccessType.PROPERTY)
public class LikeStore extends DomainEntity {
	
	//Attributes ====================================================================================

	private Date		moment;
	private String		comment;
	
	
	//Constructor ====================================================================================

	public LikeStore() {
		super();
	}


	//Getters & setters================================================================================

	
	@NotNull
	@Past
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getMoment() {
		return moment;
	}


	public void setMoment(Date moment) {
		this.moment = moment;
	}


	public String getComment() {
		return comment;
	}


	public void setComment(String comment) {
		this.comment = comment;
	}


	// Relationships ====================================================================================

	private Chorbi	liker;
	private Chorbi	liked;


	
	@Valid
	@ManyToOne(optional=false)
	public Chorbi getLiker() {
		return liker;
	}


	public void setLiker(Chorbi liker) {
		this.liker = liker;
	}


	@Valid
	@ManyToOne(optional=false)
	public Chorbi getLiked() {
		return liked;
	}


	public void setLiked(Chorbi liked) {
		this.liked = liked;
	}
	
	
	
	

	
	

}
