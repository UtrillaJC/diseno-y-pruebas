
package controllers.chorbi;

import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import controllers.AbstractController;
import domain.Brand;
import domain.Chorbi;
import forms.CreditCardForm;
import services.ChorbiService;

@Controller
@RequestMapping("/chorbi")
public class ChorbiChorbiController extends AbstractController {

	// Services -------------------------------------------------------------------

	@Autowired
	private ChorbiService chorbiService;


	// Constructors ---------------------------------------------------------------

	public ChorbiChorbiController() {
		super();
	}

	// CRUD methods -----------------------------------------------------------
	@RequestMapping(value = "/addCreditCard", method = RequestMethod.GET)
	public ModelAndView addCreditCard() {

		ModelAndView result;
		final CreditCardForm form = new CreditCardForm();
		final Chorbi chorbi = this.chorbiService.findByPrincipal();

		form.setBrandName(chorbi.getCreditCard().getBrandName());
		form.setHolderName(chorbi.getCreditCard().getHolderName());
		form.setNumber(chorbi.getCreditCard().getNumber());
		form.setExpirationMonth(chorbi.getCreditCard().getExpirationMonth());
		form.setExpirationYear(chorbi.getCreditCard().getExpirationYear());
		form.setcvvCode(chorbi.getCreditCard().getcvvCode());

		result = this.createEditModelAndView(form);

		return result;

	}

	@RequestMapping(value = "/addCreditCard", method = RequestMethod.POST, params = "addCreditCard")
	public ModelAndView save(@ModelAttribute("form") @Valid final CreditCardForm form, final BindingResult binding) {

		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(form);
		else
			try {
				this.chorbiService.updateCreditCard(form);
				result = new ModelAndView("redirect:../welcome/index.do");

			} catch (final Throwable oops) {
				result = this.createEditModelAndView(form, "edit.commit.error");
			}
		return result;

	}
	protected ModelAndView createEditModelAndView(final CreditCardForm creditCardForm) {

		ModelAndView result;

		result = this.createEditModelAndView(creditCardForm, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final CreditCardForm creditCardForm, final String message) {

		ModelAndView result;

		final List<Brand> brand = Arrays.asList(Brand.values());

		result = new ModelAndView("chorbi/addCreditCard");
		result.addObject("form", creditCardForm);
		result.addObject("message", message);
		result.addObject("brand", brand);

		return result;
	}
	
	

	

}
