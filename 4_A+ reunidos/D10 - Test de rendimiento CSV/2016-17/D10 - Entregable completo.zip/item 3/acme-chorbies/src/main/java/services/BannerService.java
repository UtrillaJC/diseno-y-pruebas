
package services;

import java.util.Collection;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.BannerRepository;
import domain.Administrator;
import domain.Banner;

@Service
@Transactional
public class BannerService {

	//Managed Repository =============================================================================

	@Autowired
	private BannerRepository		bannerRepository;

	//Supported Services =============================================================================

	@Autowired
	private AdministratorService	administratorService;


	//Constructor methods ============================================================================

	public BannerService() {
		super();
	}

	//Simple CRUD methods ============================================================================

	public Collection<Banner> findAll() {
		Collection<Banner> result;

		result = this.bannerRepository.findAll();

		return result;
	}

	public Banner findOne(final int bannerId) {
		Banner result;

		result = this.bannerRepository.findOne(bannerId);

		return result;
	}

	public Banner save(final Banner banner) {
		Assert.notNull(banner);
		Banner result;
		Administrator principal;

		principal = this.administratorService.findByPrincipal();
		Assert.isInstanceOf(Administrator.class, principal);
		Assert.notNull(principal);

		result = this.bannerRepository.saveAndFlush(banner);

		return result;

	}

	//Other Business Methods =========================================================================

	public Banner selectBanner() {
		Banner result = null;
		final List<Banner> banners = (List<Banner>) this.findAll();
		final Random randomizer = new Random();
		if (!banners.isEmpty())
			result = banners.get(randomizer.nextInt(banners.size()));
		return result;
	}

}
