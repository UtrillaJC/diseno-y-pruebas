package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.CacheRepository;
import domain.Administrator;
import domain.Cache;

@Service
@Transactional
public class CacheService {
	
	@Autowired
	private CacheRepository cacheRepository;

	
	//Supported Services ============================================================================

	@Autowired
	public ChorbiService chorbiService;

	@Autowired
	public AdministratorService administratorService;

	//Constructor methods ============================================================================

	public CacheService(){
		super();
	}

	// Simple CRUD methods ============================================================================

	public Cache findOne(int cacheId){
		Cache result;
		
		result = cacheRepository.findOne(cacheId);
		
		return result;
	}
	
	
	public Cache findOneToEdit(int cacheId){
		Cache result;
		Administrator principal;
		
		principal = administratorService.findByPrincipal();
		Assert.isInstanceOf(Administrator.class, principal);
		result = findOne(cacheId);
		Assert.notNull(result);
		
		return result;
	}

	
	public Cache findCache() {
		Cache result;
	    Collection<Cache> caches;

	    caches = this.findAll();
	    result = new Cache();

	    for (Cache c : caches)
	      result = findOne(c.getId());

	    return result;
	  }
	
	public Collection<Cache> findAll() {
		Collection<Cache> result;

		result = cacheRepository.findAll();
	    	
	    return result;
	  }
	
	
	public Cache save(Cache cache){
		Cache result;
		Administrator principal;
		
		principal = administratorService.findByPrincipal();
		result = cacheRepository.saveAndFlush(cache);
		Assert.isInstanceOf(Administrator.class, principal);
		
		return result;
	}
	
	
	
	
}
