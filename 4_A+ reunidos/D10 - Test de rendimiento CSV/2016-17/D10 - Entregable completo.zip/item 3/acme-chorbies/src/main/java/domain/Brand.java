
package domain;

public enum Brand {

	VISA, MASTERCARD, DISCOVER, DINNERS, AMEX
}
