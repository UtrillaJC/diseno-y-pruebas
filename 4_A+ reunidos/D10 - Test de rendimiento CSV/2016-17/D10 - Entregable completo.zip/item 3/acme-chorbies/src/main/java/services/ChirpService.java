package services;


import java.util.Date;

import java.util.Collection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.ChirpRepository;
import domain.Actor;
import domain.Chirp;
import domain.Chorbi;

@Service
@Transactional
public class ChirpService {

	//Managed Repository =============================================================================

	@Autowired
	public ChirpRepository chirpRepository;
	
	//Supported Services ============================================================================

	@Autowired
	public ChorbiService chorbiService;

	@Autowired
	public AdministratorService administratorService;

	//Constructor methods ============================================================================

	public ChirpService(){
		super();
	}

	// Simple CRUD methods ============================================================================

	public Chirp findOne(int chirpId){
		Chirp result;
		
		result = chirpRepository.findOne(chirpId);
		
		return result;
	}
	
	public Chirp create(){
		Chirp result;
		Chorbi principal;
		Date momentActual;
		
		principal = chorbiService.findByPrincipal();
		momentActual = new Date(System.currentTimeMillis());
		result = new Chirp();
		
		result.setMoment(momentActual);
		result.setSender(principal);
		
		return result;
	}
	
	public Chirp save(Chirp chirp){
		Chirp result;
		Date momentActual;
		
		momentActual = new Date(System.currentTimeMillis() - 1000);
		chirp.setMoment(momentActual);
		
		result = chirpRepository.saveAndFlush(chirp);
		
		return result;
	}
	
	public void delete(Chirp chirp){
		Assert.notNull(chirp);
		Actor principal;
			
		principal = chorbiService.findByPrincipal();
			
		Assert.isTrue(principal.equals(chirp.getSender()) || principal.equals(chirp.getRecipient()));
			
		chirpRepository.delete(chirp);

	}
	
	
	
	// Other business methods ============================================================================
	
	public Chirp createReply(int chirpId){
		Chirp result;
		Chirp chirp;
		Chorbi principal;
		Date momentActual;
		
		principal = chorbiService.findByPrincipal();
		chirp = findOne(chirpId);
		Assert.isTrue(chirp.getRecipient().equals(principal));
		momentActual = new Date(System.currentTimeMillis());
		
		result = new Chirp();
		
		result.setMoment(momentActual);
		result.setSender(principal);
		result.setRecipient(chirp.getSender());
		
		return result;
	}
	
	public Chirp createResend(int chirpId){
		Chirp result;
		Chirp chirp;
		Chorbi principal;
		Date momentActual;
		
		principal = chorbiService.findByPrincipal();
		chirp = findOne(chirpId);
		Assert.isTrue(chirp.getSender().equals(principal));
		momentActual = new Date(System.currentTimeMillis());
		
		result = new Chirp();
		
		result.setMoment(momentActual);
		result.setSender(principal);
		result.setSubject(chirp.getSubject());
		result.setText(chirp.getText());
		result.setAttachments(chirp.getAttachments());
		
		return result;
	}
	
	
	public Collection<Chirp> findSentChirpsByChorbi(){
		Collection<Chirp> result;
		Chorbi principal;
		
		principal = chorbiService.findByPrincipal();
		result = chirpRepository.findSentChirpsByChorbi(principal.getId());
		
		return result;
	}
	
	public Collection<Chirp> findReceivedChirpsByChorbi(){
		Collection<Chirp> result;
		Chorbi principal;
		
		principal = chorbiService.findByPrincipal();
		result = chirpRepository.findReceivedChirpsByChorbi(principal.getId());
		
		return result;
	}
	
}