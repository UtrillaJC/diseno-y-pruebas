
package forms;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.CreditCardNumber;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.Range;

import domain.Brand;

public class CreditCardForm {

	//Attributes-------------------------------------------------------------------------
	private String	holderName;
	private Brand	brandName;
	private String	number;
	private int		expirationMonth;
	private int		expirationYear;
	private int		cvvCode;


	@NotBlank
	public String getHolderName() {
		return this.holderName;
	}
	public void setHolderName(final String holderName) {
		this.holderName = holderName;
	}

	@NotNull
	public Brand getBrandName() {
		return this.brandName;
	}
	public void setBrandName(final Brand brandName) {
		this.brandName = brandName;
	}

	@NotBlank
	@CreditCardNumber
	public String getNumber() {
		return this.number;
	}
	public void setNumber(final String number) {
		this.number = number;
	}

	@Range(min = 1, max = 12)
	public int getExpirationMonth() {
		return this.expirationMonth;
	}
	public void setExpirationMonth(final int expirationMonth) {
		this.expirationMonth = expirationMonth;
	}

	@Range(min = 2017, max = 2100)
	public int getExpirationYear() {
		return this.expirationYear;
	}
	public void setExpirationYear(final int expirationYear) {
		this.expirationYear = expirationYear;
	}

	@Range(min = 100, max = 999)
	public int getcvvCode() {
		return this.cvvCode;
	}
	public void setcvvCode(final int cvvCode) {
		this.cvvCode = cvvCode;
	}

}
