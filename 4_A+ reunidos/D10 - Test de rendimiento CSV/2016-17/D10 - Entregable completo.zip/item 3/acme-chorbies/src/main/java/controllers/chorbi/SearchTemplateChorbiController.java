
package controllers.chorbi;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import controllers.AbstractController;
import domain.Chorbi;
import domain.SearchTemplate;
import services.ChorbiService;
import services.SearchTemplateService;

@Controller
@RequestMapping("/searchTemplate/chorbi")
public class SearchTemplateChorbiController extends AbstractController {

	// Services -------------------------------------------------------------------

	@Autowired
	private SearchTemplateService	searchTemplateService;

	@Autowired
	private ChorbiService			chorbiService;


	// Constructors ---------------------------------------------------------------

	public SearchTemplateChorbiController() {
		super();
	}

	// Listing methods -----------------------------------------------------------

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display() {

		ModelAndView result;
		SearchTemplate searchTemplate;
		Collection<Chorbi> chorbies;

		searchTemplate = this.searchTemplateService.findByPrincipal();
		chorbies = this.chorbiService.findAllBySearchTemplate(searchTemplate);

		result = new ModelAndView("searchTemplate/chorbi/display");
		result.addObject("searchTemplate", searchTemplate);
		result.addObject("chorbies", chorbies);
		result.addObject("requestURI", "searchTemplate/chorbi/display.do");

		return result;
	}

	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ModelAndView search() {

		ModelAndView result;
		SearchTemplate searchTemplate;
		searchTemplate = this.searchTemplateService.findByPrincipal();
		try {

			this.chorbiService.search(searchTemplate);
			result = new ModelAndView("searchTemplate/chorbi/display");
			result.addObject("searchTemplate", searchTemplate);
			result.addObject("chorbies", searchTemplate.getChorbies());
			result.addObject("requestURI", "searchTemplate/chorbi/search.do");
		} catch (final Throwable oops) {
			result = this.notCreditCardModelAndView(searchTemplate, "search.commit.error");
		}

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit() {
		ModelAndView result;
		SearchTemplate searchTemplate;

		searchTemplate = this.searchTemplateService.findByPrincipal();
		Assert.notNull(searchTemplate);

		result = this.createEditModelAndView(searchTemplate);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@ModelAttribute @Valid final SearchTemplate searchTemplate, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(searchTemplate);
		else
			try {
				this.searchTemplateService.saveEdit(searchTemplate);
				result = new ModelAndView("redirect:display.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(searchTemplate, "searchTemplate.commit.error");
			}
		return result;
	}

	// Ancillary Methods============================================================

	protected ModelAndView createEditModelAndView(final SearchTemplate searchTemplate) {
		ModelAndView result;

		result = this.createEditModelAndView(searchTemplate, null);

		return result;

	}

	protected ModelAndView createEditModelAndView(final SearchTemplate searchTemplate, final String message) {
		ModelAndView result;

		result = new ModelAndView("searchTemplate/chorbi/edit");
		result.addObject("searchTemplate", searchTemplate);
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView notCreditCardModelAndView(final SearchTemplate searchTemplate) {
		ModelAndView result;

		result = this.notCreditCardModelAndView(searchTemplate, null);

		return result;

	}

	protected ModelAndView notCreditCardModelAndView(final SearchTemplate searchTemplate, final String message) {
		ModelAndView result;

		result = new ModelAndView("searchTemplate/chorbi/display");
		result.addObject("searchTemplate", searchTemplate);
		result.addObject("message", message);

		return result;
	}
}
