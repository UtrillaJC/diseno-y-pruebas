
package services;

import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.LikeStoreRepository;
import domain.Chorbi;
import domain.LikeStore;

@Service
@Transactional
public class LikeStoreService {

	//Managed Repository =============================================================================

	@Autowired
	private LikeStoreRepository	likeStoreRepository;

	//Supported Services =============================================================================

	@Autowired
	private ChorbiService		chorbiService;


	//Constructor methods ============================================================================

	public LikeStoreService() {
		super();
	}

	//Simple CRUD methods ============================================================================

	public LikeStore findOne(final int likeStoreId) {
		LikeStore result;

		result = this.likeStoreRepository.findOne(likeStoreId);

		return result;
	}

	public Collection<LikeStore> findAll() {
		Collection<LikeStore> result;

		result = this.likeStoreRepository.findAll();

		return result;
	}

	public LikeStore create(final int id, final String comment) {
		final Chorbi principal = this.chorbiService.findByPrincipal();
		final Chorbi liked = this.chorbiService.findOne(id);
		Assert.notNull(principal);
		Assert.notNull(liked);
		Assert.isTrue(principal.getId() != liked.getId());
		Assert.isNull(this.likeStoreRepository.findByLikerAndLiked(liked.getId(), principal.getId()));
		LikeStore like = new LikeStore();
		like.setLiker(principal);
		like.setLiked(liked);
		like.setComment(comment);
		like.setMoment(new Date(System.currentTimeMillis() - 1000));
		like = this.save(like);
		return like;
	}

	public LikeStore save(final LikeStore likeStore) {
		Assert.notNull(likeStore);
		LikeStore result;
		final Chorbi c = likeStore.getLiker();
		result = this.likeStoreRepository.saveAndFlush(likeStore);
		final Collection<LikeStore> likes = c.getLikerStore();
		likes.add(result);
		c.setLikerStore(likes);
		this.chorbiService.update(c);

		return result;
	}

	public void removeLike(final int id) {
		final Chorbi principal = this.chorbiService.findByPrincipal();
		Assert.notNull(principal);
		final LikeStore like = this.likeStoreRepository.findByLikerAndLiked(id, principal.getId());
		Assert.notNull(like);
		Collection<LikeStore> likes = like.getLiker().getLikerStore();
		likes.remove(like);
		like.getLiker().setLikerStore(likes);
		this.chorbiService.update(like.getLiker());
		likes = like.getLiked().getLikedStore();
		likes.remove(like);
		like.getLiked().setLikedStore(likes);
		this.chorbiService.update(like.getLiked());
		this.likeStoreRepository.delete(like.getId());

	}

	//Other Business Methods =========================================================================

	public Collection<LikeStore> findLikesByLikedId(final int likedId) {
		Collection<LikeStore> result;
		final Chorbi liked = this.chorbiService.findOne(likedId);
		result = liked.getLikedStore();
		return result;
	}

}
