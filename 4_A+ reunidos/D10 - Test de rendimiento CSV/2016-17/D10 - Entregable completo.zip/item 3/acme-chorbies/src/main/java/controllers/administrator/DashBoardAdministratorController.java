
package controllers.administrator;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import domain.Chorbi;
import services.ChorbiService;

@Controller
@RequestMapping("/dashboard/administrator")
public class DashBoardAdministratorController {

	@Autowired
	ChorbiService chorbiService;


	public DashBoardAdministratorController() {
		super();
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView dashboard() {

		ModelAndView result;

		result = new ModelAndView("dashboard/list");
		Collection<String> dashb1;
		Collection<String> dashb2;
		Integer dashb3;
		Integer dashb4;
		Double dashb5;
		Double dashb6;
		Double dashb7;
		Double dashb8;
		Double dashb9;
		Collection<Chorbi> dashb10;
		Integer dashb11;
		Integer dashb12;
		Double dashb13;
		Integer dashb14;
		Integer dashb15;
		Double dashb16;
		Integer dashb17;
		Integer dashb18;
		Double dashb19;
		Collection<Chorbi> dashb20;
		Collection<Chorbi> dashb21;

		dashb1 = this.chorbiService.countChorbiByCountry();
		dashb2 = this.chorbiService.countChorbiByCity();
		dashb3 = this.chorbiService.minAges();
		dashb4 = this.chorbiService.maxAges();
		dashb5 = this.chorbiService.avgAges();
		dashb6 = this.chorbiService.ratioCreditCardNoValid();
		dashb7 = this.chorbiService.ratioActivities();
		dashb8 = this.chorbiService.ratioFriendship();
		dashb9 = this.chorbiService.ratioLove();
		dashb10 = this.chorbiService.chorbiOrdermoreLike();
		dashb11 = this.chorbiService.minLikes();
		dashb12 = this.chorbiService.maxLikes();
		dashb13 = this.chorbiService.avgLikes();
		dashb14 = this.chorbiService.minChirpReceiver();
		dashb15 = this.chorbiService.maxChirpReceiver();
		dashb16 = this.chorbiService.avgChirpReceiver();
		dashb17 = this.chorbiService.minChirpSent();
		dashb18 = this.chorbiService.maxChirpSent();
		dashb19 = this.chorbiService.avgChirpSent();
		dashb20 = this.chorbiService.chorbiMoreChirpReceiver();
		dashb21 = this.chorbiService.chorbiMoreChirpSent();

		result.addObject("requestURI", "dashboard/administrator/list.do");
		result.addObject("dashb1", dashb1);
		result.addObject("dashb2", dashb2);
		result.addObject("dashb3", dashb3);
		result.addObject("dashb4", dashb4);
		result.addObject("dashb5", dashb5);
		result.addObject("dashb6", dashb6);
		result.addObject("dashb7", dashb7);
		result.addObject("dashb8", dashb8);
		result.addObject("dashb9", dashb9);
		result.addObject("dashb10", dashb10);
		result.addObject("dashb11", dashb11);
		result.addObject("dashb12", dashb12);
		result.addObject("dashb13", dashb13);
		result.addObject("dashb14", dashb14);
		result.addObject("dashb15", dashb15);
		result.addObject("dashb16", dashb16);
		result.addObject("dashb17", dashb17);
		result.addObject("dashb18", dashb18);
		result.addObject("dashb19", dashb19);
		result.addObject("dashb20", dashb20);
		result.addObject("dashb21", dashb21);

		return result;
	}

}
