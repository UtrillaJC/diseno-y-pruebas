
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.LikeStore;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class LikeStoredServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private LikeStoreService likeStoreService;

	@Autowired
	private ChorbiService chorbiService;
		
	// Tests =======================================================================================


	//A chorbi may like another chorbi. The system must store the moment when 
	//he or she likes him or her and an optional comment.
	@Test
	public void driverLike() {
		final Object testingData[][] = {
			{
				"chorbi1", 56, "coment1",null
			//POSITIVO Usuario logueado como chorbi da like al chorbi con id 52
			}, {
				null, 53, "coment2", IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta dar like a un chorbi
			}, {
				"admin", 54,"comment3",  IllegalArgumentException.class
			//NEGATIVO Usuario logueado como admin intenta dar like a otro chorbi
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateLike((String) testingData[i][0], (int) testingData[i][1],(String) testingData[i][2], (Class<?>) testingData[i][3]);
	}

	public void templateLike(final String username, final int chorbiId,final String comment , final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			LikeStore like = this.likeStoreService.create(chorbiId, comment);
			Assert.isTrue(chorbiService.findOne(chorbiId).getLikedStore().contains(like));
			Assert.isTrue(chorbiService.findByPrincipal().getLikerStore().contains(like));
			this.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	
     	//A like may be cancelled at any time.
		@Test
		public void driverCancel() {
			final Object testingData[][] = {
				{"chorbi2","chorbi2", 56,null
				//POSITIVO Usuario logueado como chorbi cancela un like suyo
				}, {
					"chorbi2","chorbi4", 51, IllegalArgumentException.class
				//NEGATIVO Usuario logueado como chorbi cancela un like de otro
				}

			};

			for (int i = 0; i < testingData.length; i++)
				this.templateCancel((String) testingData[i][0], (String) testingData[i][1], (int) testingData[i][2], (Class<?>) testingData[i][3]);
		}

		public void templateCancel(final String username,final String username2, final int chorbiId, final Class<?> expected) {
			Class<?> caught;

			caught = null;

			try {
				this.authenticate(username);
				LikeStore like = this.likeStoreService.create(chorbiId, "comment");
				this.unauthenticate();
				this.authenticate(username2);
				Assert.isTrue(likeStoreService.findOne(like.getId())!=null);
				likeStoreService.removeLike(chorbiId);
				Assert.isNull(likeStoreService.findOne(like.getId()));
				this.unauthenticate();
			} catch (final Throwable oops) {
				caught = oops.getClass();
			}
			this.checkExceptions(expected, caught);
		}
		
		
	
	

}
