
package services;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;
import domain.Chorbi;
import domain.Coordinates;
import domain.Genre;
import domain.Relationship;
import domain.SearchTemplate;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class SearchTemplateServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private SearchTemplateService	searchTemplateService;

	@Autowired
	private ChorbiService			chorbiService;


	// Tests =======================================================================================

	//	An actor who is authenticated as a chorbi must be able to:
	//	Change his or her search template.
	@SuppressWarnings("unchecked")
	@Test
	public void driverSaveSearchTemplate() {
		final Coordinates coordinates = new Coordinates();
		final Coordinates coordinates2 = new Coordinates();
		coordinates.setCity("Camas");
		coordinates.setCountry("Espa�a");
		coordinates.setProvince("Sevilla");
		coordinates.setState("Andalucia");
		Collection<Chorbi> chorbies;
		chorbies = new HashSet<Chorbi>();
		final Date lastSearch = new Date(System.currentTimeMillis() - 1000);

		final Object testingData[][] = {
			{
				"chorbi1", Relationship.love, 31, Genre.man, coordinates, "keyword", chorbies, lastSearch, null
			//POSITIVO Usuario logueado como chorbi configura su searchTemplate
			}, {
				null, Relationship.love, 31, Genre.man, coordinates2, "keyword", chorbies, lastSearch, IllegalArgumentException.class
			//NEGATIVO1 Usuario no logueado intenta configurar searchTemplate
			}, {
				"admin", Relationship.love, 31, Genre.man, coordinates2, "keyword", chorbies, lastSearch, IllegalArgumentException.class
			//NEGATIVO2 Usuario no logueado intenta configurar searchTemplate
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.templateSaveSerachTemplate((String) testingData[i][0], (Relationship) testingData[i][1], (Integer) testingData[i][2], (Genre) testingData[i][3], (Coordinates) testingData[i][4], (String) testingData[i][5],
				(Collection<Chorbi>) testingData[i][6], (Date) testingData[i][7], (Class<?>) testingData[i][8]);
	}

	public void templateSaveSerachTemplate(final String username, final Relationship relationship, final Integer ageApproximate, final Genre genre, final Coordinates coordinates, final String keyword, final Collection<Chorbi> chorbies,
		final Date lastSearch, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final SearchTemplate searchTemplate = this.chorbiService.findByPrincipal().getSearchTemplate();
			searchTemplate.setRelationship(relationship);
			searchTemplate.setApproximateAge(ageApproximate);
			searchTemplate.setGenre(genre);
			searchTemplate.setCoordinates(coordinates);
			searchTemplate.setKeyword(keyword);
			searchTemplate.setChorbies(chorbies);
			searchTemplate.setLastSearch(lastSearch);
			this.searchTemplateService.saveEdit(searchTemplate);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	An actor who is authenticated as a chorbi must be able to:
	//	Browse the results of his or her search template as long as he or she's registered a valid credit card.
	@Test
	public void driverSearchSearchTemplate() {

		final Object testingData[][] = {
			{
				"chorbi1", null
			//POSITIVO Usuario logueado como chorbi busca en el sistema
			}, {
				null, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta buscar en el sistema
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.templateSearchSerachTemplate((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateSearchSerachTemplate(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final Chorbi chorbi = this.chorbiService.findByPrincipal();
			final SearchTemplate searchTemplate = chorbi.getSearchTemplate();
			this.chorbiService.search(searchTemplate);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
}
