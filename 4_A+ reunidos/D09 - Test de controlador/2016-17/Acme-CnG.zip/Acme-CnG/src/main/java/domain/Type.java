
package domain;

public enum Type {

	OFFER, REQUEST
}
