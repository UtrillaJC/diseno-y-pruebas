
package domain;

public enum Status {

	PENDING, ACCEPTED, DENIED
}
