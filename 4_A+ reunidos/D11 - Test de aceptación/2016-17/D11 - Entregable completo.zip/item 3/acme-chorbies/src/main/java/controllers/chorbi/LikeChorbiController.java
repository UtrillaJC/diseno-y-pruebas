
package controllers.chorbi;

import java.util.Calendar;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import controllers.AbstractController;
import domain.LikeStore;
import services.LikeStoreService;

@Controller
@RequestMapping("/like")
public class LikeChorbiController extends AbstractController {

	// Services -------------------------------------------------------------------

	@Autowired
	private LikeStoreService likeStoreService;

	
	// Constructors ---------------------------------------------------------------

	public LikeChorbiController() {
		super();
	}

	// CRUD methods -----------------------------------------------------------
	@RequestMapping(value = "/likeChorbi", method = RequestMethod.POST)
	public ModelAndView likeChorbi(@RequestParam int id, Integer rating, String comment) {
		if (rating == null){
			rating = 0;
		}
		ModelAndView result =  new ModelAndView("redirect:/chorbi/actor/list.do");
		try{
		likeStoreService.create(id,comment,rating);
		}catch (Exception e) {
			result.addObject("CreateError",true);
		}
		
		
		

		return result;

	}
	@RequestMapping(value = "/removeLikeChorbi", method = RequestMethod.GET)
	public ModelAndView removelikeChorbi(@RequestParam int id) {
		
		ModelAndView result =  new ModelAndView("redirect:/chorbi/actor/list.do");
		try{		
		likeStoreService.removeLike(id);
		}catch (Exception e) {
		result.addObject("DeleteError",true);
		}
		
		

		return result;

	}
	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@ModelAttribute("like") @Valid LikeStore like, BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors()) {
			result = createEditModelAndView(like);
		} else {
			try {
				like.setMoment(Calendar.getInstance().getTime());
				likeStoreService.save(like);

				result = new ModelAndView("redirect:listSentChirps.do");

			} catch (Throwable oops) {
				result = createEditModelAndView(like, "like.commit.error");
			}
		}
		return result;

	}
	

	protected ModelAndView createEditModelAndView(LikeStore likeStore) {

		ModelAndView result;

		result = this.createEditModelAndView(likeStore, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(LikeStore likeStore, final String message) {

		ModelAndView result;

		

		result = new ModelAndView("like");
		result.addObject("like",likeStore);
		result.addObject("message", message);
		

		return result;
	}
	
	

	

}
