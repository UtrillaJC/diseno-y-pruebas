
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.ChirpBroadcast;

@Repository
public interface ChirpBroadcastRepository extends JpaRepository<ChirpBroadcast, Integer> {

	@Query("select c from ChirpBroadcast c where c.recipient.id = ?1")
	Collection<ChirpBroadcast> chirpsByEventId(int eventId);	
	
	@Query("select c from ChirpBroadcast c where c.deleted = true")
	Collection<ChirpBroadcast> chirpDeleted();	
	
}
