
package controllers.manager;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import controllers.AbstractController;
import domain.Event;
import services.ChirpBroadcastService;
import services.EventService;

@Controller
@RequestMapping("/event/managers")
public class EventManagerController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private EventService	eventService;
	
	@Autowired
	private ChirpBroadcastService	chirpBroadcastService;


	// Constructors ========================================================================

	public EventManagerController() {
		super();
	}

	//List my events ========================================================================================

	@RequestMapping(value = "/myList", method = RequestMethod.GET)
	public ModelAndView listMyEvents() {
		ModelAndView result;
		List<Event> events;

		events = (List<Event>) this.eventService.findEventsByManager();

		Collections.sort(events, new Comparator<Event>() {

			@Override
			public int compare(final Event eventA, final Event eventB) {
				return (eventB.getSeats() - eventB.getChorbies().size()) - (eventA.getSeats() - eventA.getChorbies().size());
			}
		});

		result = new ModelAndView("event/managers/list");

		result.addObject("events", events);
		result.addObject("requestURI", "event/managers/myList.do");

		return result;
	}

	//Create ===========================================================================================

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		Event event;

		event = this.eventService.create();

		result = new ModelAndView("event/managers/edit");

		result.addObject("event", event);

		return result;
	}

	// Edition ---------------------------------------------------------------

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int eventId) {
		ModelAndView result;
		Event event;

		event = this.eventService.findOne(eventId);

		result = this.createEditModelAndView(event);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView edit(@Valid final Event event, final BindingResult binding) {
		ModelAndView result;


		if (binding.hasErrors())
			result = this.createEditModelAndView(event);
		else
			try {
				
				Event eventSaved = this.eventService.save(event);	
				chirpBroadcastService.sendEditBroadcastAutomatically(eventSaved.getId());


				
				result = new ModelAndView("redirect:myList.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(event, "event.commit.error");
			}

		return result;
	}

	// Deleting ---------------------------------------------------------------

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(@ModelAttribute final Event event, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(event);
		else
			try {
				chirpBroadcastService.sendDeleteBroadcastAutomatically(event.getId());
				
				this.eventService.delete(event);
				
				result = new ModelAndView("redirect:myList.do");

			} catch (final Throwable oops) {
				result = this.createEditModelAndView(event, "event.commit.error");
			}
		return result;
	}

	// Ancillary methods: Create ===========================================================================================

	protected ModelAndView createEditModelAndView(final Event event) {
		ModelAndView result;
		result = this.createEditModelAndView(event, null);
		return result;

	}

	protected ModelAndView createEditModelAndView(final Event event, final String message) {
		ModelAndView result;

		result = new ModelAndView("event/managers/edit");

		result.addObject("event", event);
		result.addObject("message", message);
		return result;
	}

}
