
package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.ChirpSender;

@Component
@Transactional
public class ChirpSenderToStringConverter implements Converter<ChirpSender, String> {

	@Override
	public String convert(final ChirpSender chirpSender) {
		String result;

		if (chirpSender == null)
			result = null;
		else
			result = String.valueOf(chirpSender.getId());

		return result;
	}
}
