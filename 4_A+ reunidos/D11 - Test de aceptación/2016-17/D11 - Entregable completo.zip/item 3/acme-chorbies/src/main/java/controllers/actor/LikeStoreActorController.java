
package controllers.actor;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.LikeStoreService;
import controllers.AbstractController;
import domain.LikeStore;

@Controller
@RequestMapping("/like/actor")
public class LikeStoreActorController extends AbstractController {

	// Services -------------------------------------------------------------------

	@Autowired
	private LikeStoreService	likeStoreService;


	// Constructors ---------------------------------------------------------------

	public LikeStoreActorController() {
		super();
	}

	// CRUD methods -----------------------------------------------------------

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam final int likedId) {
		ModelAndView result;
		Collection<LikeStore> likeStores;

		likeStores = this.likeStoreService.findLikesByLikedId(likedId);

		result = new ModelAndView("like/actor/list");

		for (final LikeStore l : likeStores) {
			final String comment = l.getComment();
			final String d1 = comment.replaceAll("([+]\\d+\\s)?(\\d){6,}", "***");
			l.setComment(d1.replaceAll("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,6}", "***"));
		}

		result.addObject("likeStores", likeStores);
		result.addObject("requestURI", "like/actor/list.do");

		return result;

	}

}
