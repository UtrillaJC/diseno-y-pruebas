
package controllers.manager;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import controllers.AbstractController;
import domain.ChirpBroadcast;
import services.ChirpBroadcastService;

@Controller
@RequestMapping("/chirpBroadcast/managers")
public class ChirpBroadcastManagerController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private ChirpBroadcastService	chirpBroadcastService;



	// Constructors ========================================================================

	public ChirpBroadcastManagerController() {
		super();
	}

	//Create broadcast===========================================================================================

	@RequestMapping(value = "/broadcast", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam final int eventId) {
		ModelAndView result;
		final ChirpBroadcast chirpBroadcast;

		chirpBroadcast = this.chirpBroadcastService.create(eventId);
		
		result = new ModelAndView("chirpBroadcast/managers/edit");
		result.addObject("chirpSender", chirpBroadcast);

		return result;
	}

	//Save ===========================================================================================

	@RequestMapping(value = "/broadcast", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@ModelAttribute("chirpSender") @Valid final ChirpBroadcast chirpSender, final BindingResult binding) {
		ModelAndView result;
		
		if (binding.hasErrors())
			result = this.createEditModelAndView(chirpSender);
		else
			try {
				this.chirpBroadcastService.save(chirpSender);
				result = new ModelAndView("redirect:/event/managers/myList.do");

			} catch (final Throwable oops) {
				result = this.createEditModelAndView(chirpSender, "chirpSender.commit.error");
			}
		return result;

	}

	// Ancillary methods: Create ===========================================================================================

	protected ModelAndView createEditModelAndView(final ChirpBroadcast chirpSender) {
		ModelAndView result;
		result = this.createEditModelAndView(chirpSender, null);
		return result;

	}

	protected ModelAndView createEditModelAndView(final ChirpBroadcast chirpSender, final String chirp) {
		ModelAndView result;

		result = new ModelAndView("chirpBroadcast/managers/edit");

		result.addObject("chirpSender", chirpSender);
		result.addObject("chirp", chirp);

		return result;
	}
}
