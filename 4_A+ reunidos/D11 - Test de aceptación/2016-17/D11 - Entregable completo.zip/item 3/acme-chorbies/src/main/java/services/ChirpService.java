
package services;

import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.ChirpRepository;
import domain.Actor;
import domain.Chirp;
import domain.ChirpSender;
import domain.Chorbi;
import domain.Event;

@Service
@Transactional
public class ChirpService {

	//Managed Repository =============================================================================

	@Autowired
	private ChirpRepository		chirpRepository;

	//Supported Services ============================================================================

	@Autowired
	private ChorbiService		chorbiService;

	@Autowired
	private ChirpSenderService	chirpSenderService;


	//Constructor methods ============================================================================

	public ChirpService() {
		super();
	}

	// Simple CRUD methods ============================================================================

	public Chirp findOne(final int chirpId) {
		Chirp result;

		result = this.chirpRepository.findOne(chirpId);

		return result;
	}

	public Chirp create() {
		Chirp result;
		ChirpSender principal;
		Date momentActual;

		principal = this.chirpSenderService.findByPrincipal();
		momentActual = new Date(System.currentTimeMillis());
		result = new Chirp();

		result.setMoment(momentActual);
		result.setSender(principal);

		return result;
	}

	public Chirp save(final Chirp chirp) {
		Chirp result;
		Date momentActual;

		momentActual = new Date(System.currentTimeMillis() - 1000);
		chirp.setMoment(momentActual);

		result = this.chirpRepository.saveAndFlush(chirp);

		return result;
	}

	public void delete(final Chirp chirp) {
		Assert.notNull(chirp);
		Actor principal;

		principal = this.chorbiService.findByPrincipal();

		Assert.isTrue(principal.equals(chirp.getSender()) || principal.equals(chirp.getRecipient()));

		this.chirpRepository.delete(chirp);

	}

	// Other business methods ============================================================================

	public Chirp createReply(final int chirpId) {
		Chirp result;
		Chirp chirp;
		Chorbi principal;
		Date momentActual;
		Chorbi recipient;

		principal = this.chorbiService.findByPrincipal();
		chirp = this.findOne(chirpId);
		Assert.isTrue(chirp.getRecipient().equals(principal));
		momentActual = new Date(System.currentTimeMillis());
		recipient = this.chorbiService.findOne(chirp.getSender().getId());
		Assert.isInstanceOf(Chorbi.class, recipient);

		result = new Chirp();

		result.setMoment(momentActual);
		result.setSender(principal);
		result.setRecipient((recipient));

		return result;
	}
	public Chirp createResend(final int chirpId) {
		Chirp result;
		Chirp chirp;
		Chorbi principal;
		Date momentActual;

		principal = this.chorbiService.findByPrincipal();
		chirp = this.findOne(chirpId);
		Assert.isTrue(chirp.getSender().equals(principal));
		momentActual = new Date(System.currentTimeMillis());

		result = new Chirp();

		result.setMoment(momentActual);
		result.setSender(principal);
		result.setSubject(chirp.getSubject());
		result.setText(chirp.getText());
		result.setAttachments(chirp.getAttachments());

		return result;
	}

	public Collection<Chirp> findSentChirpsByChorbi() {
		Collection<Chirp> result;
		Chorbi principal;

		principal = this.chorbiService.findByPrincipal();
		result = this.chirpRepository.findSentChirpsByChorbi(principal.getId());

		return result;
	}

	public Collection<Chirp> findReceivedChirpsByChorbi() {
		Collection<Chirp> result;
		Chorbi principal;

		principal = this.chorbiService.findByPrincipal();
		result = this.chirpRepository.findReceivedChirpsByChorbi(principal.getId());

		return result;
	}

	public Chirp saveBroadcast(final Chirp chirp, final Event event) {
		Chirp result;
		Date momentActual;
		final Collection<Chorbi> chorbies;

		momentActual = new Date(System.currentTimeMillis() - 1000);
		chirp.setMoment(momentActual);
		chorbies = event.getChorbies();

		result = new Chirp();

		for (final Chorbi c : chorbies) {
			chirp.setRecipient(c);
			result = this.chirpRepository.saveAndFlush(chirp);
		}

		return result;
	}
	
	
	

}
