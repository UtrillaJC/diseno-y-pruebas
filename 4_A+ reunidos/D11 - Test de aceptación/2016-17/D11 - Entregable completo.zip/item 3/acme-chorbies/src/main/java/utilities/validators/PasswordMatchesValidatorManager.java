
package utilities.validators;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import forms.RegisterFormManager;

public class PasswordMatchesValidatorManager implements ConstraintValidator<PasswordMatchesManager, RegisterFormManager> {

	@Override
	public void initialize(final PasswordMatchesManager constraintAnnotation) {
	}
	@Override
	public boolean isValid(final RegisterFormManager form, final ConstraintValidatorContext context) {
		return form.getPassword().equals(form.getVerifyPassword());
	}

}
