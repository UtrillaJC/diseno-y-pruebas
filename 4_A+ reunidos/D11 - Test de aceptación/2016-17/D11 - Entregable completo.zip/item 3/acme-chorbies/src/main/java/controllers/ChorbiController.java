/*
 * ChorbiController.java
 *
 * Copyright (C) 2017 Universidad de Sevilla
 *
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import domain.Brand;
import domain.Chorbi;
import domain.Genre;
import domain.Relationship;
import forms.RegisterForm;
import services.ChorbiService;

@Controller
@RequestMapping("/chorbi")
public class ChorbiController extends AbstractController {

	// Services -------------------------------------------------------------------

	@Autowired
	private ChorbiService chorbiService;


	// Constructors -----------------------------------------------------------

	public ChorbiController() {
		super();
	}

	// Listing methods -----------------------------------------------------------

	// Create methods --------------------------------------------------------------

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView create() {

		ModelAndView result;
		final RegisterForm form = new RegisterForm();
		result = this.createEditModelAndView(form);

		return result;

	}

	@RequestMapping(value = "/register", method = RequestMethod.POST, params = "register")
	public ModelAndView save(@ModelAttribute("form") @Valid final RegisterForm form, final BindingResult binding) {

		ModelAndView result;
		Chorbi chorbi;

		if (binding.hasErrors()) {

			if (binding.getGlobalError() != null)
				result = this.createEditModelAndView(form, binding.getGlobalError().getCode());
			else
				result = this.createEditModelAndView(form);
		} else
			try {
				chorbi = this.chorbiService.reconstruct(form);

				this.chorbiService.save(chorbi);

				result = new ModelAndView("redirect:/");

			} catch (final DataIntegrityViolationException exc) {
				result = this.createEditModelAndView(form, "register.duplicated.user");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(form, "register.commit.error");
			}

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit() {
		ModelAndView result;
		Chorbi principal;

		principal = this.chorbiService.findByPrincipal();
		result = this.editModelAndView(principal);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@ModelAttribute("chorbi") @Valid final Chorbi chorbi, final BindingResult binding) {

		ModelAndView result;

		if (binding.hasErrors())
			result = this.editModelAndView(chorbi);
		else
			try {
				this.chorbiService.update(chorbi);
				result = new ModelAndView("redirect:../welcome/index.do");

			} catch (final Throwable oops) {
				result = this.editModelAndView(chorbi, "edit.commit.error");
			}
		return result;

	}
	// Ancillary methods ---------------------------------------------------------

	protected ModelAndView createEditModelAndView(final RegisterForm registerForm) {

		ModelAndView result;

		result = this.createEditModelAndView(registerForm, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final RegisterForm registerForm, final String message) {

		ModelAndView result;

		final List<Relationship> relationship = Arrays.asList(Relationship.values());
		final List<Genre> genre = Arrays.asList(Genre.values());
		final List<Brand> brand = Arrays.asList(Brand.values());

		result = new ModelAndView("chorbi/register");
		result.addObject("form", registerForm);
		result.addObject("message", message);
		result.addObject("relationshipChorbi", relationship);
		result.addObject("genre", genre);
		result.addObject("brand", brand);

		return result;
	}

	protected ModelAndView editModelAndView(final Chorbi chorbi) {

		ModelAndView result;

		result = this.editModelAndView(chorbi, null);

		return result;
	}

	protected ModelAndView editModelAndView(final Chorbi chorbi, final String message) {

		ModelAndView result;
		result = new ModelAndView("chorbi/edit");
		result.addObject("chorbi", chorbi);
		result.addObject("message", message);
		return result;
	}
}
