
package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.ChirpBroadcast;

@Component
@Transactional
public class ChirpBroadcastToStringConverter implements Converter<ChirpBroadcast, String> {

	@Override
	public String convert(final ChirpBroadcast chirpBroadcast) {
		String result;

		if (chirpBroadcast == null)
			result = null;
		else
			result = String.valueOf(chirpBroadcast.getId());

		return result;
	}
}
