
package repositories;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Chorbi;
import domain.CreditCard;
import domain.Genre;
import domain.Relationship;

@Repository
public interface ChorbiRepository extends JpaRepository<Chorbi, Integer> {

	@Query("select c from Chorbi c where c.userAccount.id = ?1")
	Chorbi findByUserAccountId(int userAccountId);

	@Query("select l.liker from Chorbi c join c.likedStore l where c.id = ?1")
	Collection<Chorbi> findLikesByLikedId(int chorbiId);

	@Query("select distinct c.creditCard from Chorbi c where c.creditCard.number=?1")
	CreditCard findCreditCardByNumber(String s);
	
	
	@Query("select c from Chorbi c where ?1 member of c.events")
	Collection<Chorbi> findAllByEvent(int eventId);


	@Query("select count(c) from Chorbi c group by c.coordinates.country")
	List<Integer> countChorbiByCountry();

	@Query("select distinct c.coordinates.country from Chorbi c order by c.coordinates.country")
	List<String> countries();

	@Query("select count(c) from Chorbi c group by c.coordinates.city")
	List<Integer> countChorbiByCity();

	@Query("select distinct c.coordinates.city from Chorbi c order by c.coordinates.city")
	List<String> cities();

	@Query("select min((Year(CURRENT_TIMESTAMP) + Month(CURRENT_TIMESTAMP)/12 + Day(CURRENT_TIMESTAMP)/365) - ((Year(c.birthDate) + Month(c.birthDate)/12 + Day(c.birthDate)/365))) from Chorbi c")
	Integer minAges();

	@Query("select max((Year(CURRENT_TIMESTAMP) + Month(CURRENT_TIMESTAMP)/12 + Day(CURRENT_TIMESTAMP)/365) - ((Year(c.birthDate) + Month(c.birthDate)/12 + Day(c.birthDate)/365))) from Chorbi c")
	Integer maxAges();

	@Query("select avg((Year(CURRENT_TIMESTAMP) + Month(CURRENT_TIMESTAMP)/12 + Day(CURRENT_TIMESTAMP)/365) - ((Year(c.birthDate) + Month(c.birthDate)/12 + Day(c.birthDate)/365))) from Chorbi c")
	Double avgAges();

	@Query("select count(c)/((select count(c1) from Chorbi c1)*1.0) from Chorbi c where c.creditCard.expirationYear < Year(CURRENT_TIMESTAMP) or c.creditCard.expirationYear = Year(CURRENT_TIMESTAMP) and c.creditCard.expirationMonth < Month(CURRENT_TIMESTAMP) or c.creditCard.number = 0")
	Double ratioCreditCardNoValid();

	@Query("select count(c1)/(select count(c) from Chorbi c)*1.0 from Chorbi c1 where c1.searchTemplate.relationship = 0")
	Double ratioActivities();

	@Query("select count(c1)/(select count(c) from Chorbi c)*1.0 from Chorbi c1 where c1.searchTemplate.relationship = 1")
	Double ratioFriendship();

	@Query("select count(c1)/(select count(c) from Chorbi c)*1.0 from Chorbi c1 where c1.searchTemplate.relationship = 2")
	Double ratioLove();

	@Query("select c from Chorbi c order by c.likedStore.size desc")
	Collection<Chorbi> chorbiOrdermoreLike();

	@Query("select min(c.likedStore.size) from Chorbi c")
	Integer minLike();

	@Query("select max(c.likedStore.size) from Chorbi c")
	Integer maxLike();

	@Query("select min(c.likedStore.size) from Chorbi c")
	Double avgLike();

	@Query("select min(c.receivedChirps.size) from Chorbi c join c.receivedChirps ch where ch.copy = false")
	Integer minChirpReceiver();

	@Query("select max(c.receivedChirps.size) from Chorbi c join c.receivedChirps ch where ch.copy = false")
	Integer maxChirpReceiver();

	@Query("select avg(c.receivedChirps.size) from Chorbi c join c.receivedChirps ch where ch.copy = false")
	Double avgChirpReceiver();

	@Query("select min(c.sentChirps.size) from Chorbi c join c.sentChirps ch where ch.copy = false")
	Integer minChirpSent();

	@Query("select max(c.sentChirps.size) from Chorbi c join c.sentChirps ch where ch.copy = false")
	Integer maxChirpSent();

	@Query("select avg(c.sentChirps.size) from Chorbi c join c.sentChirps ch where ch.copy = false")
	Double avgChirpSent();

	@Query("select c from Chorbi c where c.receivedChirps.size = (select max(c1.receivedChirps.size) from Chorbi c1 join c1.receivedChirps ch where ch.copy = false)")
	Collection<Chorbi> chorbiMoreChirpReceiver();

	@Query("select c from Chorbi c where c.sentChirps.size = (select max(c1.sentChirps.size) from Chorbi c1 join c1.sentChirps ch where ch.copy = false)")
	Collection<Chorbi> chorbiMoreChirpSent();

	@Query("select c from Chorbi c where c.birthDate >= ?1 and c.birthDate <= ?2")
	Collection<Chorbi> chorbiByAge(Date minAge, Date maxAge);

	@Query("select c from Chorbi c where c.coordinates.country = ?1")
	Collection<Chorbi> chorbiByCoordinatesCountry(String country);

	@Query("select c from Chorbi c where c.coordinates.city = ?1")
	Collection<Chorbi> chorbiByCoordinatesCity(String city);

	@Query("select c from Chorbi c where c.coordinates.state = ?1")
	Collection<Chorbi> chorbiByCoordinatesState(String state);

	@Query("select c from Chorbi c where c.coordinates.province = ?1")
	Collection<Chorbi> chorbiByCoordinatesProvince(String city);

	@Query("select c from Chorbi c where c.genre = ?1")
	Collection<Chorbi> chorbiByGenre(Genre genre);

	@Query("select c from Chorbi c where c.description like %?1%")
	Collection<Chorbi> getChorbiByDescription(String keyword);

	@Query("select c from Chorbi c where c.relationship = ?1")
	Collection<Chorbi> chorbiByRelationship(Relationship relationship);
	
	@Query("select c from Chorbi c order by c.events.size desc")
	Collection<Chorbi> ChorbiOrdermoreEvents();

	@Query("select c.userAccount.username, c.amount from Chorbi c")
	Collection<Object[]> chorbiAmount();	
	
	@Query("select min(l.stars) from Chorbi c join c.likedStore l")
	Integer minStar();
	
	@Query("select max(l.stars) from Chorbi c join c.likedStore l")
	Integer maxStar();
	
	@Query("select avg(l.stars) from Chorbi c join c.likedStore l")
	Double avgStar();
	
	@Query("select distinct c from Chorbi c join c.likedStore l order by l.stars desc")
	Collection<Chorbi> chorbiesOrderStar();
	
	
	
	
}
