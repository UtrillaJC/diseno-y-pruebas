
package forms;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

import domain.CreditCard;
import utilities.validators.NotFalse;
import utilities.validators.PasswordMatchesManager;

@PasswordMatchesManager
public class RegisterFormManager {
	//Attributes=====================================================================================

	private String				username;
	private String				surname;
	private String				password;
	private String				verifyPassword;
	private String	name;
	private String	email;
	private String	phone;
	private String		nameCompany;
	private Integer		vatNumber;
	private CreditCard	creditCard;
	private Boolean				contractAccepted;

	//Getters & setters================================================================================
	@NotBlank
	@Size(min = 5, max = 32)
	public String getUsername() {
		return this.username;
	}

	public void setUsername(final String username) {
		this.username = username;
	}
	@NotBlank
	public String getNameCompany() {
		return this.nameCompany;
	}

	public void setNameCompany(final String nameCompany) {
		this.nameCompany = nameCompany;
	}

	@NotBlank
	@Size(min = 5, max = 32)
	public String getPassword() {
		return this.password;
	}

	public void setPassword(final String password) {
		this.password = password;
	}
	
	@NotBlank
	@Size(min = 5, max = 32)
	public String getVerifyPassword() {
		return this.verifyPassword;
	}

	public void setVerifyPassword(final String verifyPassword) {
		this.verifyPassword = verifyPassword;
	}
	public Integer getVatNumber() {
		return this.vatNumber;
	}

	public void setVatNumber(final Integer vatNumber) {
		this.vatNumber = vatNumber;
	}

	@Valid
	public CreditCard getCreditCard() {
		return this.creditCard;
	}

	public void setCreditCard(final CreditCard creditCard) {
		this.creditCard = creditCard;
	}
	@NotBlank
	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	@NotBlank
	public String getSurname() {
		return this.surname;
	}

	public void setSurname(final String surname) {
		this.surname = surname;
	}

	@NotBlank
	@Email
	public String getEmail() {
		return this.email;
	}

	public void setEmail(final String email) {
		this.email = email;
	}

	@NotBlank
	@Pattern(regexp = "^([+]\\d+\\s)?\\d+$")
	public String getPhone() {
		return this.phone;
	}

	public void setPhone(final String phone) {
		this.phone = phone;
	}
	@NotFalse
	public Boolean getContractAccepted() {
		return this.contractAccepted;
	}
	public void setContractAccepted(final Boolean contractAccepted) {
		this.contractAccepted = contractAccepted;
	}

}
