
package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.EventRepository;
import domain.Actor;
import domain.ChirpBroadcast;
import domain.Chorbi;
import domain.Event;
import domain.Fee;
import domain.Manager;

@Service
@Transactional
public class EventService {

	@Autowired
	private EventRepository			eventRepository;

	//Supported Services ============================================================================

	@Autowired
	public ManagerService			managerService;

	@Autowired
	private ChorbiService			chorbiService;

	@Autowired
	private ChirpBroadcastService	chirpBroadcastService;

	@Autowired
	private FeeService				feeService;


	//Constructor methods ============================================================================

	public EventService() {
		super();
	}

	// Simple CRUD methods ============================================================================

	public Event findOne(final int eventId) {
		Event result;

		result = this.eventRepository.findOne(eventId);

		return result;
	}

	public Collection<Event> findAll() {
		Collection<Event> result;

		result = this.eventRepository.findAll();

		return result;
	}

	public Collection<Event> findEventsByManager() {
		Collection<Event> result;
		Manager principal;

		principal = this.managerService.findByPrincipal();
		result = this.eventRepository.findEventsByManager(principal.getId());

		return result;
	}

	public Event create() {
		Event result;
		Manager principal;

		principal = this.managerService.findByPrincipal();
		result = new Event();

		result.setManager(principal);

		return result;
	}

	public Event save(final Event event) {
		this.managerService.validCreditCard();
		Event result;
		Manager principal;
		final Fee fee = this.feeService.findByManager();

		principal = this.managerService.findByPrincipal();
		Assert.isTrue(principal.equals(event.getManager()));
		result = this.eventRepository.saveAndFlush(event);
		principal.setAmount(principal.getAmount() + fee.getQuantity());

		return result;
	}

	public void delete(final Event event) {
		Assert.notNull(event);
		Actor principal;
		Collection<ChirpBroadcast> chirpsBroadcasts;

		chirpsBroadcasts = this.chirpBroadcastService.chirpsByEventId(event.getId());

		for (final ChirpBroadcast c : chirpsBroadcasts)
			c.setRecipient(null);

		principal = this.managerService.findByPrincipal();

		Assert.isTrue(principal.equals(event.getManager()));

		this.eventRepository.delete(event);

	}

	//Other Business Methods =========================================================================

	public Collection<Event> findAllBySeatsAvailableAndLessMonth() {
		Collection<Event> result;

		result = this.eventRepository.findAllBySeatsAvailableAndLessMonth();

		return result;
	}

	public Collection<Event> findByPrincipalChorbi() {
		Collection<Event> result;
		final Chorbi chorbi = this.chorbiService.findByPrincipal();

		result = chorbi.getEvents();

		return result;
	}

	public void registerToEvent(final Event event) {
		final Chorbi chorbi = this.chorbiService.findByPrincipal();
		final Collection<Chorbi> chorbies = event.getChorbies();
		final Collection<Event> events = chorbi.getEvents();
		Assert.isTrue(event.getSeats() - event.getChorbies().size() > 0 && !event.getChorbies().contains(chorbi));

		chorbies.add(chorbi);
		events.add(event);
		event.setChorbies(chorbies);
		chorbi.setEvents(events);
	}

	public void unregisterToEvent(final Event event) {
		final Chorbi chorbi = this.chorbiService.findByPrincipal();
		final Collection<Chorbi> chorbies = event.getChorbies();
		final Collection<Event> events = chorbi.getEvents();
		Assert.isTrue(event.getChorbies().contains(chorbi) && chorbi.getEvents().contains(event));

		chorbies.remove(chorbi);
		events.remove(event);
		event.setChorbies(chorbies);
		chorbi.setEvents(events);
	}
}
