
package controllers;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import domain.ChirpBroadcast;
import services.ChirpBroadcastService;

@Controller
@RequestMapping("/chirpBroadcast")
public class ChirpBroadcastController extends AbstractController {

	// Services ============================================================================

	
	@Autowired
	private ChirpBroadcastService	chirpBroadcastService;



	// Constructors ========================================================================

	public ChirpBroadcastController() {
		super();
	}



	//List my sendChirps ========================================================================================

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView listChirpBroadcasts(@RequestParam int eventId) {
		ModelAndView result;
		Collection<ChirpBroadcast> chirpBroadcasts;

		
		chirpBroadcasts = chirpBroadcastService.chirpsByEventId(eventId);

		result = new ModelAndView("chirpBroadcast/list");

		for (final ChirpBroadcast c : chirpBroadcasts) {
			final String subject = c.getSubject();
			final String d1 = subject.replaceAll("([+]\\d+\\s)?(\\d){6,}", "***");
			c.setSubject(d1.replaceAll("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,6}", "***"));
		}

		result.addObject("chirpBroadcasts", chirpBroadcasts);
		result.addObject("requestURI", "chirpBroadcast/list.do");

		return result;
	}

	@RequestMapping(value = "/listDeletedEvent", method = RequestMethod.GET)
	public ModelAndView listDeletedEvent() {
		ModelAndView result;
		Collection<ChirpBroadcast> chirpBroadcasts;
		chirpBroadcasts = chirpBroadcastService.chirpDeleted();

		result = new ModelAndView("chirpBroadcast/list");

		for (final ChirpBroadcast c : chirpBroadcasts) {
			final String subject = c.getSubject();
			final String d1 = subject.replaceAll("([+]\\d+\\s)?(\\d){6,}", "***");
			c.setSubject(d1.replaceAll("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,6}", "***"));
		}

		result.addObject("chirpBroadcasts", chirpBroadcasts);
		result.addObject("requestURI", "chirpBroadcast/listDeletedEvent.do");

		return result;
	}

}
