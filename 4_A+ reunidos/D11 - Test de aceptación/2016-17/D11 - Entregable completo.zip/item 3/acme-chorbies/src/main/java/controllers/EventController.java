
package controllers;

import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.EventService;
import domain.Event;

@Controller
@RequestMapping("/event")
public class EventController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private EventService	eventService;


	// Constructors ========================================================================

	public EventController() {
		super();
	}

	//List events available and less month ========================================================================================

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView listEventsAvailable() {
		ModelAndView result;
		List<Event> events;

		events = (List<Event>) this.eventService.findAllBySeatsAvailableAndLessMonth();
		Collections.sort(events, new Comparator<Event>() {

			@Override
			public int compare(final Event eventA, final Event eventB) {
				return (eventB.getSeats() - eventB.getChorbies().size()) - (eventA.getSeats() - eventA.getChorbies().size());
			}
		});

		result = new ModelAndView("event/list");

		result.addObject("events", events);
		result.addObject("requestURI", "event/list.do");

		return result;
	}

	@SuppressWarnings("deprecation")
	@RequestMapping(value = "/listAll", method = RequestMethod.GET)
	public ModelAndView listAll() {
		ModelAndView result;
		List<Event> events;

		events = (List<Event>) this.eventService.findAll();
		final Date actual = new Date(System.currentTimeMillis() - 1000);
		final Date monthMore = new Date(System.currentTimeMillis() - 1000);
		final int month = monthMore.getMonth() + 1;
		monthMore.setMonth(month);

		Collections.sort(events, new Comparator<Event>() {

			@Override
			public int compare(final Event eventA, final Event eventB) {
				return (eventB.getSeats() - eventB.getChorbies().size()) - (eventA.getSeats() - eventA.getChorbies().size());
			}
		});

		result = new ModelAndView("event/listAll");

		result.addObject("events", events);
		result.addObject("requestURI", "event/listAll.do");
		result.addObject("actual", actual);
		result.addObject("monthMore", monthMore);
		return result;
	}

}
