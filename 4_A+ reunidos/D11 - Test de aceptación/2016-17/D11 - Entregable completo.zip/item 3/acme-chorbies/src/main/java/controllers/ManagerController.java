/*
 * ManagerController.java
 *
 * Copyright (C) 2017 Universidad de Sevilla
 *
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import domain.Brand;
import domain.Manager;
import domain.Genre;
import domain.Relationship;
import forms.RegisterFormManager;
import services.ManagerService;

@Controller
@RequestMapping("/managers")
public class ManagerController extends AbstractController {

	// Services -------------------------------------------------------------------

	@Autowired
	private ManagerService managerService;


	// Constructors -----------------------------------------------------------

	public ManagerController() {
		super();
	}

	// Listing methods -----------------------------------------------------------

	// Create methods --------------------------------------------------------------

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView create() {

		ModelAndView result;
		final RegisterFormManager form = new RegisterFormManager();
		result = this.createEditModelAndView(form);

		return result;

	}

	@RequestMapping(value = "/register", method = RequestMethod.POST, params = "register")
	public ModelAndView save(@ModelAttribute("form") @Valid final RegisterFormManager form, final BindingResult binding) {

		ModelAndView result;
		Manager manager;

		if (binding.hasErrors()) {

			if (binding.getGlobalError() != null)
				result = this.createEditModelAndView(form, binding.getGlobalError().getCode());
			else
				result = this.createEditModelAndView(form);
		} else
			try {
				manager = this.managerService.reconstruct(form);

				this.managerService.save(manager);

				result = new ModelAndView("redirect:/");

			} catch (final DataIntegrityViolationException exc) {
				result = this.createEditModelAndView(form, "register.duplicated.user");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(form, "register.commit.error");
			}

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit() {
		ModelAndView result;
		Manager principal;

		principal = this.managerService.findByPrincipal();
		result = this.editModelAndView(principal);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@ModelAttribute("manager") @Valid final Manager manager, final BindingResult binding) {

		ModelAndView result;

		if (binding.hasErrors())
			result = this.editModelAndView(manager);
		else
			try {
				this.managerService.update(manager);
				result = new ModelAndView("redirect:../welcome/index.do");

			} catch (final Throwable oops) {
				result = this.editModelAndView(manager, "edit.commit.error");
			}
		return result;

	}
	// Ancillary methods ---------------------------------------------------------

	protected ModelAndView createEditModelAndView(final RegisterFormManager registerFormManager) {

		ModelAndView result;

		result = this.createEditModelAndView(registerFormManager, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final RegisterFormManager registerFormManager, final String message) {

		ModelAndView result;

		final List<Relationship> relationship = Arrays.asList(Relationship.values());
		final List<Genre> genre = Arrays.asList(Genre.values());
		final List<Brand> brand = Arrays.asList(Brand.values());

		result = new ModelAndView("managers/register");
		result.addObject("form", registerFormManager);
		result.addObject("message", message);
		result.addObject("relationshipManager", relationship);
		result.addObject("genre", genre);
		result.addObject("brand", brand);

		return result;
	}

	protected ModelAndView editModelAndView(final Manager manager) {

		ModelAndView result;

		result = this.editModelAndView(manager, null);

		return result;
	}

	protected ModelAndView editModelAndView(final Manager manager, final String message) {

		ModelAndView result;
		result = new ModelAndView("managers/edit");
		result.addObject("manager", manager);
		result.addObject("message", message);
		return result;
	}
}
