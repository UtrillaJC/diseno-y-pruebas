
package services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.SearchTemplateRepository;
import domain.Chorbi;
import domain.SearchTemplate;

@Service
@Transactional
public class SearchTemplateService {

	//Managed Repository =============================================================================

	@Autowired
	private SearchTemplateRepository searchTemplateRepository;

	//Supported Services =============================================================================

	@Autowired
	private ChorbiService chorbiService;

	//Constructor methods ============================================================================

	public SearchTemplateService() {
		super();
	}

	//Simple CRUD methods ============================================================================

	public SearchTemplate create() {
		SearchTemplate result;

		result = new SearchTemplate();

		return result;
	}
	public SearchTemplate saveEdit(SearchTemplate searchTemplate) {
		Assert.notNull(searchTemplate);
		SearchTemplate result;
		Chorbi principal;
		
		principal = chorbiService.findByPrincipal();
		Assert.isTrue(searchTemplate.equals(principal.getSearchTemplate()));
		Assert.notNull(principal);
		
		searchTemplate.setLastSearch(null);
		
		result = searchTemplateRepository.saveAndFlush(searchTemplate);

		return result;
	}


	public SearchTemplate save(SearchTemplate searchTemplate) {
		Assert.notNull(searchTemplate);
		SearchTemplate result;
		
		result = searchTemplateRepository.saveAndFlush(searchTemplate);

		return result;
	}
	
	public SearchTemplate saveSearch(SearchTemplate searchTemplate) {
		Assert.notNull(searchTemplate);
		SearchTemplate result;
		Chorbi principal;
				
		principal = chorbiService.findByPrincipal();
		Assert.isTrue(searchTemplate.equals(principal.getSearchTemplate()));
		result = searchTemplateRepository.saveAndFlush(searchTemplate);

		return result;
	}

	//Other Business Methods =========================================================================

	public SearchTemplate findByPrincipal() {
		SearchTemplate result;
		Chorbi chorbi;
		
		chorbi = this.chorbiService.findByPrincipal();
		result = chorbi.getSearchTemplate();
		
		return result;
	}
}
