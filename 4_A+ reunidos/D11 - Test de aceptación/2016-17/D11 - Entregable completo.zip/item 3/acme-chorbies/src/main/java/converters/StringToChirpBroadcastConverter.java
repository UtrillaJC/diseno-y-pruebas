
package converters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import domain.ChirpBroadcast;
import repositories.ChirpBroadcastRepository;

@Component
@Transactional
public class StringToChirpBroadcastConverter implements Converter<String, ChirpBroadcast> {

	@Autowired
	ChirpBroadcastRepository chirpBroadcastRepository;


	@Override
	public ChirpBroadcast convert(final String text) {
		ChirpBroadcast result;
		int id;

		try {
			if (StringUtils.isEmpty(text))
				result = null;
			else {
				id = Integer.valueOf(text);
				result = this.chirpBroadcastRepository.findOne(id);
			}
		} catch (final Throwable oops) {
			throw new IllegalArgumentException(oops);
		}
		return result;
	}
}
