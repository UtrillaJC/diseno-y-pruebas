
package controllers.administrator;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.CacheService;
import controllers.AbstractController;
import domain.Cache;

@Controller
@RequestMapping("/cache/administrator")
public class CacheAdministratorController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private CacheService	cacheService;


	// Constructors ========================================================================

	public CacheAdministratorController() {
		super();
	}

	
	//Show Cache
	@RequestMapping(value = "/showCache", method = RequestMethod.GET)
	public ModelAndView showCache() {
		ModelAndView result;
		Cache cache;

		cache = cacheService.findCache();

		result = new ModelAndView("cache/administrator/showCache");
		result.addObject("row", cache);

		return result;
	}
	
	
	// Edit ======================================================================================

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int cacheId) {
		ModelAndView result;
		final Cache cache;

		cache = this.cacheService.findOneToEdit(cacheId);
		Assert.notNull(cache);

		result = this.createEditModelAndView(cache);

		return result;
	}

	// Edit ======================================================================================

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid @ModelAttribute final Cache cache, final BindingResult bindingResult) {
		ModelAndView result;

		if (bindingResult.hasErrors())
			result = this.createEditModelAndView(cache);
		else
			try {
				this.cacheService.save(cache);
				result = new ModelAndView("redirect:/cache/administrator/showCache.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(cache, "cache.commit.error");
			}
		return result;
	}

	// Ancillary methods =============================================================================

	protected ModelAndView createEditModelAndView(final Cache cache) {
		assert cache != null;

		ModelAndView result;

		result = this.createEditModelAndView(cache, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Cache cache, final String message) {
		assert cache != null;

		ModelAndView result;

		result = new ModelAndView("cache/administrator/edit");
		result.addObject("cache", cache);
		result.addObject("message", message);

		return result;
	}

}
