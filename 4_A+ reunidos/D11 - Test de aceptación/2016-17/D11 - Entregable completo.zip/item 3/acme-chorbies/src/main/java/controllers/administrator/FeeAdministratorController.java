
package controllers.administrator;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.FeeService;
import controllers.AbstractController;
import domain.Fee;

@Controller
@RequestMapping("/fee/administrator")
public class FeeAdministratorController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private FeeService	feeService;


	// Constructors ========================================================================

	public FeeAdministratorController() {
		super();
	}

	// List ======================================================================================

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Fee> fees;

		fees = this.feeService.findAll();

		result = new ModelAndView("fee/administrator/list");
		result.addObject("fees", fees);
		result.addObject("requestURI", "fee/administrator/list.do");

		return result;

	}

	// Edit ======================================================================================

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int feeId) {
		ModelAndView result;
		final Fee fee;

		fee = this.feeService.findOne(feeId);
		Assert.notNull(fee);

		result = this.createEditModelAndView(fee);

		return result;
	}

	// Edit ======================================================================================

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid @ModelAttribute final Fee fee, final BindingResult bindingResult) {
		ModelAndView result;

		if (bindingResult.hasErrors())
			result = this.createEditModelAndView(fee);
		else
			try {
				this.feeService.save(fee);
				result = new ModelAndView("redirect:/fee/administrator/list.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(fee, "fee.commit.error");
			}
		return result;
	}

	// Update monthly fees ---------------------------------------------------------------------------

	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public ModelAndView updateFees() {
		ModelAndView result;
		try {
			this.feeService.updateFees();
			result = new ModelAndView("redirect:/");
			result.addObject("messageOk", "updateFees.commit.ok");
		} catch (final Throwable oops) {
			result = new ModelAndView("redirect:/");
			result.addObject("messageError", "updateFees.commit.error");
		}

		return result;
	}

	// Ancillary methods =============================================================================

	protected ModelAndView createEditModelAndView(final Fee fee) {
		assert fee != null;

		ModelAndView result;

		result = this.createEditModelAndView(fee, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Fee fee, final String message) {
		assert fee != null;

		ModelAndView result;

		result = new ModelAndView("fee/administrator/edit");
		result.addObject("fee", fee);
		result.addObject("message", message);

		return result;
	}

}
