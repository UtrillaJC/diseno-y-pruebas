
package services;

import java.util.ArrayList;
import java.util.Collection;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.ManagerRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;
import domain.CreditCard;
import domain.Event;
import domain.Manager;
import forms.RegisterFormManager;

@Service
@Transactional
public class ManagerService {

	//Managed Repository =============================================================================

	@Autowired
	private ManagerRepository		managerRepository;

	//Supported Services =============================================================================
	@Autowired
	private AdministratorService	administratorService;


	//Constructor methods ============================================================================

	public ManagerService() {
		super();
	}

	//Simple CRUD methods ============================================================================

	public Manager findOne(final int managerId) {
		Manager result;

		result = this.managerRepository.findOne(managerId);

		return result;
	}

	public Collection<Manager> findAll() {
		Collection<Manager> result;

		result = this.managerRepository.findAll();

		return result;
	}

	public Manager create() {
		Manager result;
		UserAccount userAccount;
		Authority authority;
		CreditCard creditCard;

		authority = new Authority();
		userAccount = new UserAccount();
		creditCard = new CreditCard();
		Collection<Event> events;

		authority.setAuthority("MANAGER");
		userAccount.addAuthority(authority);
		events = new ArrayList<Event>();

		result = new Manager();

		result.setUserAccount(userAccount);
		result.setCreditCard(creditCard);
		result.setEvents(events);
		result.getUserAccount().setEnabled(true);
		result.setAmount(0.0);

		return result;
	}

	public Manager save(final Manager manager) {
		Assert.notNull(manager);
		Manager result;

		int actualMonth, actualYear;

		actualMonth = DateTime.now().getMonthOfYear();
		actualYear = DateTime.now().getYear();

		Assert.isTrue(manager.getCreditCard().getExpirationYear() > actualYear || ((manager.getCreditCard().getExpirationYear() == actualYear) && (manager.getCreditCard().getExpirationMonth() >= actualMonth)));

		String password = manager.getUserAccount().getPassword();
		final Md5PasswordEncoder encoder = new Md5PasswordEncoder();
		password = encoder.encodePassword(password, null);
		manager.getUserAccount().setPassword(password);

		result = this.managerRepository.saveAndFlush(manager);

		return result;
	}

	//Other Business Methods =========================================================================

	public Manager findByPrincipal() {
		Manager result;
		UserAccount userAccount;

		userAccount = LoginService.getPrincipal();
		Assert.notNull(userAccount);
		result = this.findByUserAccount(userAccount);
		Assert.notNull(result);

		return result;
	}

	public Manager findByUserAccount(final UserAccount userAccount) {
		Manager result;

		result = this.managerRepository.findByUserAccountId(userAccount.getId());

		return result;
	}

	public void checkPrincipal() {
		final UserAccount userAccount = LoginService.getPrincipal();
		Assert.notNull(userAccount);

		final Collection<Authority> authorities = userAccount.getAuthorities();
		Assert.notNull(authorities);

		final Authority auth = new Authority();
		auth.setAuthority("MANAGER");

		Assert.isTrue(authorities.contains(auth));

	}

	public Manager reconstruct(final RegisterFormManager form) {
		Manager manager;

		manager = this.create();

		manager.getUserAccount().setUsername(form.getUsername());
		manager.getUserAccount().setPassword(form.getPassword());
		manager.setName(form.getName());
		manager.setSurname(form.getSurname());
		manager.setEmail(form.getEmail());
		manager.setPhone(form.getPhone());
		manager.setNameCompany(form.getNameCompany());
		manager.setVatNumber(form.getVatNumber());

		manager.getCreditCard().setBrandName(form.getCreditCard().getBrandName());
		manager.getCreditCard().setHolderName(form.getCreditCard().getHolderName());
		manager.getCreditCard().setNumber(form.getCreditCard().getNumber());
		manager.getCreditCard().setcvvCode(form.getCreditCard().getcvvCode());
		manager.getCreditCard().setExpirationMonth(form.getCreditCard().getExpirationMonth());
		manager.getCreditCard().setExpirationYear(form.getCreditCard().getExpirationYear());

		return manager;

	}

	public Manager update(final Manager manager) {
		Assert.notNull(manager);
		Manager result;
		Manager principal;
		int actualMonth, actualYear;

		actualMonth = DateTime.now().getMonthOfYear();
		actualYear = DateTime.now().getYear();
		principal = this.findByPrincipal();
		Assert.isTrue(principal.equals(manager));
		Assert.isTrue(manager.getCreditCard().getExpirationYear() > actualYear || ((manager.getCreditCard().getExpirationYear() == actualYear) && (manager.getCreditCard().getExpirationMonth() >= actualMonth)));

		result = this.managerRepository.saveAndFlush(manager);

		return result;

	}

	public void validCreditCard() {
		Manager manager;
		int actualMonth, actualYear;
		manager = this.findByPrincipal();
		actualMonth = DateTime.now().getMonthOfYear();
		actualYear = DateTime.now().getYear();
		Assert.isTrue(manager.getCreditCard().getExpirationYear() > actualYear || ((manager.getCreditCard().getExpirationYear() == actualYear) && (manager.getCreditCard().getExpirationMonth() >= actualMonth)));

	}

	public Collection<Manager> ManagerOrdermoreEvents() {
		this.administratorService.checkPrincipal();
		return this.managerRepository.ManagerOrdermoreEvents();
	}

	public Collection<Object[]> managerAmount() {
		this.administratorService.checkPrincipal();
		return this.managerRepository.managerAmount();
	}
}
