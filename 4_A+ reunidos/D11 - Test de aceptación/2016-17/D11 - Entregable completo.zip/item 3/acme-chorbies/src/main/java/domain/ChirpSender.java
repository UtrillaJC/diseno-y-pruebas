
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.validation.Valid;
import javax.validation.constraints.Digits;

@Entity
@Access(AccessType.PROPERTY)
public abstract class ChirpSender extends Actor {

	//Attributes ====================================================================================

	private Double	amount;


	//Constructor ====================================================================================

	public ChirpSender() {
		super();
	}

	//Getter &  setter ====================================================================================

	@Digits(integer = 99, fraction = 2)
	public Double getAmount() {
		return this.amount;
	}

	public void setAmount(final Double amount) {
		this.amount = amount;
	}


	//Relationship ====================================================================================

	private Collection<Chirp>	sentChirps;


	@Valid
	@OneToMany(mappedBy = "sender")
	public Collection<Chirp> getSentChirps() {
		return this.sentChirps;
	}

	public void setSentChirps(final Collection<Chirp> sentChirps) {
		this.sentChirps = sentChirps;
	}
}
