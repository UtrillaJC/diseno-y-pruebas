
package repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.LikeStore;

@Repository
public interface LikeStoreRepository extends JpaRepository<LikeStore, Integer> {
	
	@Query("select l from LikeStore l where l.liker.id=?2 and l.liked.id=?1")
	LikeStore findByLikerAndLiked(int likedId, int likerId);

	

	
	
	
	
}
