
package domain;

import java.util.Collection;
import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.URL;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Access(AccessType.PROPERTY)
@Table(uniqueConstraints = {
	@UniqueConstraint(columnNames = {
		"seats", "moment"
	})
})
public class Event extends DomainEntity {

	//Attributes ====================================================================================

	private String	title;
	private Date	moment;
	private String	description;
	private String	picture;
	private int		seats;


	//Constructor ====================================================================================

	public Event() {
		super();
	}

	//Getter &  setter ====================================================================================

	@NotBlank
	public String getTitle() {
		return this.title;
	}

	public void setTitle(final String title) {
		this.title = title;
	}

	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.TIMESTAMP)
	@NotNull
	public Date getMoment() {
		return this.moment;
	}

	public void setMoment(final Date moment) {
		this.moment = moment;
	}

	@NotBlank
	public String getDescription() {
		return this.description;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	@NotBlank
	@URL
	public String getPicture() {
		return this.picture;
	}

	public void setPicture(final String picture) {
		this.picture = picture;
	}

	@Min(0)
	public int getSeats() {
		return this.seats;
	}

	public void setSeats(final int seats) {
		this.seats = seats;
	}


	//Relationship ====================================================================================

	private Manager				manager;
	private Collection<Chorbi>	chorbies;


	//	private Collection<ChirpBroadcast>	chirpBroadcasts;

	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public Manager getManager() {
		return this.manager;
	}

	public void setManager(final Manager manager) {
		this.manager = manager;
	}

	@ManyToMany
	@Valid
	public Collection<Chorbi> getChorbies() {
		return this.chorbies;
	}

	public void setChorbies(final Collection<Chorbi> chorbies) {
		this.chorbies = chorbies;
	}

	//	@Valid
	//	@OneToMany
	//	public Collection<ChirpBroadcast> getChirpBroadcasts() {
	//		return this.chirpBroadcasts;
	//	}
	//
	//	public void setChirpBroadcasts(final Collection<ChirpBroadcast> chirpBroadcasts) {
	//		this.chirpBroadcasts = chirpBroadcasts;
	//	}
}
