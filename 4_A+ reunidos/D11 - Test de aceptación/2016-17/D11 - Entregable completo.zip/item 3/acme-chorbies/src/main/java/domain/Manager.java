
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.validation.Valid;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Access(AccessType.PROPERTY)
public class Manager extends ChirpSender {

	//Attributes ====================================================================================

	private String		nameCompany;
	private Integer		vatNumber;
	private CreditCard	creditCard;


	//Constructor ====================================================================================

	public Manager() {
		super();
	}

	//Getter &  setter ====================================================================================

	@NotBlank
	public String getNameCompany() {
		return this.nameCompany;
	}

	public void setNameCompany(final String nameCompany) {
		this.nameCompany = nameCompany;
	}

	public Integer getVatNumber() {
		return this.vatNumber;
	}

	public void setVatNumber(final Integer vatNumber) {
		this.vatNumber = vatNumber;
	}

	@Valid
	public CreditCard getCreditCard() {
		return this.creditCard;
	}

	public void setCreditCard(final CreditCard creditCard) {
		this.creditCard = creditCard;
	}


	//Relationship ====================================================================================

	private Collection<Event>	events;


	@Valid
	@OneToMany(mappedBy = "manager")
	public Collection<Event> getEvents() {
		return this.events;
	}

	public void setEvents(final Collection<Event> events) {
		this.events = events;
	}

}
