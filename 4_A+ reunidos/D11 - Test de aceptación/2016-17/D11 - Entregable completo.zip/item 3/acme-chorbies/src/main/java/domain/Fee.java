
package domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.validation.constraints.Digits;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Access(AccessType.PROPERTY)
@Table(indexes = {
	@Index(columnList = "name")
})
public class Fee extends DomainEntity {

	//Attributes ====================================================================================

	private Double	quantity;
	private String	name;


	//Constructor ====================================================================================

	public Fee() {
		super();
	}

	//Getter &  setter ====================================================================================

	@Digits(integer = 99, fraction = 2)
	public Double getQuantity() {
		return this.quantity;
	}

	public void setQuantity(final Double quantity) {
		this.quantity = quantity;
	}

	@NotBlank
	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	//Relationship ====================================================================================

}
