
package controllers.chorbi;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.EventService;
import controllers.AbstractController;
import domain.Event;

@Controller
@RequestMapping("/event/chorbi")
public class EventChorbiController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private EventService	eventService;


	// Constructors ========================================================================

	public EventChorbiController() {
		super();
	}

	//List events available and less month ========================================================================================

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		List<Event> events;

		events = (List<Event>) this.eventService.findByPrincipalChorbi();

		Collections.sort(events, new Comparator<Event>() {

			@Override
			public int compare(final Event eventA, final Event eventB) {
				return (eventB.getSeats() - eventB.getChorbies().size()) - (eventA.getSeats() - eventA.getChorbies().size());
			}
		});

		result = new ModelAndView("event/chorbi/list");

		result.addObject("events", events);
		result.addObject("requestURI", "event/chorbi/list.do");

		return result;
	}

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView register(@RequestParam final int eventId) {
		ModelAndView result;
		final Event event = this.eventService.findOne(eventId);

		try {
			this.eventService.registerToEvent(event);
			result = this.list();
			result.addObject("messageOk", "registerEvent.commit.ok");
		} catch (final Throwable oops) {
			result = this.list();
			result.addObject("message", "registerEvent.commit.error");
		}

		return result;
	}

	@RequestMapping(value = "/unregister", method = RequestMethod.GET)
	public ModelAndView unregister(@RequestParam final int eventId) {
		ModelAndView result;
		final Event event = this.eventService.findOne(eventId);

		try {
			this.eventService.unregisterToEvent(event);
			result = this.list();
			result.addObject("messageOk", "unregisterEvent.commit.ok");
		} catch (final Throwable oops) {
			result = this.list();
			result.addObject("message", "unregisterEvent.commit.error");
		}

		return result;
	}

}
