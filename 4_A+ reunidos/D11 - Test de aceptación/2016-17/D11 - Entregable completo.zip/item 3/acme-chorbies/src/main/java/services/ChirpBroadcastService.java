
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Actor;
import domain.ChirpBroadcast;
import domain.ChirpSender;
import domain.Event;
import repositories.ChirpBroadcastRepository;

@Service
@Transactional
public class ChirpBroadcastService {

	//Managed Repository =============================================================================

	@Autowired
	private ChirpBroadcastRepository		chirpBroadcastRepository;

	//Supported Services ============================================================================
	
	@Autowired
	private ManagerService managerService;

	@Autowired
	private EventService eventService;

	@Autowired
	private ChirpSenderService	chirpSenderService;


	//Constructor methods ============================================================================

	public ChirpBroadcastService() {
		super();
	}

	// Simple CRUD methods ============================================================================

	public ChirpBroadcast findOne(final int chirpBroadcastId) {
		ChirpBroadcast result;

		result = this.chirpBroadcastRepository.findOne(chirpBroadcastId);

		return result;
	}

	public ChirpBroadcast create(int eventId) {
		ChirpBroadcast result;
		ChirpSender principal;
		Date momentActual;
		Event event = eventService.findOne(eventId);
		Collection<String> attachments= new ArrayList<String>();

		momentActual = new Date(System.currentTimeMillis() - 1000);

		
		principal = this.chirpSenderService.findByPrincipal();
		
		result = new ChirpBroadcast();

		result.setSender(principal);
		result.setMoment(momentActual);
		result.setRecipient(event);
		result.setAttachments(attachments);
		result.setDeleted(false);
		return result;
	}

	public ChirpBroadcast save(final ChirpBroadcast chirpBroadcast) {
		ChirpBroadcast result;
		Date momentActual;
		Event event;

		momentActual = new Date(System.currentTimeMillis() - 1000);
		chirpBroadcast.setMoment(momentActual);	
		event = chirpBroadcast.getRecipient();

		result = this.chirpBroadcastRepository.save(chirpBroadcast);

		eventService.save(event);
		
		return result;
	}
	public ChirpBroadcast saveDelete(final ChirpBroadcast chirpBroadcast) {
		ChirpBroadcast result;
		Date momentActual;
		momentActual = new Date(System.currentTimeMillis() - 1000);
		chirpBroadcast.setMoment(momentActual);	
		chirpBroadcast.setDeleted(true);
		result = this.chirpBroadcastRepository.save(chirpBroadcast);
		
		return result;
	}


	public void delete(final ChirpBroadcast chirpBroadcast) {
		Assert.notNull(chirpBroadcast);
		Actor principal;

		principal = this.managerService.findByPrincipal();

		Assert.isTrue(principal.equals(chirpBroadcast.getSender()));

		this.chirpBroadcastRepository.delete(chirpBroadcast);

	}

	// Other business methods ============================================================================



	
	//Metodo para enviar cuando se borra
	  
	  public void sendDeleteBroadcastAutomatically(int eventId) {
	    ChirpBroadcast result;
	    Event event;

	    	event = eventService.findOne(eventId);
	    	if (!event.getChorbies().isEmpty()){
		    result = this.create(eventId);
		    result.setSubject(result.getRecipient().getTitle() + " (EVENT DELETED/EVENTO BORRADO)");
		    result.setText("This event has been deleted./Este evento ha sido borrado.");
	    	this.saveDelete(result);		    
	    	}
	    }

	//Metodo para enviar cuando se borra

	  public void sendEditBroadcastAutomatically(int eventId) {
	    ChirpBroadcast result;	  
	    Event event;

    	event = eventService.findOne(eventId);
    	if (!event.getChorbies().isEmpty()){	    
	    result = this.create(eventId);
	    result.setSubject(result.getRecipient().getTitle() + " (EVENT EDITED/EVENTO EDITADO)");
	    result.setText("This event has been deleted./Este evento ha sido borrado.");
    	this.save(result);	
    	}
		
	}

		public Collection<ChirpBroadcast> chirpDeleted() {
			Collection<ChirpBroadcast> result;
			result = this.chirpBroadcastRepository.chirpDeleted();

			return result;
		}
	  
		public Collection<ChirpBroadcast> chirpsByEventId(int eventId) {
			Collection<ChirpBroadcast> result;
			result = this.chirpBroadcastRepository.chirpsByEventId(eventId);

			return result;
		}
}
