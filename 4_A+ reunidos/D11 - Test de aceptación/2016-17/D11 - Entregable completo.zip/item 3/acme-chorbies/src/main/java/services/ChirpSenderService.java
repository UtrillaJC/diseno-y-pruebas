
package services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.ChirpSenderRepository;
import security.LoginService;
import security.UserAccount;
import domain.ChirpSender;

@Service
@Transactional
public class ChirpSenderService {

	//Managed Repository =============================================================================

	@Autowired
	private ChirpSenderRepository	chirpSenderRepository;


	//Supported Services =============================================================================

	//Constructor methods ============================================================================

	public ChirpSenderService() {
		super();
	}

	//Simple CRUD methods ============================================================================

	//Other Business Methods =========================================================================

	public ChirpSender findByPrincipal() {
		ChirpSender result;
		UserAccount userAccount;

		userAccount = LoginService.getPrincipal();
		Assert.notNull(userAccount);
		result = this.findByUserAccount(userAccount);
		Assert.notNull(result);

		return result;
	}

	public ChirpSender findByUserAccount(final UserAccount userAccount) {
		ChirpSender result;

		result = this.chirpSenderRepository.findByUserAccountId(userAccount.getId());

		return result;
	}
}
