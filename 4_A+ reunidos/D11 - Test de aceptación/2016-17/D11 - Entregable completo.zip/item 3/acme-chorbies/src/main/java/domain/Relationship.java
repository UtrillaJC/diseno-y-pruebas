
package domain;

public enum Relationship {

	activities, friendship, love
}
