
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Event;

@Repository
public interface EventRepository extends JpaRepository<Event, Integer> {

	@Query("select e from Event e where e.manager.id = ?1")
	Collection<Event> findEventsByManager(int managerId);

	@Query("select e from Event e where e.seats > e.chorbies.size and YEAR(e.moment) = YEAR(CURRENT_TIMESTAMP) and MONTH(e.moment) = MONTH(CURRENT_TIMESTAMP) and DAY(e.moment) - DAY(CURRENT_TIMESTAMP) <= 30 and e.moment > CURRENT_TIMESTAMP or YEAR(e.moment) = YEAR(CURRENT_TIMESTAMP) and MONTH(e.moment) - MONTH(CURRENT_TIMESTAMP) = 1 and DAY(e.moment) - DAY(CURRENT_TIMESTAMP) <= 30 and e.moment > CURRENT_TIMESTAMP or YEAR(e.moment) - YEAR(CURRENT_TIMESTAMP) = 1 and MONTH(CURRENT_TIMESTAMP) - MONTH(e.moment) = 11 and DAY(e.moment) - DAY(CURRENT_TIMESTAMP) <= 30 and e.moment > CURRENT_TIMESTAMP")
	Collection<Event> findAllBySeatsAvailableAndLessMonth();

}
