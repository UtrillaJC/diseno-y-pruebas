
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class DashboardServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private ChorbiService	chorbiService;
	
	@Autowired
	private ManagerService	managerService;

	// Tests =======================================================================================
	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			A listing with the number of chorbies per country.
	@Test
	public void driverCountChorbiByCountry() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateCountChorbiByCountry((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateCountChorbiByCountry(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.countChorbiByCountry();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			A listing with the number of chorbies per city.
	@Test
	public void driverCountChorbiByCity() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateCountChorbiByCity((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateCountChorbiByCity(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.countChorbiByCity();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			The minimum ages of the chorbies.
	@Test
	public void driverMinAges() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateMinAges((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateMinAges(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.minAges();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			The maximum ages of the chorbies.
	@Test
	public void driverMaxAges() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateMaxAges((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateMaxAges(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.maxAges();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			The average ages of the chorbies.
	@Test
	public void driverAvgAges() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateAvgAges((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateAvgAges(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.avgAges();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//	The ratio of chorbies who have not registered a credit card or have registered
	//	an invalid credit card.
	@Test
	public void driverRatioCreditCardNoValid() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateRatioCreditCardNoValid((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateRatioCreditCardNoValid(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.ratioCreditCardNoValid();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//	The ratios of chorbies who search for "activities".
	@Test
	public void driverRatioActivities() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateRatioActivities((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateRatioActivities(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.ratioActivities();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//	The ratios of chorbies who search for "friendship".
	@Test
	public void driverRatioFriendship() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateRatioFriendship((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateRatioFriendship(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.ratioFriendship();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//	The ratios of chorbies who search for "love".
	@Test
	public void driverRatioLove() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateRatioLove((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateRatioLove(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.ratioLove();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	//	Display a dashboard with the following information
	//	The minimum number of likes per chorbi.
	@Test
	public void driverMinLikes() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateMinLikes((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateMinLikes(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.minLikes();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	Display a dashboard with the following information
	//	The maximum number of likes per chorbi.
	@Test
	public void driverMaxLikes() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateMaxLikes((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateMaxLikes(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.maxLikes();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	Display a dashboard with the following information
	//	The average number of likes per chorbi.
	@Test
	public void driverAvgLikes() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateAvgLikes((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateAvgLikes(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.avgLikes();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	Display a dashboard with the following information:
	//	The list of chorbies, sorted by the number of likes they have got.
	@Test
	public void driverChorbiOrdermoreLike() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateChorbiOrdermoreLike((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateChorbiOrdermoreLike(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.chorbiOrdermoreLike();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	Display a dashboard with the following information:
	//		The minimum number of chirps that a chorbi
	//		receives from other chorbies.
	@Test
	public void driverMinChirpReceiver() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateMinChirpReceiver((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateMinChirpReceiver(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.minChirpReceiver();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	Display a dashboard with the following information:
	//		The maximum number of chirps that a chorbi
	//		receives from other chorbies.
	@Test
	public void driverMaxChirpReceiver() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateMaxChirpReceiver((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateMaxChirpReceiver(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.maxChirpReceiver();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	Display a dashboard with the following information:
	//		The average number of chirps that a chorbi
	//		receives from other chorbies.
	@Test
	public void driverAvgChirpReceiver() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateAvgChirpReceiver((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateAvgChirpReceiver(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.avgChirpReceiver();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	Display a dashboard with the following information:
	//		The minimum number of chirps that a chorbi
	//		sends to other chorbies.
	@Test
	public void driverMinChirpSent() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateMinChirpSent((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateMinChirpSent(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.minChirpSent();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	Display a dashboard with the following information:
	//		The maximum number of chirps that a chorbi
	//		sends to other chorbies.
	@Test
	public void driverMaxChirpSent() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateMaxChirpSent((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateMaxChirpSent(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.maxChirpSent();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	Display a dashboard with the following information:
	//		The average number of chirps that a chorbi
	//		sends to other chorbies.
	@Test
	public void driverAvgChirpSent() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateAvgChirpSent((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateAvgChirpSent(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.avgChirpSent();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	Display a dashboard
	//	The chorbies who have got more chirps.
	@Test
	public void driverChorbiMoreChirpReceiver() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateChorbiMoreChirpReceiver((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateChorbiMoreChirpReceiver(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.chorbiMoreChirpReceiver();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	Display a dashboard
	//	The chorbies who have sent more chirps.
	@Test
	public void driverChorbiMoreChirpSent() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"chorbi1", IllegalArgumentException.class
			//logueado como un chorbi. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateChorbiMoreChirpSent((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateChorbiMoreChirpSent(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.chorbiMoreChirpSent();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	// An actor who is authenticated as admin:
	  // Dashboard
	  
	  @Test
	  public void driverChorbiesOrderStar() {
	    final Object testingData[][] = {
	      {
	        "admin", null //positivo. autenticado como ADMINISTRATOR
	      },
	      
	      {
	        "chorbi1", IllegalArgumentException.class //negativo. autenticado como CHORBI
	      }, {
	        null, IllegalArgumentException.class //no logueado
	      }

	    };

	    for (int i = 0; i < testingData.length; i++)
	      this.templateChorbiesOrderStar((String) testingData[i][0], (Class<?>) testingData[i][1]);
	  }

	  public void templateChorbiesOrderStar(final String username, final Class<?> expected) {
	    Class<?> caught;

	    caught = null;

	    try {
	      this.authenticate(username);
	      this.chorbiService.chorbiesOrderStar();
	      this.unauthenticate();

	    } catch (final Throwable oops) {
	      caught = oops.getClass();
	    }
	    this.checkExceptions(expected, caught);
	  }

	  @Test
	  public void driverChorbiOrdermoreEvents() {
	    final Object testingData[][] = {
	      {
	        "admin", null //positivo. autenticado como ADMINISTRATOR
	      },
	      
	      {
	        "chorbi1", IllegalArgumentException.class //negativo. autenticado como CHORBI
	      }, {
	        null, IllegalArgumentException.class //no logueado
	      }

	    };

	    for (int i = 0; i < testingData.length; i++)
	      this.templateChorbiOrdermoreEvents((String) testingData[i][0], (Class<?>) testingData[i][1]);
	  }

	  public void templateChorbiOrdermoreEvents(final String username, final Class<?> expected) {
	    Class<?> caught;

	    caught = null;

	    try {
	      this.authenticate(username);
	      this.chorbiService.chorbiOrdermoreEvents();
	      this.unauthenticate();

	    } catch (final Throwable oops) {
	      caught = oops.getClass();
	    }
	    this.checkExceptions(expected, caught);
	  }
	  @Test
	  public void driverMinStar() {
	    final Object testingData[][] = {
	      {
	        "admin", null //positivo. autenticado como ADMINISTRATOR
	      },
	      
	      {
	        "chorbi1", IllegalArgumentException.class //negativo. autenticado como CHORBI
	      }, {
	        null, IllegalArgumentException.class //no logueado
	      }

	    };

	    for (int i = 0; i < testingData.length; i++)
	      this.templateMinStar((String) testingData[i][0], (Class<?>) testingData[i][1]);
	  }

	  public void templateMinStar(final String username, final Class<?> expected) {
	    Class<?> caught;

	    caught = null;

	    try {
	      this.authenticate(username);
	      this.chorbiService.minStar();
	      this.unauthenticate();

	    } catch (final Throwable oops) {
	      caught = oops.getClass();
	    }
	    this.checkExceptions(expected, caught);
	  }
	  
	  @Test
	  public void driverMaxStar() {
	    final Object testingData[][] = {
	      {
	        "admin", null //positivo. autenticado como ADMINISTRATOR
	      },
	      
	      {
	        "chorbi1", IllegalArgumentException.class //negativo. autenticado como CHORBI
	      }, {
	        null, IllegalArgumentException.class //no logueado
	      }

	    };

	    for (int i = 0; i < testingData.length; i++)
	      this.templateMaxStar((String) testingData[i][0], (Class<?>) testingData[i][1]);
	  }

	  public void templateMaxStar(final String username, final Class<?> expected) {
	    Class<?> caught;

	    caught = null;

	    try {
	      this.authenticate(username);
	      this.chorbiService.maxStar();
	      this.unauthenticate();

	    } catch (final Throwable oops) {
	      caught = oops.getClass();
	    }
	    this.checkExceptions(expected, caught);
	  }
	  
	  @Test
	  public void driverAvgStar() {
	    final Object testingData[][] = {
	      {
	        "admin", null //positivo. autenticado como ADMINISTRATOR
	      },
	      
	      {
	        "chorbi1", IllegalArgumentException.class //negativo. autenticado como CHORBI
	      }, {
	        null, IllegalArgumentException.class //no logueado
	      }

	    };

	    for (int i = 0; i < testingData.length; i++)
	      this.templateAvgStar((String) testingData[i][0], (Class<?>) testingData[i][1]);
	  }

	  public void templateAvgStar(final String username, final Class<?> expected) {
	    Class<?> caught;

	    caught = null;

	    try {
	      this.authenticate(username);
	      this.chorbiService.avgStar();
	      this.unauthenticate();

	    } catch (final Throwable oops) {
	      caught = oops.getClass();
	    }
	    this.checkExceptions(expected, caught);
	  }

	  @Test
	  public void driverChorbiAmount() {
	    final Object testingData[][] = {
	      {
	        "admin", null //positivo. autenticado como ADMINISTRATOR
	      },
	      
	      {
	        "chorbi1", IllegalArgumentException.class //negativo. autenticado como CHORBI
	      }, {
	        null, IllegalArgumentException.class //no logueado
	      }

	    };

	    for (int i = 0; i < testingData.length; i++)
	      this.templateChorbiAmount((String) testingData[i][0], (Class<?>) testingData[i][1]);
	  }

	  public void templateChorbiAmount(final String username, final Class<?> expected) {
	    Class<?> caught;

	    caught = null;

	    try {
	      this.authenticate(username);
	      this.chorbiService.chorbiAmount();
	      this.unauthenticate();

	    } catch (final Throwable oops) {
	      caught = oops.getClass();
	    }
	    this.checkExceptions(expected, caught);
	  }  
	  
	  @Test
	  public void driverManagerOrdermoreEvents() {
	    final Object testingData[][] = {
	      {
	        "admin", null //positivo. autenticado como ADMINISTRATOR
	      },
	      
	      {
	        "chorbi1", IllegalArgumentException.class //negativo. autenticado como CHORBI
	      }, {
	        null, IllegalArgumentException.class //no logueado
	      }

	    };

	    for (int i = 0; i < testingData.length; i++)
	      this.templateManagerOrdermoreEvents((String) testingData[i][0], (Class<?>) testingData[i][1]);
	  }

	  public void templateManagerOrdermoreEvents(final String username, final Class<?> expected) {
	    Class<?> caught;

	    caught = null;

	    try {
	      this.authenticate(username);
	      this.managerService.ManagerOrdermoreEvents();
	      this.unauthenticate();

	    } catch (final Throwable oops) {
	      caught = oops.getClass();
	    }
	    this.checkExceptions(expected, caught);
	  }
	  
	  @Test
	  public void driverManagerAmount() {
	    final Object testingData[][] = {
	      {
	        "admin", null //positivo. autenticado como ADMINISTRATOR
	      },
	      
	      {
	        "chorbi1", IllegalArgumentException.class //negativo. autenticado como CHORBI
	      }, {
	        null, IllegalArgumentException.class //no logueado
	      }

	    };

	    for (int i = 0; i < testingData.length; i++)
	      this.templateManagerAmount((String) testingData[i][0], (Class<?>) testingData[i][1]);
	  }

	  public void templateManagerAmount(final String username, final Class<?> expected) {
	    Class<?> caught;

	    caught = null;

	    try {
	      this.authenticate(username);
	      this.managerService.managerAmount();
	      this.unauthenticate();

	    } catch (final Throwable oops) {
	      caught = oops.getClass();
	    }
	    this.checkExceptions(expected, caught);
	  }
}