
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;
import domain.Event;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class EventServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private EventService	eventService;


	// Tests =======================================================================================

	// An actor who is authenticated as a manager must be able to:
	// List his events

	@Test
	public void driverFindEventsByManager() {
		final Object testingData[][] = {
			{
				"manager1", null
			},

			{
				"admin", IllegalArgumentException.class
			}, {
				null, IllegalArgumentException.class
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateFindEventsByManager((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateFindEventsByManager(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.eventService.findEventsByManager();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//An actor who is authenticated as a manager must be able to:
	//Create an event

	@Test
	public void driverCreateEvent() {

		final Object testingData[][] = {
			{
				"manager1", null
			//POSITIVO Usuario logueado crea un evento suyo correctamente.
			}, {
				"chorbi1", IllegalArgumentException.class
			//NEGATIVO Usuario logueado crea un evento cuando no esta permitido hacerlo.
			}, {
				null, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado crea un evento que no es suyo.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateDeleteEvent((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateCreateEvent(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.eventService.create();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//An actor who is authenticated as a manager must be able to:
	//Modifying an event

	@Test
	public void driverModifyingEvent() {

		final Object testingData[][] = {
			{
				"manager1", "TituloPrueba", null
			//POSITIVO Usuario logueado edita un evento suyo correctamente.
			}, {
				"manager2", "TituloPrueba", IllegalArgumentException.class
			//NEGATIVO Usuario logueado edita un evento que no es suyo.
			}, {
				null, "TituloPrueba", IllegalArgumentException.class
			//NEGATIVO Usuario no logueado edita un evento que no es suyo.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateModifyingEvent((String) testingData[i][0], (String) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateModifyingEvent(final String username, final String title, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			Event event;
			event = this.eventService.findOne(105);
			event.setTitle(title);

			this.eventService.save(event);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//An actor who is authenticated as a manager must be able to:
	//Delete an event

	@Test
	public void driverDeleteEvent() {

		final Object testingData[][] = {
			{
				"manager1", null
			//POSITIVO Usuario logueado borra un evento suyo correctamente.
			}, {
				"manager2", IllegalArgumentException.class
			//NEGATIVO Usuario logueado borra un evento que no es suyo.
			}, {
				null, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado borra un evento que no es suyo.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateDeleteEvent((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateDeleteEvent(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			Event event;
			event = this.eventService.findOne(105);
			this.eventService.delete(event);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	An actor who is authenticated as a chorbi must be able to:
	//	Register to an event as long as there are enough seats available.

	@Test
	public void driverRegisterToEvent() {

		final Object testingData[][] = {
			{
				"chorbi1", 105, null
			//POSITIVO Usuario logueado como chorbi se registra a un evento.
			}, {
				"chorbi2", 105, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como chorbi intenta registrarse a un evento al que ya se registro.
			}, {
				"chorbi1", 108, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como chorbi intenta registrarse a un evento sin plazas disponibles.
			}, {
				null, 105, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta registrarse a un evento.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateRegisterToEvent((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateRegisterToEvent(final String username, final int eventId, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			Event event;
			event = this.eventService.findOne(eventId);
			this.eventService.registerToEvent(event);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	An actor who is authenticated as a chorbi must be able to:
	//	Un-register from an event to which he or she's registered.

	@Test
	public void driverUnregisterFromEvent() {

		final Object testingData[][] = {
			{
				"chorbi2", 105, null
			//POSITIVO Usuario logueado como chorbi se borra de un evento.
			}, {
				"chorbi1", 105, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como chorbi intenta borrarse de un evento del que no se registro.
			}, {
				null, 105, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta borrarse de un evento.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateUnregisterFromEvent((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateUnregisterFromEvent(final String username, final int eventId, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			Event event;
			event = this.eventService.findOne(eventId);
			this.eventService.unregisterToEvent(event);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	An actor who is authenticated as a chorbi must be able to:
	//	Browse the list of events to which he or she's registered.

	@Test
	public void driverBrowseRegisteredEvents() {

		final Object testingData[][] = {
			{
				"chorbi1", null
			//POSITIVO Usuario logueado como chorbi lista los eventos a los que se ha registrado.
			}, {
				"manager", IllegalArgumentException.class
			//NEGATIVO Usuario logueado como admin intenta listar los eventos a los que se ha registrado.
			}, {
				null, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta listar los eventos a los que se ha registrado.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateBrowseRegisteredEvents((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateBrowseRegisteredEvents(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.eventService.findByPrincipalChorbi();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

}
