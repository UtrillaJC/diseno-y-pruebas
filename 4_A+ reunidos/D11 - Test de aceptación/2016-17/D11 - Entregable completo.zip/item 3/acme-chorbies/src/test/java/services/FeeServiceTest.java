
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;
import domain.Fee;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class FeeServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private FeeService	feeService;


	// Tests =======================================================================================

	// An actor who is authenticated as an administrator must be able to:
	// Change the fee that is charged to managers and chorbies. (Note that they need not be the same.)
	@Test
	public void driverEditFee() {
		final Object testingData[][] = {
			{
				"admin", 12, null
			//POSITIVO Usuario logueado como admin cambia el fee
			}, {
				null, 12, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta cambiar la fee
			}, {
				"chorbi1", 12, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como chorbi intenta cambiar la fee
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateEditFee((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateEditFee(final String username, final double quantity, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			Fee fee;
			fee = this.feeService.findOne(79);
			fee.setQuantity(quantity);
			this.feeService.save(fee);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	// An actor who is authenticated as an administrator must be able to:
	// Run a process to update the total monthly fees that the chorbies would have to pay.
	@Test
	public void driverUpdateFees() {
		final Object testingData[][] = {
			{
				"admin", null
			//POSITIVO Usuario logueado como admin actualiza los fees
			}, {
				null, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta actualizar los fees
			}, {
				"chorbi1", IllegalArgumentException.class
			//NEGATIVO Usuario logueado como chorbi intenta actualizar los fees
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateUpdateFees((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateUpdateFees(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.feeService.updateFees();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

}
