
package services;

import javax.validation.ConstraintViolationException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import domain.Brand;
import domain.CreditCard;
import forms.RegisterFormManager;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class ManagerServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private ManagerService	managerService;


	// Tests =======================================================================================

	//A user who is not authenticated must be able to:
	//Login to the system using his or her credentials.
	@Test
	public void driverLogin() {
		final Object testingData[][] = {
			{
				"manager1", null
			//POSITIVO Usuario se loguea como manager1
			}, {
				"", IllegalArgumentException.class
			//NEGATIVO Usuario intenta loguearse dejando el username en blanco
			}, {
				"inexistente", IllegalArgumentException.class
			//NEGATIVO Usuario inexistente intenta loguearse 
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateLogin((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateLogin(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	//Register as manager
	@Test
	public void driverManagerRegisterForm() {
		CreditCard creditcard = new CreditCard();
		creditcard.setBrandName(Brand.VISA);
		creditcard.setHolderName("prueba");
		creditcard.setcvvCode(111);
		creditcard.setExpirationMonth(12);
		creditcard.setExpirationYear(2022);
		creditcard.setNumber("4196521598170877");
		
		final Object testingData[][] = {
			// Register to the system as a user
			{
				true, "name1", "user1", "password1", "password1", "+34 636435557", "email@gmail.es", "surname", "nombre de la compa�ia", 2, creditcard,null
//			//Nos registramos como manager en el sistema con todos los datos correctos.POSITIVO1.	
			}, {
				true, "name2", "user2", "password1", "password1", "+34 636435557", "emailgmail.es", "surname", "nombre de la compa�ia", 2, creditcard, ConstraintViolationException.class
			//formato  invalido, NEGATIVO1	

			}

		};
		for (int i = 0; i < testingData.length; i++)
			this.templateManagerRegisterForm((Boolean) testingData[i][0],
											 (String) testingData[i][1],
											 (String) testingData[i][2],
											 (String) testingData[i][3],
											 (String) testingData[i][4],
											 (String) testingData[i][5],
											 (String) testingData[i][6],
											 (String) testingData[i][7],
											 (String) testingData[i][8],
											 (Integer) testingData[i][9],
											 (CreditCard) testingData[i][10],
											 (Class<?>) testingData[i][11]);
	}

	public void templateManagerRegisterForm(final Boolean contractAccepted,
											final String name,
											final String username,
											final String password, 
											final String verifyPassword,
											final String phone, 
											final String email, 
											final String surname,
											final String nameCompany,
											final Integer vatNumber, 
											final CreditCard creditcard, 
											final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			final RegisterFormManager urf = new RegisterFormManager();
			urf.setContractAccepted(contractAccepted);
			urf.setName(name);
			urf.setUsername(username);
			urf.setPassword(password);
			urf.setVerifyPassword(verifyPassword);
			urf.setPhone(phone);
			urf.setEmail(email);
			urf.setSurname(surname);			
			urf.setNameCompany(nameCompany);
			urf.setVatNumber(vatNumber);
			urf.setCreditCard(creditcard);
			

			this.managerService.save(this.managerService.reconstruct(urf));

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	An actor who is authenticated as a chorbi must be able to:
	//	Change his or her profile.
//	@Test
//	public void driverEditProfile() {
//		final Chorbi chorbi = this.chorbiService.findOne(90);
//		final Date birthDate = chorbi.getBirthDate();
//		final Coordinates coordinates = chorbi.getCoordinates();
//		coordinates.setCity("Sevilla");
//		coordinates.setCountry("Espa�a");
//		coordinates.setState("Andaluc�a");
//		coordinates.setProvince("Sevilla");
//
//		final Object testingData[][] = {
//			{
//				"chorbi1", "Jose Manuel", "Navarro", "jose@mail.com", "http://jose.com", "+34 665333817", "Inteligente", Relationship.love, Genre.man, coordinates, birthDate, null
//			//POSITIVO Usuario logueado como chorbi edita su perfil
//			}, {
//				null, "Jose Manuel", "Navarro", "jose@mail.com", "http://jose.com", "+34 665333817", "Inteligente", Relationship.love, Genre.man, coordinates, birthDate, IllegalArgumentException.class
//			//NEGATIVO Usuario no logueado intenta editar su perfil
//			}, {
//				"chorbi2", "", "Navarro", "jose@mail.com", "http://jose.com", "+34 665333817", "Inteligente", Relationship.love, Genre.man, coordinates, birthDate, ConstraintViolationException.class
//			//NEGATIVO Usuario logueado como chorbi intenta editar su perfil y deja el nombre en blanco
//			}
//		};
//
//		for (int i = 0; i < testingData.length; i++)
//			this.templateEditProfile((String) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (String) testingData[i][3], (String) testingData[i][4], (String) testingData[i][5], (String) testingData[i][6],
//				(Relationship) testingData[i][7], (Genre) testingData[i][8], (Coordinates) testingData[i][9], (Date) testingData[i][10], (Class<?>) testingData[i][11]);
//	}
//
//	public void templateEditProfile(final String username, final String name, final String surname, final String email, final String picture, final String phone, final String description, final Relationship relationship, final Genre genre,
//		final Coordinates coordinates, final Date birthDate, final Class<?> expected) {
//		Class<?> caught;
//
//		caught = null;
//
//		try {
//			this.authenticate(username);
//			final Chorbi chorbi = this.chorbiService.findOne(90);
//			chorbi.setName(name);
//			chorbi.setSurname(surname);
//			chorbi.setPhone(phone);
//			chorbi.setEmail(email);
//			chorbi.setPicture(picture);
//			chorbi.setDescription(description);
//			chorbi.setBirthDate(birthDate);
//			chorbi.setCoordinates(coordinates);
//			chorbi.setGenre(genre);
//			chorbi.setRelationship(relationship);
//			this.chorbiService.update(chorbi);
//
//			this.unauthenticate();
//
//		} catch (final Throwable oops) {
//			caught = oops.getClass();
//		}
//		this.checkExceptions(expected, caught);
//	}
}
