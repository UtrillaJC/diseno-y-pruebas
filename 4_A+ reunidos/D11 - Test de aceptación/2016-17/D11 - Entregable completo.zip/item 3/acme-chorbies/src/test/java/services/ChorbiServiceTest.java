
package services;

import java.util.Date;

import javax.validation.ConstraintViolationException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;
import domain.Brand;
import domain.Chorbi;
import domain.Coordinates;
import domain.Genre;
import domain.Relationship;
import forms.CreditCardForm;
import forms.RegisterForm;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class ChorbiServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private ChorbiService	chorbiService;


	// Tests =======================================================================================

	//A user who is not authenticated must be able to:
	//Login to the system using his or her credentials.
	@Test
	public void driverLogin() {
		final Object testingData[][] = {
			{
				"chorbi1", null
			//POSITIVO Usuario se loguea como chorbi1
			}, {
				"", IllegalArgumentException.class
			//NEGATIVO Usuario intenta loguearse dejando el username en blanco
			}, {
				"inexistente", IllegalArgumentException.class
			//NEGATIVO Usuario inexistente intenta loguearse 

			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateLogin((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateLogin(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	An actor who is authenticated must be able to:
	//	Browse the list of chorbies who have registered to the system.
	@Test
	public void driverBrowseChorbies() {
		final Object testingData[][] = {
			{
				"chorbi1", null
			//POSITIVO Usuario se loguea como chorbi1
			}, {
				"", IllegalArgumentException.class
			//NEGATIVO Usuario intenta loguearse dejando el username en blanco
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateBrowseChorbies((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateBrowseChorbies(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.findAll();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	// A user who is authenticated as an admin:
	// Ban a chorbi, that is, to disable his or her account
	@Test
	public void driverBan() {
		final Object testingData[][] = {
			{
				"admin", 95, null
			//POSITIVO Usuario logueado como admin banea al chorbi con id 52
			}, {
				null, 96, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta banear a un chorbi
			}, {
				"chorbi1", 97, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como chorbi intenta banear a otro chorbi
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateBan((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateBan(final String username, final int chorbiId, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.banChorbi(chorbiId);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	// A user who is authenticated as an admin:
	// Unban a chorbi, which means that his or her account is re-enabled.
	@Test
	public void driverUnban() {
		final Object testingData[][] = {
			{
				"admin", 99, null
			//POSITIVO Usuario logueado como admin desbanea al chorbi con id 94
			}, {
				null, 99, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta desbanear a un chorbi
			}, {
				"chorbi1", 99, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como chorbi intenta desbanear a otro chorbi
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateUnban((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateUnban(final String username, final int chorbiId, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.unbanChorbi(chorbiId);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	An actor who is authenticated must be able to:
	//	Browse the list of chorbies who have registered to the system and navigate to the
	//	chorbies who like them.
	@Test
	public void driverBrowseChorbiesWhoLikeThem() {
		final Object testingData[][] = {
			{
				"chorbi1", this.chorbiService.findOne(96), null
			//POSITIVO Usuario se loguea como chorbi1
			}, {
				"", this.chorbiService.findOne(97), IllegalArgumentException.class
			//NEGATIVO Usuario intenta loguearse dejando el username en blanco
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateBrowseChorbiesWhoLikeThem((String) testingData[i][0], (Chorbi) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateBrowseChorbiesWhoLikeThem(final String username, final Chorbi chorbi, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chorbiService.findLikesByLiked(chorbi);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	@Test
	public void driverUpdateCreditCard() {

		final Object testingData[][] = {
			{
				"chorbi1", Brand.VISA, 111, 2, 2020, "4226761849010480", "holderName", null
			//logueado como un chorbi. Positivo
			}, {
				"chorbi1", Brand.VISA, 111, 2, 2010, "4226761849010480", "holderName", IllegalArgumentException.class
			//creditcard expirada. Negativo
			}, {
				"chorbi1", Brand.VISA, 111, 2, 2010, "4226761849015480", "holderName", IllegalArgumentException.class
			//n�mero de creditcard no v�lida. Negativo

			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateUpdateCreditCard((String) testingData[i][0], (Brand) testingData[i][1], (int) testingData[i][2], (int) testingData[i][3], (int) testingData[i][4], (String) testingData[i][5], (String) testingData[i][6],
				(Class<?>) testingData[i][7]);
	}

	public void templateUpdateCreditCard(final String username, final Brand brandName, final int cvvCode, final int expirationMonth, final int expirationYear, final String number, final String holderName, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final CreditCardForm form = new CreditCardForm();
			form.setBrandName(brandName);
			form.setcvvCode(cvvCode);
			form.setExpirationMonth(expirationMonth);
			form.setExpirationYear(expirationYear);
			form.setNumber(number);
			form.setHolderName(holderName);

			this.chorbiService.updateCreditCard(form);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	A user who is not authenticated must be able to:
	//	Register to the system as a chorbi.
	@Test
	public void driverChorbiRegisterForm() {
		final Date date = new Date(12 / 10 / 1998);
		//		final Date date2 = new Date(12 / 10 / 2008);
		//		final Date date3 = new Date(12 / 10 / 2028);
		final Coordinates coordinates = new Coordinates();
		coordinates.setCountry("Espa�a");
		coordinates.setCity("Sevilla");
		final Object testingData[][] = {
			// Register to the system as a user
			{
				true, "name1", "user1", "password1", "password1", "+34 636435557", "email@gmail.es", "surname", "http://4.bp.blogspot.com/-agczo3xCwc8/UYrHz7mYhNI/AAAAAAAAAs0/YasdtPjlrzI/s320/profile-photo.jpg", "description", Relationship.love, date,
				Genre.man, coordinates, null
			//Nos registramos en el sistema con todos los datos correctos.POSITIVO1.	
			}, {
				true, "name2", "user2", "password2", "password2", "+34 636435557", "email@gmail.es", "surname", "s320/profile-photo.jpg", "description", Relationship.love, date, Genre.man, coordinates, ConstraintViolationException.class
			//formato picture invalido, NEGATIVO1.	
			//			}, {
			//				true, "name3", "user2", "password3", "password3", "+34 636435557", "email@gmail.es", "surname", "http://4.bp.blogspot.com/-agczo3xCwc8/UYrHz7mYhNI/AAAAAAAAAs0/YasdtPjlrzI/s320/profile-photo.jpg", "description", Relationship.love, date,
			//				Genre.man, coordinates, DataIntegrityViolationException.class //username exist, NEGATIVO2.
			//			}, {
			//				true, "name4", "user4", "password4", "password4", "+34 636435557", "emailgmailes", "surname", "http://4.bp.blogspot.com/-agczo3xCwc8/UYrHz7mYhNI/AAAAAAAAAs0/YasdtPjlrzI/s320/profile-photo.jpg", "description", Relationship.love, date,
			//				Genre.man, coordinates, DataIntegrityViolationException.class //formato email invalido, NEGATIVO3.
			//			}, {
			//				true, "name5", "user5", "password5", "password5", "+34 636435557", "email@gmail.es", "surname", "http://4.bp.blogspot.com/-agczo3xCwc8/UYrHz7mYhNI/AAAAAAAAAs0/YasdtPjlrzI/s320/profile-photo.jpg", "description", Relationship.love, date,
			//				Genre.man, coordinates, DataIntegrityViolationException.class //name null, NEGATIVO4.
			//			}, {
			//				true, "name6", "user6", "password6", "password666", "+34 636435557", "email@gmail.es", "surname", "http://4.bp.blogspot.com/-agczo3xCwc8/UYrHz7mYhNI/AAAAAAAAAs0/YasdtPjlrzI/s320/profile-photo.jpg", "description", Relationship.love, date,
			//				Genre.man, coordinates, DataIntegrityViolationException.class //no coinciden password invalido, NEGATIVO5.
			//			}, {
			//				true, "name7", "user7", "password7", "password7", "+34 636435557", "email@gmail.es", "surname", "http://4.bp.blogspot.com/-agczo3xCwc8/UYrHz7mYhNI/AAAAAAAAAs0/YasdtPjlrzI/s320/profile-photo.jpg", "description", Relationship.love, date2,
			//				Genre.man, coordinates, DataIntegrityViolationException.class //menor de 18 a�os, NEGATIVO6.
			//			}, {
			//				true, "name8", "user8", "password8", "password8", "5557", "email@gmail.es", "surname", "http://4.bp.blogspot.com/-agczo3xCwc8/UYrHz7mYhNI/AAAAAAAAAs0/YasdtPjlrzI/s320/profile-photo.jpg", "description", Relationship.love, date, Genre.man,
			//				coordinates, DataIntegrityViolationException.class  //phone invalid, NEGATIVO7.
			//			}, {
			//				true, "name9", "user9", "password9", "password9", "+34 636435557", "email@gmail.es", "surname", "http://4.bp.blogspot.com/-agczo3xCwc8/UYrHz7mYhNI/AAAAAAAAAs0/YasdtPjlrzI/s320/profile-photo.jpg", "description", Relationship.love, date3,
			//				Genre.man, coordinates, DataIntegrityViolationException.class  //birthdate no past, NEGATIVO8.
			//			}, {
			//				true, "name10", "user10", "password10", "password10", "+34 636435557", "email@gmail.es", "surname", "http://4.bp.blogspot.com/-agczo3xCwc8/UYrHz7mYhNI/AAAAAAAAAs0/YasdtPjlrzI/s320/profile-photo.jpg", null, Relationship.love, date,
			//				Genre.man, coordinates, DataIntegrityViolationException.class  //decription null, NEGATIVO9.

			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateChorbiRegisterForm((Boolean) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (String) testingData[i][3], (String) testingData[i][4], (String) testingData[i][5], (String) testingData[i][6],
				(String) testingData[i][7], (String) testingData[i][8], (String) testingData[i][9], (Relationship) testingData[i][10], (Date) testingData[i][11], (Genre) testingData[i][12], (Coordinates) testingData[i][13], (Class<?>) testingData[i][14]);
	}

	public void templateChorbiRegisterForm(final Boolean contractAccepted, final String name, final String username, final String password, final String verifyPassword, final String phone, final String email, final String surname, final String picture,
		final String description, final Relationship relationship, final Date birthDate, final Genre genre, final Coordinates coordinates, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			final RegisterForm urf = new RegisterForm();
			urf.setContractAccepted(contractAccepted);
			urf.setName(name);
			urf.setUsername(username);
			urf.setPassword(password);
			urf.setVerifyPassword(verifyPassword);
			urf.setPhone(phone);
			urf.setEmail(email);
			urf.setSurname(surname);
			urf.setPicture(picture);
			urf.setDescription(description);
			urf.setRelationship(relationship);
			urf.setBirthDate(birthDate);
			urf.setGenre(genre);
			urf.setCoordinates(coordinates);

			this.chorbiService.save(this.chorbiService.reconstruct(urf));

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	An actor who is authenticated as a chorbi must be able to:
	//	Change his or her profile.
	@Test
	public void driverEditProfile() {
		final Chorbi chorbi = this.chorbiService.findOne(96);
		final Date birthDate = chorbi.getBirthDate();
		final Coordinates coordinates = chorbi.getCoordinates();
		coordinates.setCity("Sevilla");
		coordinates.setCountry("Espa�a");
		coordinates.setState("Andaluc�a");
		coordinates.setProvince("Sevilla");

		final Object testingData[][] = {
			{
				"chorbi1", "Jose Manuel", "Navarro", "jose@mail.com", "http://jose.com", "+34 665333817", "Inteligente", Relationship.love, Genre.man, coordinates, birthDate, null
			//POSITIVO Usuario logueado como chorbi edita su perfil
			}, {
				null, "Jose Manuel", "Navarro", "jose@mail.com", "http://jose.com", "+34 665333817", "Inteligente", Relationship.love, Genre.man, coordinates, birthDate, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta editar su perfil
			}, {
				"chorbi2", "", "Navarro", "jose@mail.com", "http://jose.com", "+34 665333817", "Inteligente", Relationship.love, Genre.man, coordinates, birthDate, ConstraintViolationException.class
			//NEGATIVO Usuario logueado como chorbi intenta editar su perfil y deja el nombre en blanco
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.templateEditProfile((String) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (String) testingData[i][3], (String) testingData[i][4], (String) testingData[i][5], (String) testingData[i][6],
				(Relationship) testingData[i][7], (Genre) testingData[i][8], (Coordinates) testingData[i][9], (Date) testingData[i][10], (Class<?>) testingData[i][11]);
	}

	public void templateEditProfile(final String username, final String name, final String surname, final String email, final String picture, final String phone, final String description, final Relationship relationship, final Genre genre,
		final Coordinates coordinates, final Date birthDate, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final Chorbi chorbi = this.chorbiService.findOne(95);
			chorbi.setName(name);
			chorbi.setSurname(surname);
			chorbi.setPhone(phone);
			chorbi.setEmail(email);
			chorbi.setPicture(picture);
			chorbi.setDescription(description);
			chorbi.setBirthDate(birthDate);
			chorbi.setCoordinates(coordinates);
			chorbi.setGenre(genre);
			chorbi.setRelationship(relationship);
			this.chorbiService.update(chorbi);

			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	An actor who is authenticated as a chorbi must be able to:
	//	Browse the catalogue of chorbies who have liked him or her as long as he or she has registered a valid credit card
	@Test
	public void driverBrowseChorbiesWhoLikeMe() {
		final Object testingData[][] = {
			{
				"chorbi1", null
			//POSITIVO Usuario se loguea como chorbi y ve los chorbis que le han dado me gusta
			}, {
				null, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta ver los chorbis que le han dado me gusta
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateBrowseChorbiesWhoLikeMe((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateBrowseChorbiesWhoLikeMe(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final Chorbi principal = this.chorbiService.findByPrincipal();
			this.chorbiService.findLikesByLiked(principal);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
}
