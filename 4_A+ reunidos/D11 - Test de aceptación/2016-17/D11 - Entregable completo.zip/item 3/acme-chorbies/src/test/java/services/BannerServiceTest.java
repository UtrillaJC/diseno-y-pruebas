
package services;

import javax.validation.ConstraintViolationException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;
import domain.Banner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class BannerServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private BannerService	bannerService;


	// Tests =======================================================================================

	// A user who is not authenticated must be able to:
	// See a welcome page with a banner that advertises Acme projects, including Acme Pad-Thai, Acme BnB, and Acme Car'n go! The banners must be selected randomly
	@Test
	public void driverSelect() {
		final Object testingData[][] = {
			{
				null, null
			//POSITIVO Usuario no logueado hace el seleccionar banner aleatoriamente
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateSelect((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateSelect(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.bannerService.selectBanner();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	// Admin
	// Change the banners that are displayed on the welcome page
	@Test
	public void driverSave() {
		final Object testingData[][] = {
			{
				"admin", 81, "http://image.com", null
			//POSITIVO Usuario logueado como admin llama al metodo guardar de Banner con todos los datos de Banner rellenos correctamente.
			}, {
				"admin", 82, null, ConstraintViolationException.class
			//NEGATIVO Usuario logueado como admin llama al metodo guardar con el campo "text" a null
			}, {
				null, 83, "http://image.com", IllegalArgumentException.class
			//NEGATIVO Usuario no autenticado llama al m�todo guardar de Banner con todos los datos de Banner rellenos correctamente.
			}, {
				"chorbi1", 81, "http://image.com", IllegalArgumentException.class
			//NEGATIVO Usuario autenticado que no debe de guardar un Banner llama al m�todo de guardar Banner con todos us datos rellenos correctamente.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateSave((String) testingData[i][0], (int) testingData[i][1], (String) testingData[i][2], (Class<?>) testingData[i][3]);
	}

	public void templateSave(final String username, final int bannerId, final String text, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			Banner banner;
			banner = this.bannerService.findOne(bannerId);
			banner.setText(text);
			this.bannerService.save(banner);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
}
