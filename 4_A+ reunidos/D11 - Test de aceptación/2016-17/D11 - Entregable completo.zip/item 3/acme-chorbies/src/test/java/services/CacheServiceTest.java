
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;
import domain.Cache;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class CacheServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private CacheService	cacheService;


	// Tests =======================================================================================

	// Admin
	//Change the time that the results of search templates are cached.
	@Test
	public void driverEditCache() {
		final Object testingData[][] = {
			{
				"admin", 78, 24, 0, 0, null
			//POSITIVO Usuario logueado como admin cambia el tiempo de cache a 24 horas
			}, {
				null, 78, 32, 0, 0, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta cambiar la cache
			}, {
				"chorbi1", 78, 24, 0, 0, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como chorbi intenta cambiar la cache
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateEditCache((String) testingData[i][0], (int) testingData[i][1], (Integer) testingData[i][2], (Integer) testingData[i][3], (Integer) testingData[i][4], (Class<?>) testingData[i][5]);
	}

	public void templateEditCache(final String username, final int cacheId, final Integer hours, final Integer minutes, final Integer seconds, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			Cache cache;
			cache = this.cacheService.findOneToEdit(cacheId);
			cache.setHours(hours);
			cache.setMinutes(minutes);
			cache.setSeconds(seconds);
			this.cacheService.save(cache);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

}
