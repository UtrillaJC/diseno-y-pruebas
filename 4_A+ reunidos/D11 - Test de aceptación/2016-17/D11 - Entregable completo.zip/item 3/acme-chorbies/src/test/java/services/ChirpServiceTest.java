
package services;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;

import javax.validation.ConstraintViolationException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;
import domain.Chirp;
import domain.Chorbi;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class ChirpServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private ChirpService	chirpService;

	@Autowired
	private ChorbiService	chorbiService;


	// Tests =======================================================================================

	// A user who is authenticated as chorbi:
	// Chirp to another chorbi
	@SuppressWarnings("unchecked")
	@Test
	public void driverChirp() throws MalformedURLException {
		Chorbi recipient, recipient2;
		recipient = this.chorbiService.findOne(95);
		recipient2 = this.chorbiService.findOne(96);
		Collection<URL> attachments1;
		attachments1 = new ArrayList<URL>();
		final URL at1 = new URL("http://nereida.deioc.ull.es/~cleon/in.da");
		attachments1.add(at1);

		final Object testingData[][] = {
			{
				"chorbi1", "asunto", "texto del mensaje", attachments1, recipient, null
			//POSITIVO Usuario logueado como chorbi envia un chirp
			}, {
				null, "asunto", "texto del mensaje", attachments1, recipient, IllegalArgumentException.class
			//NEGATIVO 1 Usuario no logueado intenta enviar un chirp
			}, {
				"chorbi1", "", "texto del mensaje", attachments1, recipient, ConstraintViolationException.class
			//NEGATIVO 2 Usuario logueado como chorbi intenta enviar chirp con subject en blanco
			}, {
				"admin", "asunto", "texto del mensaje", attachments1, recipient, IllegalArgumentException.class
			//NEGATIVO 3 Usuario admin
			}, {
				"chorbi1", "asunto", "", attachments1, recipient, ConstraintViolationException.class
			//NEGATIVO 4 Usuario logueado como chorbi intenta enviar chirp con text en blanco
			}, {
				"chorbi1", "asunto", "texto del mensaje", null, recipient, ConstraintViolationException.class
			//NEGATIVO 5 attachment null
			}, {
				"chorbi1", "asunto", "texto del mensaje", attachments1, null, ConstraintViolationException.class
			//NEGATIVO 6 recipient null
			}, {
				"chorbi1", "asunto", null, attachments1, recipient, ConstraintViolationException.class
			//NEGATIVO 7 text null
			}, {
				"chorbi1", null, "texto del mensaje", attachments1, recipient, ConstraintViolationException.class
			//NEGATIVO 8 asunto null
			}, {
				"chorbi1", "asunto", "texto del mensaje", attachments1, recipient2, ConstraintViolationException.class
			//NEGATIVO 9 recipient no valid

			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateChirp((String) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (Collection<URL>) testingData[i][3], (Chorbi) testingData[i][4], (Class<?>) testingData[i][5]);
	}
	public void templateChirp(final String username, final String subject, final String text, final Collection<URL> attachments, final Chorbi recipient, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final Chirp chirp = this.chirpService.create();
			chirp.setSubject(subject);
			chirp.setText(text);
			chirp.setAttachments(attachments);
			chirp.setRecipient(recipient);
			chirp.setCopy(false);
			this.chirpService.save(chirp);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	// A user who is authenticated as chorbi:
	// Delete a chirp

	@Test
	public void driverDeleteChirp() {

		final Object testingData[][] = {
			{
				"chorbi1", null
			//POSITIVO Usuario logueado borra un chirp suyo correctamente.
			}, {
				"chorbi4", IllegalArgumentException.class
			//NEGATIVO Usuario logueado borra chirp que no ha enviado ni recibido, es decir, que no es suyo.
			}, {
				null, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta borrar chirp.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateDeleteChirp((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateDeleteChirp(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			Chirp chirp;
			chirp = this.chirpService.findOne(111);
			this.chirpService.delete(chirp);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	// A user who is authenticated as chorbi:
	// Browse the list of chirps that he or she's got, and reply to any of them.

	@Test
	public void driverCreateReplyChirp() {

		final Object testingData[][] = {
			{
				"chorbi2", null
			//POSITIVO Usuario logueado responde un chirp suyo correctamente.
			}, {
				"chorbi4", IllegalArgumentException.class
			//NEGATIVO Usuario logueado responde chirp que no ha enviado ni recibido, es decir, que no es suyo.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateDeleteChirp((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateCreateReplyChirp(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chirpService.findReceivedChirpsByChorbi();
			this.chirpService.createReply(111);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	// A user who is authenticated as chorbi:
	// Browse the list of chirps that he or she's sent, and re-send any of them

	@Test
	public void drivercreateResendChirp() {

		final Object testingData[][] = {
			{
				"chorbi1", null
			//POSITIVO Usuario logueado reenvia un chirp suyo correctamente.
			}, {
				"chorbi4", IllegalArgumentException.class
			//NEGATIVO Usuario logueado reenvia chirp que no ha enviado ni recibido, es decir, que no es suyo.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateDeleteChirp((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templatecreateResendChirp(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.chirpService.findSentChirpsByChorbi();
			this.chirpService.createResend(111);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

}
