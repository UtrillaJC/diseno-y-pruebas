
package services;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;
import domain.Chirp;
import domain.ChirpBroadcast;
import domain.Chorbi;
import domain.Event;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class ChirpBroadcastServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private ChirpBroadcastService	chirpBroadcastService;
	
	@Autowired
	private EventService	eventService;

	@Autowired
	private ChorbiService	chorbiService;
	
	@Autowired
	private ManagerService	managerService;


	// Tests =======================================================================================

	// A user who is authenticated as manager:
	// Chirpbroadcast 
	@SuppressWarnings("unchecked")
	@Test
	public void driverChirpBroadcast() throws MalformedURLException {
				
		Collection<String> attachments1;
		attachments1 = new ArrayList<String>();
		final String at1 = "http://nereida.deioc.ull.es/~cleon/in.da";
		attachments1.add(at1);

		final Object testingData[][] = {
			{
				"manager1", "asunto", "texto del mensaje", attachments1, null
			//POSITIVO Usuario logueado como manager envia un chirpbroadcast
			}, 
			{
				"chorbi1", "asunto", "texto del mensaje", attachments1, IllegalArgumentException.class
			//POSITIVO Usuario logueado como manager envia un chirpbroadcast
			}, 
			{
				null, "asunto", "texto del mensaje", attachments1, IllegalArgumentException.class
			//POSITIVO Usuario logueado como manager envia un chirpbroadcast
			}, 
		};

		for (int i = 0; i < testingData.length; i++)
			this.templateChirpBroadcast((String) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (Collection<String>) testingData[i][3], (Class<?>) testingData[i][4]);
	}
	public void templateChirpBroadcast(final String username, final String subject, final String text, final Collection<String> attachments, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			Event event;
			event = eventService.findOne(105);
			
			final ChirpBroadcast chirpBroadcast = this.chirpBroadcastService.create(event.getId());
			chirpBroadcast.setSubject(subject);
			chirpBroadcast.setText(text);
			chirpBroadcast.setAttachments(attachments);
			
			chirpBroadcast.setDeleted(false);
			this.chirpBroadcastService.save(chirpBroadcast);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	
	
	
	
	
	// A user who is authenticated as manager:
	// Delete a chirpbroadcast

		@Test
		public void driverDeleteChirp() {

			final Object testingData[][] = {
				{
					"manager1", null
				//POSITIVO Usuario logueado borra un chirpbroadcast suyo correctamente.
				}, {
					"chorbi4", IllegalArgumentException.class
				//NEGATIVO Usuario logueado borra chirpbroadcast que no ha enviado. 
				}, {
					null, IllegalArgumentException.class
				//NEGATIVO Usuario no logueado intenta borrar chirpbroadcast.
				}

			};

			for (int i = 0; i < testingData.length; i++)
				this.templateDeleteChirp((String) testingData[i][0], (Class<?>) testingData[i][1]);
		}

		public void templateDeleteChirp(final String username, final Class<?> expected) {
			Class<?> caught;

			caught = null;

			try {
				this.authenticate(username);
				ChirpBroadcast chirpBroadcast;
				chirpBroadcast = this.chirpBroadcastService.findOne(104);
				this.chirpBroadcastService.delete(chirpBroadcast);
				this.unauthenticate();

			} catch (final Throwable oops) {
				caught = oops.getClass();
			}
			this.checkExceptions(expected, caught);
		}

}
