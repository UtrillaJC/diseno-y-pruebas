
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.LikeStore;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class LikeStoredServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private LikeStoreService	likeStoreService;

	@Autowired
	private ChorbiService		chorbiService;


	// Tests =======================================================================================

	//A chorbi may like another chorbi. The system must store the moment when 
	//he or she likes him or her and an optional comment.
	@Test
	public void driverLike() {
		final Object testingData[][] = {
			{
				"chorbi1", 100, "coment1", 3, null
			//POSITIVO Usuario logueado como chorbi da like a otro chorbi
			}, {
				null, 100, "coment2", 2, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta dar like a un chorbi
			}, {
				"admin", 95, "comment3", 1, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como admin intenta dar like a otro chorbi
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateLike((String) testingData[i][0], (int) testingData[i][1], (String) testingData[i][2], (int) testingData[i][3], (Class<?>) testingData[i][4]);
	}

	public void templateLike(final String username, final int chorbiId, final String comment, final int star, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final LikeStore like = this.likeStoreService.create(chorbiId, comment, star);
			Assert.isTrue(this.chorbiService.findOne(chorbiId).getLikedStore().contains(like));
			Assert.isTrue(this.chorbiService.findByPrincipal().getLikerStore().contains(like));
			this.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//A like may be cancelled at any time.
	@Test
	public void driverCancel() {
		final Object testingData[][] = {
			{
				"chorbi2", "chorbi2", 98, 3, null
			//POSITIVO Usuario logueado como chorbi cancela un like suyo
			}, {
				"chorbi2", "chorbi4", 98, 2, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como chorbi cancela un like de otro
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateCancel((String) testingData[i][0], (String) testingData[i][1], (int) testingData[i][2], (int) testingData[i][3], (Class<?>) testingData[i][4]);
	}

	public void templateCancel(final String username, final String username2, final int chorbiId, final int star, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final LikeStore like = this.likeStoreService.create(chorbiId, "comment", star);
			this.unauthenticate();
			this.authenticate(username2);
			Assert.isTrue(this.likeStoreService.findOne(like.getId()) != null);
			this.likeStoreService.removeLike(chorbiId);
			Assert.isNull(this.likeStoreService.findOne(like.getId()));
			this.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

}
