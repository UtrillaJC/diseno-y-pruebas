-Cuando queremos hacer el requisito: Crear un presupuesto a partir de muebles y sus piezas.
 Debemos registrarnos como Customer, irnos a la vista del listado de muebles y darle al bot�n ADD.
 En esa nueva vista clickeamos en budget para escoger a que presupuesto queremos a�adir el mueble, y si no
 es a un presupuesto ya realizado, en la lista de presupuestos, abajo del todo pone "Crear otro presupuesto".
 Al darle escogeremos el nombre de un nuevo presupuesto y a�adiremos el mueble a dicho presupuesto.

-El email que se registre al registrarse como customer, assembler o critic, as� como el email del admin, 
es relevante, ya que hay ciertas acciones que implican que se env�e un correo electr�nico a la direcci�n 
de email que est� registrada en el sistema. Concretamente se env�an emails cuando: se acepta o deniega un 
cambio en una l�nea de presupuesto, se banea una cr�tica o se env�a un mensaje.