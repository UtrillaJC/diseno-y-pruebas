
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.ReviewRepository;
import domain.Assembler;
import domain.Assembly;
import domain.Furniture;
import domain.Maker;
import domain.Review;

@Service
@Transactional
public class ReviewService {

	//Managed Repository =============================================================================

	@Autowired
	private ReviewRepository	reviewRepository;

	//Supported Services =============================================================================

	@Autowired
	private AssemblerService	assemblerService;


	//Constructor methods ============================================================================

	public ReviewService() {
		super();
	}

	//Simple CRUD methods ============================================================================

	public Collection<Review> findAll() {
		Collection<Review> result;

		result = this.reviewRepository.findAll();

		return result;
	}

	public Review findOne(final int reviewId) {
		Review result;

		result = this.reviewRepository.findOne(reviewId);
		Assert.notNull(result);

		return result;
	}

	public Collection<Review> findReviewsByAssembler() {
		Collection<Review> result;
		Assembler principal;

		principal = this.assemblerService.findByPrincipal();
		Assert.isInstanceOf(Assembler.class, principal);

		result = principal.getReviews();

		return result;
	}

	public Collection<Review> findReviewsByMakerId(final int makerId) {
		Collection<Review> result;

		result = this.reviewRepository.findReviewsByMakerId(makerId);

		return result;
	}

	public Review create(final Maker maker) {
		Review result;
		Assembler principal;

		principal = this.assemblerService.findByPrincipal();

		for (final Furniture fm : maker.getFurnitures()) {
			final Assembly am = fm.getAssembly();
			final Boolean bool = principal.getAssemblies().contains(am);
			if (bool)
				break;
			else
				Assert.isTrue(bool);
		}

		Collection<Review> reviews = new ArrayList<Review>();

		result = new Review();
		result.setMaker(maker);
		result.setMoment(new Date(System.currentTimeMillis() - 10));

		result.setAssembler(principal);
		reviews = principal.getReviews();
		reviews.add(result);
		principal.setReviews(reviews);

		return result;
	}

	public Review save(final Review review) {
		Review result;
		Assembler principal;

		principal = this.assemblerService.findByPrincipal();
		Assert.isInstanceOf(Assembler.class, principal);

		result = this.reviewRepository.saveAndFlush(review);

		return result;
	}

	public void delete(final Review r) {
		Assert.notNull(r);

		this.reviewRepository.delete(r);

	}

}
