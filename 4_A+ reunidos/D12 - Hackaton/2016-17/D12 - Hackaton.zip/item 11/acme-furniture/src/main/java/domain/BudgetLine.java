
package domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Access(AccessType.PROPERTY)
@Table(indexes = {
	@Index(columnList = "pieceCode"), @Index(columnList = "furnitureCode"), @Index(columnList = "comment")
})
public class BudgetLine extends DomainEntity {

	// Constructors -----------------------------------------------------------

	public BudgetLine() {
		super();

	}


	// Attributes -------------------------------------------------------------

	private int		quantity;
	private String	furnitureCode;
	private String	pieceCode;
	private Double	piecePrice;
	private String	comment;


	@Min(1)
	public int getQuantity() {
		return this.quantity;
	}
	public void setQuantity(final int quantity) {
		this.quantity = quantity;
	}

	@NotBlank
	@Pattern(regexp = "\\d{6}-\\D{4}")
	public String getFurnitureCode() {
		return this.furnitureCode;
	}
	public void setFurnitureCode(final String furnitureCode) {
		this.furnitureCode = furnitureCode;
	}

	@NotBlank
	public String getPieceCode() {
		return this.pieceCode;
	}
	public void setPieceCode(final String pieceCode) {
		this.pieceCode = pieceCode;
	}

	@Digits(integer = 99, fraction = 2)
	public Double getPiecePrice() {
		return this.piecePrice;
	}
	public void setPiecePrice(final Double piecePrice) {
		this.piecePrice = piecePrice;
	}

	public String getComment() {
		return this.comment;
	}
	public void setComment(final String comment) {
		this.comment = comment;
	}


	// Relationships ----------------------------------------------------------

	private Budget		budget;
	private Acceptance	acceptance;


	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public Budget getBudget() {
		return this.budget;
	}

	public void setBudget(final Budget budget) {
		this.budget = budget;
	}

	@Valid
	@OneToOne(mappedBy = "budgetLine")
	public Acceptance getAcceptance() {
		return this.acceptance;
	}
	public void setAcceptance(final Acceptance acceptance) {
		this.acceptance = acceptance;
	}

}
