
package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.IncidenceRepository;
import domain.Customer;
import domain.Furniture;
import domain.Incidence;

@Service
@Transactional
public class IncidenceService {

	//Managed Repository =============================================================================

	@Autowired
	private IncidenceRepository		incidenceRepository;

	//Supported Services =============================================================================

	@Autowired
	private AdministratorService	administratorService;

	@Autowired
	private CustomerService			customerService;

	@Autowired
	private BudgetLineService		budgetLineService;


	//Constructor methods ============================================================================

	public IncidenceService() {
		super();
	}

	//Simple CRUD methods ============================================================================

	public Collection<Incidence> findAll() {
		Collection<Incidence> result;

		result = this.incidenceRepository.findAll();

		return result;
	}

	public Incidence findOne(final int incidenceId) {
		Incidence result;

		result = this.incidenceRepository.findOne(incidenceId);
		Assert.notNull(result);

		return result;
	}

	public Incidence create(final Furniture furniture) {
		Assert.notNull(furniture);
		Incidence result;
		Customer principal;

		principal = this.customerService.findByPrincipal();
		result = new Incidence();

		result.setCustomerName(principal.getName());
		result.setFurniture(furniture);

		return result;
	}

	public Incidence save(final Incidence incidence) {
		Assert.notNull(incidence);
		final Incidence result;
		Customer principal;
		Collection<String> furnitureCodes;

		principal = this.customerService.findByPrincipal();
		furnitureCodes = this.budgetLineService.findFurnitureCodeByCustomer(principal.getId());
		Assert.isTrue(furnitureCodes.contains(incidence.getFurniture().getCode()));
		Assert.isInstanceOf(Customer.class, principal);

		result = this.incidenceRepository.saveAndFlush(incidence);

		return result;
	}

	//Other Business Methods =========================================================================

	public Integer minIncidence() {
		this.administratorService.checkPrincipal();
		Integer min = this.incidenceRepository.minIncidence();
		if (min == null)
			min = 0;
		return min;
	}

	public Integer maxIncidence() {
		this.administratorService.checkPrincipal();
		Integer min = this.incidenceRepository.maxIncidence();
		if (min == null)
			min = 0;
		return min;
	}

	public Double avgIncidence() {
		this.administratorService.checkPrincipal();
		Double min = this.incidenceRepository.avgIncidence();
		if (min == null)
			min = 0.0;
		return min;
	}
}
