
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.BudgetLine;

@Repository
public interface BudgetLineRepository extends JpaRepository<BudgetLine, Integer> {

	@Query("select bl from BudgetLine bl where bl.pieceCode = ?1 and bl.budget.id = ?2")
	BudgetLine findByPieceCodeAndBudget(String code, int budgetId);

	@Query("select bl from BudgetLine bl where bl.furnitureCode = ?1")
	Collection<BudgetLine> findByFurnitureCode(String code);

	@Query("select bl.furnitureCode from BudgetLine bl where bl.budget.customer.id = ?1")
	Collection<String> findAllFurnitureCodeByCustomerId(int customerId);

	@Query("select bl from BudgetLine bl where bl.comment  is not null and bl.acceptance is empty")
	Collection<BudgetLine> findAllWithPendingAceptance();
	
	@Query("select bl from BudgetLine bl where bl.budget.id=?1 and bl.furnitureCode = ?2")
	Collection<BudgetLine> findByFurnitureAndBudget(int budgetId, String code);
}
