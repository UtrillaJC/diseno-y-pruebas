
package services;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Budget;
import domain.BudgetLine;
import domain.Customer;
import domain.Furniture;
import domain.Piece;
import repositories.BudgetRepository;

@Service
@Transactional
public class BudgetService {

	//Managed Repository =============================================================================

	@Autowired
	private BudgetRepository	budgetRepository;

	//Supported Services =============================================================================

	@Autowired
	private CustomerService		customerService;

	@Autowired
	private AdministratorService administratorService;
	
	@Autowired
	private BudgetLineService budgetLineService;
	
	@Autowired
	private FurnitureService furnitureService;


	//Constructor methods ============================================================================

	public BudgetService() {
		super();
	}

	//Simple CRUD methods ============================================================================

	public Budget create(String name) {
		final Budget result;
		Assert.notNull(name);
		Customer principal;
		Date moment;
		Collection<BudgetLine> budgetLines;
	//	final Double totalPrice;

		principal = this.customerService.findByPrincipal();
		Assert.notNull(principal);
		Assert.isInstanceOf(Customer.class, principal);
		moment = new Date(System.currentTimeMillis());
		budgetLines = new HashSet<BudgetLine>();
//		totalPrice = 0.0;

		result = new Budget();
		result.setName(name);
		result.setCustomer(principal);
		result.setMoment(moment);
		result.setBudgetLines(budgetLines);
		//result.setTotalPrice(totalPrice);
		return result;

	}

	public Budget save(final Budget budget) {
		final Budget result;
		Date moment;

		moment = new Date(System.currentTimeMillis() - 1000);

		if (budget.getId() == 0)
			budget.setMoment(moment);

		result = this.budgetRepository.saveAndFlush(budget);

		return result;

	}

	//Other Business Methods =========================================================================

	public Collection<Budget> findAllByCustomer(final int customerId) {
		final Collection<Budget> result;
		final Customer principal;

		principal = this.customerService.findByPrincipal();
		Assert.isTrue(customerId == principal.getId());

		result = this.budgetRepository.findAllByCustomer(customerId);

		return result;

	}

	public Collection<Budget> findByPrincipal() {
		
		final Customer principal;
		principal = this.customerService.findByPrincipal();
		return budgetRepository.findAllByCustomer(principal.getId());
	}

	public Budget findOne(int budgetId) {
		
		return budgetRepository.findOne(budgetId);
	}

	public Collection<BudgetLine> add(Budget budget, int furnitureId, int quantity) {
		Assert.isTrue(budget.getCustomer().equals(customerService.findByPrincipal()));
		if(budget.getId()==0){
			budget = save(budget);
		}
		Furniture f = furnitureService.findOne(furnitureId);
		Collection<BudgetLine> res = new HashSet<BudgetLine>();
		Collection<BudgetLine> bls = budget.getBudgetLines();
		for(Piece p:f.getPieces()){
		BudgetLine bl = budgetLineService.findByPieceCodeAndBudget(p.getCode(), budget.getId());
		if(bl == null){
		bl =  budgetLineService.create();
		bl.setBudget(budget);
		bl.setFurnitureCode(f.getCode());
		bl.setPieceCode(p.getCode());
		bl.setPiecePrice(p.getPrice());
		bl.setQuantity(quantity);
		BudgetLine savedBl = budgetLineService.save(bl);
		bls.add(savedBl);
		res.add(savedBl);
		}else{
			bl.setQuantity(bl.getQuantity()+quantity);
		}
				
		}
		budget.setBudgetLines(bls);
		save(budget);
		return res;
		
	}
	
	public Integer minBudgetsByCustomer() {
		administratorService.checkPrincipal();
		Integer min = this.budgetRepository.minBudgetsByCustomer();
		if (min == null)
			min = 0;
		return min;
	}

	public Integer maxBudgetsByCustomer() {
		administratorService.checkPrincipal();
		Integer min = this.budgetRepository.maxBudgetsByCustomer();
		if (min == null)
			min = 0;
		return min;
	}

	public Double avgBudgetsByCustomer() {
		administratorService.checkPrincipal();
		Double min = this.budgetRepository.avgBudgetsByCustomer();
		if (min == null)
			min = 0.0;
		return min;
	}

}
