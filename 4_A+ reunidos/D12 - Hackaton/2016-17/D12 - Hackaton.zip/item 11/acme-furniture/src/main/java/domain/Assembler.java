
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Entity
@Access(AccessType.PROPERTY)
public class Assembler extends Actor {

	//Constructors====================================================================================

	public Assembler() {
		super();
	}


	//Relationships --------------------------------------------------------------------------------

	private Collection<Assembly>	assemblies;
	private Collection<Review>		reviews;


	@NotNull
	@Valid
	@OneToMany(mappedBy = "assembler")
	public Collection<Review> getReviews() {
		return this.reviews;
	}

	public void setReviews(final Collection<Review> reviews) {
		this.reviews = reviews;
	}

	@NotNull
	@Valid
	@OneToMany(mappedBy = "assembler")
	public Collection<Assembly> getAssemblies() {
		return this.assemblies;
	}

	public void setAssemblies(final Collection<Assembly> assemblies) {
		this.assemblies = assemblies;
	}

}
