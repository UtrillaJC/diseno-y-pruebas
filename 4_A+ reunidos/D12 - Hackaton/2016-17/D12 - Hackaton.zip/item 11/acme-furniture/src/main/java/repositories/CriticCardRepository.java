package repositories;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.CriticCard;

@Repository  
public interface CriticCardRepository extends JpaRepository<CriticCard, Integer> {

	@Query("select cr from CriticCard cr where cr.critic.id = ?1")
	CriticCard findCriticCardByCritic(int criticId);


}