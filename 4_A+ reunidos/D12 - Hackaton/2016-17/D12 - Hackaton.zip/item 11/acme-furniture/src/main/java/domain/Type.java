package domain;

public enum Type {
	
	POSITIVE, NEUTRAL, NEGATIVE

}
