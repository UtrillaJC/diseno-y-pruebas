
package domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Range;

@Entity
@Access(AccessType.PROPERTY)
public class Rating extends DomainEntity {

	// Constructors -----------------------------------------------------------

	public Rating() {
		super();

	}


	// Attributes -------------------------------------------------------------

	//	private String	actorName;
	private int		stars;
	private String	comment;


	//	@NotBlank
	//	public String getActorName() {
	//		return actorName;
	//	}
	//	public void setActorName(String actorName) {
	//		this.actorName = actorName;
	//	}

	@NotNull
	@Range(min = 0, max = 5)
	public int getStars() {
		return this.stars;
	}
	public void setStars(final int stars) {
		this.stars = stars;
	}

	public String getComment() {
		return this.comment;
	}
	public void setComment(final String comment) {
		this.comment = comment;
	}


	// Relationships ----------------------------------------------------------

	private Customer	customer;
	private Assembler	assembler;
	private Furniture	furniture;


	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public Furniture getFurniture() {
		return this.furniture;
	}

	public void setFurniture(final Furniture furniture) {
		this.furniture = furniture;
	}
	@Valid
	@ManyToOne(optional = true)
	public Assembler getAssembler() {
		return this.assembler;
	}

	public void setAssembler(final Assembler assembler) {
		this.assembler = assembler;
	}

	@Valid
	@ManyToOne(optional = true)
	public Customer getCustomer() {
		return this.customer;
	}
	public void setCustomer(final Customer customer) {
		this.customer = customer;
	}

}
