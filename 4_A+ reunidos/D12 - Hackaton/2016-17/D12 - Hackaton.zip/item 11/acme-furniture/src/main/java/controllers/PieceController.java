
package controllers;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.PieceService;
import domain.Piece;

@Controller
@RequestMapping("/piece")
public class PieceController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private PieceService	pieceService;


	// Constructors ========================================================================

	public PieceController() {
		super();
	}

	//List events available and less month ========================================================================================

	@RequestMapping(value = "/listByFurniture", method = RequestMethod.GET)
	public ModelAndView listFurniture(@RequestParam final int furnitureId) {
		ModelAndView result;
		Collection<Piece> pieces;

		pieces = this.pieceService.findAllByFurniture(furnitureId);
		result = new ModelAndView("piece/listByFurniture");

		result.addObject("pieces", pieces);
		result.addObject("requestURI", "piece/listByFurniture.do");

		return result;
	}

}
