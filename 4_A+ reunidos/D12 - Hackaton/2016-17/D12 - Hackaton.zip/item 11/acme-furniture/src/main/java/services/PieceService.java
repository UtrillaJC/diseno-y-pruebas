
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.PieceRepository;
import domain.Back;
import domain.Furniture;
import domain.Piece;

@Service
@Transactional
public class PieceService {

	//Managed Repository =============================================================================

	@Autowired
	private PieceRepository			pieceRepository;

	//Supported Services =============================================================================
	@Autowired
	private FurnitureService		furnitureService;

	@Autowired
	private AdministratorService	administratorService;


	//Constructor methods ============================================================================

	public PieceService() {
		super();
	}

	//Simple CRUD methods ============================================================================
	public Collection<Piece> findAll() {
		Collection<Piece> result;

		result = this.pieceRepository.findAll();

		return result;
	}

	public Piece create(final int furnitureId) {

		final Furniture furniture = this.furnitureService.findOne(furnitureId);
		Assert.notNull(furniture);
		Collection<Back> backs;

		backs = new ArrayList<Back>();

		final Piece result = new Piece();

		result.setCode(this.generateCode());
		result.setFurniture(furniture);
		result.setBacks(backs);

		return result;

	}

	public void delete(final Piece piece) {
		Assert.notNull(piece);
		this.administratorService.checkPrincipal();
		piece.getFurniture().setPrice(piece.getFurniture().getPrice() - piece.getPrice());

		this.pieceRepository.delete(piece);

	}

	//Other Business Methods =========================================================================

	public Piece findOne(final int pieceId) {
		Piece result;

		result = this.pieceRepository.findOne(pieceId);
		Assert.notNull(result);

		return result;
	}

	public Collection<Piece> findAllByFurniture(final int furnitureId) {
		Collection<Piece> result;

		result = this.pieceRepository.findAllByFurnitureId(furnitureId);

		return result;
	}

	public String generateCode() {
		String result = null;
		List<String> codes;
		String lastCode;
		String[] parts;
		String temp;
		Integer num;

		temp = "";

		codes = this.pieceRepository.searchLastCode();

		if (codes.isEmpty() || codes.equals(null))
			lastCode = "000000-AAAA";
		else
			lastCode = codes.get(0);
		parts = lastCode.split("-");

		if (codes.isEmpty() || codes.equals(null))
			result = "000000-AAAA";
		else if (parts[0].equals("999999")) {
			if (parts[0].toUpperCase().charAt(3) == 'Z')
				temp = String.valueOf(parts[0].charAt(0)) + String.valueOf(parts[0].charAt(1)) + String.valueOf((char) (parts[0].charAt(2) + 1)) + String.valueOf((char) (parts[0].charAt(3) + 1));
			else if (parts[0].toUpperCase().charAt(2) == 'Z' && parts[0].toUpperCase().charAt(3) == 'Z')
				temp = String.valueOf(parts[0].charAt(0)) + String.valueOf((char) (parts[0].charAt(1) + 1)) + String.valueOf((char) (parts[0].charAt(2) + 1)) + String.valueOf((char) (parts[0].charAt(3) + 1));
			else if (parts[0].toUpperCase().charAt(1) == 'Z' && parts[0].toUpperCase().charAt(2) == 'Z' && parts[0].toUpperCase().charAt(3) == 'Z')
				temp = String.valueOf(parts[0].charAt(0) + 1) + String.valueOf((char) (parts[0].charAt(1) + 1)) + String.valueOf((char) (parts[0].charAt(2) + 1)) + String.valueOf((char) (parts[0].charAt(3) + 1));
			else if (parts[0].toUpperCase().charAt(0) == 'Z' && parts[0].toUpperCase().charAt(1) == 'Z' && parts[0].toUpperCase().charAt(2) == 'Z' && parts[0].toUpperCase().charAt(3) == 'Z')
				temp = "AAAA";
			else
				temp = String.valueOf(parts[0].charAt(0)) + String.valueOf(parts[0].charAt(1)) + String.valueOf(parts[0].charAt(2)) + String.valueOf((char) (parts[0].charAt(3) + 1));
			result = "000000-" + temp.toUpperCase();
		} else {
			num = Integer.valueOf(parts[0]);
			num += 1;
			temp = String.valueOf(num);
			if (temp.length() != 6)
				while (temp.length() != 6)
					temp = "0" + temp;
			result = temp + "-" + parts[1].toUpperCase();
		}

		Assert.isTrue(!codes.contains(result));

		return result;
	}

	public Piece save(final Piece piece) {
		Assert.notNull(piece);
		this.administratorService.checkPrincipal();

		final Double price = piece.getFurniture().getPrice() + piece.getPrice();

		piece.getFurniture().setPrice(price);

		return this.pieceRepository.saveAndFlush(piece);

	}

	public Piece update(final Piece piece) {
		Assert.notNull(piece);

		Piece pieceUpddate;

		this.administratorService.checkPrincipal();

		pieceUpddate = this.pieceRepository.saveAndFlush(piece);

		final Collection<Piece> pieces = piece.getFurniture().getPieces();
		Double priceFurniture = 0.0;

		for (final Piece p : pieces)
			priceFurniture = priceFurniture + p.getPrice();

		pieceUpddate.getFurniture().setPrice(priceFurniture);

		return pieceUpddate;

	}

}
