package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.Maker;

@Component
@Transactional
public class MakerToStringConverter implements Converter<Maker, String>{
	
	@Override
	public String convert(Maker maker){
		String result;
		
		if(maker == null)
			result = null;
		else
			result = String.valueOf(maker.getId());
		
		return result;
	}

}
