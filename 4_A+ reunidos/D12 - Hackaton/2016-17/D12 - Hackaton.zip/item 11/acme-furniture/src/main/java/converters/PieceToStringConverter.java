package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.Piece;

@Component
@Transactional
public class PieceToStringConverter implements Converter<Piece, String>{
	
	@Override
	public String convert(Piece piece){
		String result;
		
		if(piece == null)
			result = null;
		else
			result = String.valueOf(piece.getId());
		
		return result;
	}

}
