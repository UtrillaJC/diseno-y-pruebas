
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.CritiqueRepository;
import domain.Administrator;
import domain.Critic;
import domain.Critique;
import domain.Customer;
import domain.Furniture;

@Service
@Transactional
public class CritiqueService {

	//Managed Repository =============================================================================

	@Autowired
	private CritiqueRepository		critiqueRepository;

	//Supported Services =============================================================================

	@Autowired
	private CriticService			criticService;

	@Autowired
	private FurnitureService		furnitureService;

	@Autowired
	private CustomerService			customerService;

	@Autowired
	private AdministratorService	administratorService;


	//Constructor methods ============================================================================

	public CritiqueService() {
		super();
	}

	//Simple CRUD methods ============================================================================

	public Collection<Critique> findAll() {
		Collection<Critique> result;

		result = this.critiqueRepository.findAll();

		return result;
	}

	public Critique findOne(final int critiqueId) {
		Critique result;

		result = this.critiqueRepository.findOne(critiqueId);

		return result;
	}

	public Collection<Critique> findCritiquesByCritic() {
		Collection<Critique> result;
		Critic principal;

		principal = this.criticService.findByPrincipal();
		result = this.critiqueRepository.findCritiquesByCritic(principal.getId());

		return result;
	}

	public Critique create(final int furnitureId) {
		Critique result;
		Critic principal;
		Date momentActual;
		final Furniture furniture = this.furnitureService.findOne(furnitureId);

		principal = this.criticService.findByPrincipal();
		momentActual = new Date(System.currentTimeMillis() - 1000);
		result = new Critique();
		final Collection<Critic> critics = new ArrayList<Critic>();

		result.setMoment(momentActual);
		result.setCritic(principal);
		result.setBanned(false);
		result.setFurniture(furniture);
		result.setFair(0);
		result.setUnfair(0);
		result.setCritics(critics);

		return result;
	}

	public Critique save(final Critique critique) {
		Critique result;
		Critic principal;

		principal = this.criticService.findByPrincipal();
		Assert.isInstanceOf(Critic.class, principal);
		Assert.isTrue(principal.getCriticCard() != null);

		result = this.critiqueRepository.saveAndFlush(critique);

		final Furniture furniture = result.getFurniture();
		final Collection<Critique> critiques = furniture.getCritiques();
		critiques.add(result);
		furniture.setCritiques(critiques);

		return result;
	}

	public Critique update(final Critique critique) {
		Critique result;
		final Critic principal = this.criticService.findByPrincipal();

		Assert.isInstanceOf(Critic.class, principal);
		Assert.isTrue(principal.equals(critique.getCritic()));

		result = this.critiqueRepository.saveAndFlush(critique);
		return result;
	}

	public void delete(final Critique critique) {
		Assert.notNull(critique);
		Critic principal;

		principal = this.criticService.findByPrincipal();
		Assert.isInstanceOf(Critic.class, principal);
		Assert.isTrue(principal.equals(critique.getCritic()));

		this.critiqueRepository.delete(critique);

	}

	//Other Business Methods =========================================================================

	public Collection<Critique> findAllExceptMine() {
		Critic principal;
		principal = this.criticService.findByPrincipal();
		Assert.isInstanceOf(Critic.class, principal);

		Collection<Critique> result;
		final Collection<Critique> mine = principal.getCritiques();

		result = this.findAll();
		result.removeAll(mine);

		return result;
	}

	public void fair(final Critique critique) {
		Critic principal;
		principal = this.criticService.findByPrincipal();
		final Collection<Critique> voted = principal.getVotedCritiques();
		final Collection<Critic> critics = critique.getCritics();
		Assert.isInstanceOf(Critic.class, principal);
		Assert.isTrue(!principal.equals(critique.getCritic()));
		Assert.isTrue(!voted.contains(critique));

		Integer fair = critique.getFair();
		fair++;
		critique.setFair(fair);

		voted.add(critique);
		critics.add(principal);
		principal.setVotedCritiques(voted);
		critique.setCritics(critics);
	}

	public void unfair(final Critique critique) {
		Critic principal;
		principal = this.criticService.findByPrincipal();
		final Collection<Critique> voted = principal.getVotedCritiques();
		final Collection<Critic> critics = critique.getCritics();
		Assert.isInstanceOf(Critic.class, principal);
		Assert.isTrue(!principal.equals(critique.getCritic()));
		Assert.isTrue(!voted.contains(critique));

		Integer unfair = critique.getUnfair();
		unfair++;
		critique.setUnfair(unfair);

		voted.add(critique);
		critics.add(principal);
		principal.setVotedCritiques(voted);
		critique.setCritics(critics);
	}

	public void ban(final Critique critique) {
		Administrator principal;
		principal = this.administratorService.findByPrincipal();
		Assert.isInstanceOf(Administrator.class, principal);
		Assert.isTrue(critique.isBanned() == false);

		critique.setBanned(true);

		final EmailService emailService = new EmailService();
		//Mensaje para emisor

		final String asunto = "Cr�tica baneada";
		final String cuerpo = "La cr�tica que realiz� al mueble con c�digo " + critique.getFurniture().getCode() + " ha sido baneada.";

		try {
			emailService.sendEmail(critique.getCritic().getEmail(), asunto, cuerpo);
		} catch (final Exception e) {
			e.printStackTrace();
			System.out.println("Fallo al enviar el email");
		}
	}

	public void unban(final Critique critique) {
		Administrator principal;
		principal = this.administratorService.findByPrincipal();
		Assert.isInstanceOf(Administrator.class, principal);
		Assert.isTrue(critique.isBanned() == true);

		critique.setBanned(false);
	}

	public Collection<Critique> findByFurnitureId(final int furnitureId) {
		Collection<Critique> result;
		Furniture furniture;
		Customer principal;

		principal = this.customerService.findByPrincipal();
		Assert.isInstanceOf(Customer.class, principal);
		furniture = this.furnitureService.findOne(furnitureId);
		result = furniture.getCritiques();
		return result;
	}

	public Integer minCritique() {
		this.administratorService.checkPrincipal();
		Integer min = this.critiqueRepository.minCritique();
		if (min == null)
			min = 0;
		return min;
	}

	public Integer maxCritique() {
		this.administratorService.checkPrincipal();
		Integer min = this.critiqueRepository.maxCritique();
		if (min == null)
			min = 0;
		return min;
	}

	public Double avgCritique() {
		this.administratorService.checkPrincipal();
		Double min = this.critiqueRepository.avgCritique();
		if (min == null)
			min = 0.0;
		return min;
	}

}
