package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.Acceptance;

@Component
@Transactional
public class AcceptanceToStringConverter implements Converter<Acceptance, String>{
	
	@Override
	public String convert(Acceptance acceptance){
		String result;
		
		if(acceptance == null)
			result = null;
		else
			result = String.valueOf(acceptance.getId());
		
		return result;
	}

}
