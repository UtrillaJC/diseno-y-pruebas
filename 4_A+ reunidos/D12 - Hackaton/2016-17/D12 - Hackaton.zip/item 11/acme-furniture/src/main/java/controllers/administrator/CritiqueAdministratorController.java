
package controllers.administrator;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.CritiqueService;
import controllers.AbstractController;
import domain.Critique;

@Controller
@RequestMapping("/critique/administrator")
public class CritiqueAdministratorController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private CritiqueService	critiqueService;


	// Constructors ========================================================================

	public CritiqueAdministratorController() {
		super();
	}

	//List ========================================================================================

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Critique> critiques;

		critiques = this.critiqueService.findAll();

		result = new ModelAndView("critique/administrator/list");

		result.addObject("critiques", critiques);
		result.addObject("requestURI", "critique/administrator/list.do");

		return result;
	}

	//Ban -----------------------------------------------------------------------------------------

	@RequestMapping(value = "/ban", method = RequestMethod.GET)
	public ModelAndView ban(@RequestParam final int critiqueId) {
		ModelAndView result;
		final Critique critique = this.critiqueService.findOne(critiqueId);

		try {
			this.critiqueService.ban(critique);
			result = this.list();
			result.addObject("messageOk", "ban.commit.ok");
		} catch (final Throwable oops) {
			result = this.list();
			result.addObject("message", "ban.commit.error");
		}

		return result;
	}

	@RequestMapping(value = "/unban", method = RequestMethod.GET)
	public ModelAndView unban(@RequestParam final int critiqueId) {
		ModelAndView result;
		final Critique critique = this.critiqueService.findOne(critiqueId);

		try {
			this.critiqueService.unban(critique);
			result = this.list();
			result.addObject("messageOk", "unban.commit.ok");
		} catch (final Throwable oops) {
			result = this.list();
			result.addObject("message", "unban.commit.error");
		}

		return result;
	}

}
