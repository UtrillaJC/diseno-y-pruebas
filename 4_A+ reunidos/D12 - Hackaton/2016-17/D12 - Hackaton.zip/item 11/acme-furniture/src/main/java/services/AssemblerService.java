
package services;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.AssemblerRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;
import domain.Assembler;
import domain.Assembly;
import domain.Folder;
import domain.Message;
import domain.Review;
import forms.RegistrationForm;

@Service
@Transactional
public class AssemblerService {

	//Managed Repository =============================================================================

	@Autowired
	private AssemblerRepository	assemblerRepository;

	//Supported Services =============================================================================
	@Autowired
	private FolderService		folderService;


	//Constructor methods ============================================================================

	public AssemblerService() {
		super();
	}

	//Simple CRUD methods ============================================================================
	public Assembler create() {

		final Assembler a = new Assembler();
		final UserAccount ua = new UserAccount();
		Collection<Assembly> assemblies;
		final Collection<Review> reviews;
		Collection<Folder> folders;
		Collection<Message> sentMessages;
		Collection<Message> receivedMessages;

		ua.setUsername("");
		ua.setPassword("");
		assemblies = new ArrayList<Assembly>();
		folders = new ArrayList<Folder>();
		sentMessages = new ArrayList<Message>();
		receivedMessages = new ArrayList<Message>();
		reviews = new ArrayList<Review>();

		final Authority auth = new Authority();
		auth.setAuthority("ASSEMBLER");

		ua.addAuthority(auth);
		a.setUserAccount(ua);
		a.setAssemblies(assemblies);
		a.setReceivedMessages(receivedMessages);
		a.setSentMessages(sentMessages);
		a.setFolders(folders);
		a.setReviews(reviews);

		return a;
	}

	public Assembler reconstruct(final RegistrationForm arf) {

		final Assembler a = this.create();

		a.getUserAccount().setUsername(arf.getUsername());
		a.getUserAccount().setPassword(arf.getPassword());

		a.setName(arf.getName());
		a.setSurname(arf.getSurname());
		a.setEmail(arf.getEmail());
		a.setPhone(arf.getPhone());
		a.setAddress(arf.getAddress());

		return a;
	}

	public Assembler save(final Assembler a) {
		Assembler result;
		final UserAccount ua = a.getUserAccount();
		final Md5PasswordEncoder md5PasswordEncoder = new Md5PasswordEncoder();
		final String pass = md5PasswordEncoder.encodePassword(ua.getPassword(), null);
		ua.setPassword(pass);
		a.setUserAccount(ua);

		result = this.assemblerRepository.saveAndFlush(a);
		this.folderService.createDefaultFolders(result);

		return result;
	}
	//Other Business Methods =========================================================================

	public Assembler findByPrincipal() {
		Assembler result;
		UserAccount userAccount;

		userAccount = LoginService.getPrincipal();
		Assert.notNull(userAccount);
		result = this.findByUserAccount(userAccount);
		Assert.notNull(result);

		return result;
	}

	public Assembler findByUserAccount(final UserAccount userAccount) {
		Assembler result;

		result = this.assemblerRepository.findByUserAccountId(userAccount.getId());

		return result;
	}
}
