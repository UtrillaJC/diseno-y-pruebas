
package controllers.administrator;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.BudgetLineService;
import controllers.AbstractController;
import domain.BudgetLine;

@Controller
@RequestMapping("/budgetLine/administrator")
public class BudgetLineAdministratorController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private BudgetLineService	budgetLineService;


	// Constructors ========================================================================

	public BudgetLineAdministratorController() {
		super();
	}

	//List my critiques ========================================================================================

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		final Collection<BudgetLine> budgetLines = this.budgetLineService.findAllWithPendingAceptance();

		result = new ModelAndView("/budgetLine/customer/list");

		result.addObject("budgetsLines", budgetLines);
		result.addObject("requestURI", "budgetLine/administrator/list.do");

		return result;
	}

	@RequestMapping(value = "/accept", method = RequestMethod.GET)
	public ModelAndView accept(@RequestParam final int blId) {

		final ModelAndView result = new ModelAndView("redirect:list.do");
		try {
			this.budgetLineService.accept(blId);
		} catch (final Exception e) {
			result.addObject("acceptError", true);
		}

		return result;
	}
	@RequestMapping(value = "/denny", method = RequestMethod.GET)
	public ModelAndView denny(@RequestParam final int blId) {

		final ModelAndView result = new ModelAndView("redirect:list.do");
		try {
			this.budgetLineService.deny(blId);
		} catch (final Exception e) {
			result.addObject("acceptError", true);
		}

		return result;
	}
}
