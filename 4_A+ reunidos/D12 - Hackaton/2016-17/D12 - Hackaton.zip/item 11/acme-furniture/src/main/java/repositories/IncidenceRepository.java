package repositories;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Incidence;

@Repository  
public interface IncidenceRepository extends JpaRepository<Incidence, Integer> {

	@Query("select min(f.incidences.size) from Furniture f")
	Integer minIncidence();	
	
	@Query("select avg(f.incidences.size) from Furniture f")
	Double avgIncidence();	
	
	@Query("select max(f.incidences.size) from Furniture f")
	Integer maxIncidence();	
}