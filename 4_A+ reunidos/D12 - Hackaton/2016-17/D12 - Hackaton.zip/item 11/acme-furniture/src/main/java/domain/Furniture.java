
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.URL;

@Entity
@Access(AccessType.PROPERTY)
public class Furniture extends DomainEntity {

	// Constructors -----------------------------------------------------------

	public Furniture() {
		super();

	}


	// Attributes -------------------------------------------------------------

	private String	code;
	private String	type;
	private double	height;
	private double	width;
	private double	depth;
	private String	picture;
	private Double	price;


	@NotBlank
	@Column(unique = true)
	@Pattern(regexp = "\\d{6}-\\D{4}")
	public String getCode() {
		return this.code;
	}
	public void setCode(final String code) {
		this.code = code;
	}

	@NotBlank
	public String getType() {
		return this.type;
	}
	public void setType(final String type) {
		this.type = type;
	}

	@Min(0)
	public double getHeight() {
		return this.height;
	}
	public void setHeight(final double height) {
		this.height = height;
	}

	@Min(0)
	public double getWidth() {
		return this.width;
	}
	public void setWidth(final double width) {
		this.width = width;
	}

	@Min(0)
	public double getDepth() {
		return this.depth;
	}
	public void setDepth(final double depth) {
		this.depth = depth;
	}

	@NotBlank
	@URL
	public String getPicture() {
		return this.picture;
	}
	public void setPicture(final String picture) {
		this.picture = picture;
	}

	@Digits(integer = 99, fraction = 2)
	@Min(0)
	@NotNull
	public Double getPrice() {
		return this.price;
	}
	public void setPrice(final Double price) {
		this.price = price;
	}


	// Relationships ----------------------------------------------------------

	private Assembly				assembly;
	private Collection<Critique>	critiques;
	private Collection<Incidence>	incidences;
	private Collection<Piece>		pieces;
	private Maker					maker;
	private Collection<Rating>		ratings;


	@NotNull
	@Valid
	@OneToMany(mappedBy = "furniture")
	public Collection<Rating> getRatings() {
		return this.ratings;
	}

	public void setRatings(final Collection<Rating> ratings) {
		this.ratings = ratings;
	}
	@Valid
	@OneToOne(cascade = CascadeType.REMOVE, optional = true, mappedBy = "furniture")
	public Assembly getAssembly() {
		return this.assembly;
	}

	public void setAssembly(final Assembly assembly) {
		this.assembly = assembly;
	}
	@Valid
	@NotNull
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "furniture")
	public Collection<Critique> getCritiques() {
		return this.critiques;
	}
	public void setCritiques(final Collection<Critique> critiques) {
		this.critiques = critiques;
	}

	@Valid
	@NotNull
	@OneToMany(cascade = CascadeType.REMOVE, mappedBy = "furniture")
	public Collection<Incidence> getIncidences() {
		return this.incidences;
	}
	public void setIncidences(final Collection<Incidence> incidences) {
		this.incidences = incidences;
	}

	@Valid
	@NotNull
	@OneToMany(cascade = CascadeType.REMOVE, mappedBy = "furniture")
	public Collection<Piece> getPieces() {
		return this.pieces;
	}
	public void setPieces(final Collection<Piece> pieces) {
		this.pieces = pieces;
	}

	@Valid
	@NotNull
	@ManyToOne(optional = false)
	public Maker getMaker() {
		return this.maker;
	}
	public void setMaker(final Maker maker) {
		this.maker = maker;
	}

}
