
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.FurnitureRepository;
import domain.Administrator;
import domain.Assembler;
import domain.Assembly;
import domain.Critique;
import domain.Customer;
import domain.Furniture;
import domain.Incidence;
import domain.Piece;
import domain.Rating;

@Service
@Transactional
public class FurnitureService {

	//Managed Repository =============================================================================

	@Autowired
	private FurnitureRepository		furnitureRepository;

	//Supported Services =============================================================================

	@Autowired
	private AssemblerService		assemblerService;

	@Autowired
	private AdministratorService	administratorService;

	@Autowired
	private CustomerService			customerService;

	@Autowired
	private RatingService			ratingService;


	//Constructor methods ============================================================================

	public FurnitureService() {
		super();
	}

	//Simple CRUD methods ============================================================================

	public Collection<Furniture> findAll() {
		Collection<Furniture> result;

		result = this.furnitureRepository.findAll();

		return result;
	}

	public Furniture findOne(final int furnitureId) {
		Furniture result;

		result = this.furnitureRepository.findOne(furnitureId);
		Assert.notNull(result);

		return result;
	}

	public Furniture create() {
		final Furniture result;
		String code;
		Double price;

		this.administratorService.checkPrincipal();

		final Collection<Critique> critiques = new ArrayList<Critique>();
		final Collection<Incidence> incidences = new ArrayList<Incidence>();
		final Collection<Piece> pieces = new ArrayList<Piece>();
		final Collection<Rating> ratings = new ArrayList<Rating>();

		code = this.generateCode();
		price = 0.0;

		result = new Furniture();

		result.setCode(code);
		result.setPrice(price);
		result.setCritiques(critiques);
		result.setIncidences(incidences);
		result.setPieces(pieces);
		result.setRatings(ratings);

		return result;

	}

	public Furniture save(final Furniture furniture) {
		Assert.notNull(furniture);
		final Furniture result;
		Administrator principal;

		principal = this.administratorService.findByPrincipal();
		Assert.isInstanceOf(Administrator.class, principal);

		result = this.furnitureRepository.saveAndFlush(furniture);

		return result;

	}

	public void delete(final Furniture furniture) {
		Assert.notNull(furniture);

		this.administratorService.checkPrincipal();
		Collection<Rating> ratings = new ArrayList<Rating>();
		ratings = this.ratingService.findRatingsByFurnitureId(furniture.getId());

		if (!ratings.isEmpty())
			for (final Rating r : ratings)
				this.ratingService.delete(r);

		this.furnitureRepository.delete(furniture);

	}
	//Other Business Methods =========================================================================

	public Collection<Furniture> findNotAssembled() {
		Collection<Furniture> result;
		Assembler principal;

		principal = this.assemblerService.findByPrincipal();
		Assert.isInstanceOf(Assembler.class, principal);
		result = this.findAll();

		final Iterator<Furniture> iter = result.iterator();

		while (iter.hasNext()) {
			final Furniture f = iter.next();

			if (f.getAssembly() != null)
				iter.remove();
		}

		return result;
	}

	public Collection<Furniture> findAssembledByMe() {
		Collection<Furniture> result;
		Assembler principal;

		result = new ArrayList<Furniture>();
		principal = this.assemblerService.findByPrincipal();
		Assert.isInstanceOf(Assembler.class, principal);
		final Collection<Assembly> assemblies = principal.getAssemblies();

		for (final Assembly a : assemblies)
			result.add(a.getFurniture());

		return result;
	}

	public Collection<Furniture> findAllByCustomer() {
		final Collection<Furniture> result;
		Customer principal;

		principal = this.customerService.findByPrincipal();
		Assert.notNull(principal);
		Assert.isInstanceOf(Customer.class, principal);

		result = this.furnitureRepository.findAllByCustomer(principal.getId());

		return result;
	}

	public String generateCode() {
		String result = null;
		List<String> codes;
		String lastCode;
		String[] parts;
		String temp;
		Integer num;

		temp = "";

		codes = this.furnitureRepository.searchLastCode();

		if (codes.isEmpty() || codes.equals(null))
			lastCode = "000000-AAAA";
		else
			lastCode = codes.get(0);
		parts = lastCode.split("-");

		if (codes.isEmpty() || codes.equals(null))
			result = "000000-AAAA";
		else if (parts[0].equals("999999")) {
			if (parts[0].toUpperCase().charAt(3) == 'Z')
				temp = String.valueOf(parts[0].charAt(0)) + String.valueOf(parts[0].charAt(1)) + String.valueOf((char) (parts[0].charAt(2) + 1)) + String.valueOf((char) (parts[0].charAt(3) + 1));
			else if (parts[0].toUpperCase().charAt(2) == 'Z' && parts[0].toUpperCase().charAt(3) == 'Z')
				temp = String.valueOf(parts[0].charAt(0)) + String.valueOf((char) (parts[0].charAt(1) + 1)) + String.valueOf((char) (parts[0].charAt(2) + 1)) + String.valueOf((char) (parts[0].charAt(3) + 1));
			else if (parts[0].toUpperCase().charAt(1) == 'Z' && parts[0].toUpperCase().charAt(2) == 'Z' && parts[0].toUpperCase().charAt(3) == 'Z')
				temp = String.valueOf(parts[0].charAt(0) + 1) + String.valueOf((char) (parts[0].charAt(1) + 1)) + String.valueOf((char) (parts[0].charAt(2) + 1)) + String.valueOf((char) (parts[0].charAt(3) + 1));
			else if (parts[0].toUpperCase().charAt(0) == 'Z' && parts[0].toUpperCase().charAt(1) == 'Z' && parts[0].toUpperCase().charAt(2) == 'Z' && parts[0].toUpperCase().charAt(3) == 'Z')
				temp = "AAAA";
			else
				temp = String.valueOf(parts[0].charAt(0)) + String.valueOf(parts[0].charAt(1)) + String.valueOf(parts[0].charAt(2)) + String.valueOf((char) (parts[0].charAt(3) + 1));
			result = "000000-" + temp.toUpperCase();
		} else {
			num = Integer.valueOf(parts[0]);
			num += 1;
			temp = String.valueOf(num);
			if (temp.length() != 6)
				while (temp.length() != 6)
					temp = "0" + temp;
			result = temp + "-" + parts[1].toUpperCase();
		}

		Assert.isTrue(!codes.contains(result));

		return result;
	}

	public Furniture findByCode(final String code) {

		return this.furnitureRepository.findByCode(code);
	}
	
	public Collection<Object[]> furnitureOrderByRatingsString() {
		administratorService.checkPrincipal();

		return this.furnitureRepository.furnitureOrderByRatingsString();
	}	

	//	public double averageRatingsPerFurniture(final Furniture furniture) {
	//		double result = 0.;
	//		int aux = 0;
	//
	//		final Collection<Rating> ratings = this.ratingService.findRatingsByFurnitureId(furniture.getId());
	//		if (ratings.size() != 0) {
	//			for (final Rating r : ratings)
	//				aux += (r.getStars());
	//			result = aux / ratings.size();
	//		} else
	//			result = 0.;
	//
	//		return result;
	//
	//	}
}
