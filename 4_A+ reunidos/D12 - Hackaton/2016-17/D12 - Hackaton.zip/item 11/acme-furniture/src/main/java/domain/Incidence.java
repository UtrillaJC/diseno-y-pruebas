package domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Access(AccessType.PROPERTY)
public class Incidence extends DomainEntity{
	
	// Constructors -----------------------------------------------------------
	
	public Incidence(){
		super();
		
	}
	
	// Attributes -------------------------------------------------------------

	private String customerName;
	private String cause;
	
	@NotBlank
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	@NotBlank
	public String getCause() {
		return cause;
	}
	public void setCause(String cause) {
		this.cause = cause;
	}
	
	

	// Relationships ----------------------------------------------------------
	
	private Furniture furniture;

	@NotNull
	@Valid
	@ManyToOne(optional=false)
	public Furniture getFurniture() {
		return furniture;
	}
	public void setFurniture(Furniture furniture) {
		this.furniture = furniture;
	}
	
	
	
	

}
