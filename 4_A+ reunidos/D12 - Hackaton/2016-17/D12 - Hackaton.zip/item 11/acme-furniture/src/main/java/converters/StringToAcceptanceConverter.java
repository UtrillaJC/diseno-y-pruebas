package converters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import domain.Acceptance;
import repositories.AcceptanceRepository;

@Component
@Transactional
public class StringToAcceptanceConverter implements Converter<String, Acceptance> {
	
	@Autowired AcceptanceRepository acceptanceRepository;
	
	@Override 
	public Acceptance convert(String text){
		
		Acceptance result;
		int id;
		
		try{
			if(StringUtils.isEmpty(text))
				result = null;
			else{
				id = Integer.valueOf(text);
				result = acceptanceRepository.findOne(id);
			}
			
		} catch(Throwable oops){
			throw new IllegalArgumentException(oops);
		}
		
		return result;
	}
	

}
