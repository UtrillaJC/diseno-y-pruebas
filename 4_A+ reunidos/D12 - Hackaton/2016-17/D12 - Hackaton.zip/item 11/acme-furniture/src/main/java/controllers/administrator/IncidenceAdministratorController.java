
package controllers.administrator;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.IncidenceService;
import controllers.AbstractController;
import domain.Incidence;

@Controller
@RequestMapping("/incidence/administrator")
public class IncidenceAdministratorController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private IncidenceService	incidenceService;


	// Constructors ========================================================================

	public IncidenceAdministratorController() {
		super();
	}

	//List my critiques ========================================================================================

	@RequestMapping(value = "/listAll", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Incidence> incidences;

		incidences = this.incidenceService.findAll();

		result = new ModelAndView("incidence/administrator/listAll");

		result.addObject("incidences", incidences);
		result.addObject("requestURI", "incidence/administrator/listAll.do");

		return result;
	}

	
}
