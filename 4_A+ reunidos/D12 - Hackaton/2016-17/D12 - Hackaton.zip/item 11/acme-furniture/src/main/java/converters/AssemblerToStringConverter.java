package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.Assembler;

@Component
@Transactional
public class AssemblerToStringConverter implements Converter<Assembler, String>{
	
	@Override
	public String convert(Assembler assembler){
		String result;
		
		if(assembler == null)
			result = null;
		else
			result = String.valueOf(assembler.getId());
		
		return result;
	}

}
