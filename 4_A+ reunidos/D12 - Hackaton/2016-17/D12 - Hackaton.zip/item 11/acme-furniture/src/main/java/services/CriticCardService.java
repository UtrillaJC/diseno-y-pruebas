
package services;

import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.CriticCardRepository;
import domain.Critic;
import domain.CriticCard;

@Service
@Transactional
public class CriticCardService {

	@Autowired
	private CriticCardRepository	criticCardRepository;

	//Supported Services ============================================================================

	@Autowired
	public CriticService			criticService;


	//Constructor methods ============================================================================

	public CriticCardService() {
		super();
	}

	// Simple CRUD methods ============================================================================

	public CriticCard findOne(final int criticCardId) {
		CriticCard result;

		result = this.criticCardRepository.findOne(criticCardId);

		return result;
	}

	public Collection<CriticCard> findAll() {
		Collection<CriticCard> result;

		result = this.criticCardRepository.findAll();

		return result;
	}

	public CriticCard findCriticCardByCritic() {
		CriticCard result;
		Critic principal;

		principal = this.criticService.findByPrincipal();
		result = this.criticCardRepository.findCriticCardByCritic(principal.getId());

		return result;
	}

	public CriticCard create() {
		CriticCard result;
		Critic principal;

		principal = this.criticService.findByPrincipal();
		Assert.isInstanceOf(Critic.class, principal);

		result = new CriticCard();
		result.setCode(this.codeGen());
		result.setCritic(principal);

		return result;
	}

	public CriticCard save(final CriticCard criticCard) {
		Critic principal;
		CriticCard result;

		principal = this.criticService.findByPrincipal();

		Assert.isInstanceOf(Critic.class, principal);
		Assert.isTrue(criticCard.getExpirationMoment().after(new Date(System.currentTimeMillis() - 10)));

		result = this.criticCardRepository.saveAndFlush(criticCard);

		return result;
	}

	//Other Business Methods =========================================================================

	public String codeGen() {
		String res = "";
		final String alfabeto = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

		res += alfabeto.charAt((int) (Math.random() * 62));
		res += alfabeto.charAt((int) (Math.random() * 62));
		res += alfabeto.charAt((int) (Math.random() * 62));
		res += alfabeto.charAt((int) (Math.random() * 62));
		res += alfabeto.charAt((int) (Math.random() * 62));
		res += alfabeto.charAt((int) (Math.random() * 62));
		res += alfabeto.charAt((int) (Math.random() * 62));
		res += alfabeto.charAt((int) (Math.random() * 62));
		res += alfabeto.charAt((int) (Math.random() * 62));

		return res;
	}

}
