
package domain;

public enum Level {

	novice, medium, expert

}
