
package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.AcceptanceRepository;
import domain.Acceptance;

@Service
@Transactional
public class AcceptanceService {

	@Autowired
	private AcceptanceRepository	acceptanceRepository;

	@Autowired
	private AdministratorService	administratorService;



	public AcceptanceService() {
		super();
	}

	public Acceptance create() {

		final Acceptance acceptance = new Acceptance();

		return acceptance;
	}

	public Acceptance save(final Acceptance ac) {

		Assert.notNull(ac);
		Assert.notNull(this.administratorService.findByPrincipal());
		Acceptance saved = acceptanceRepository.save(ac);
		/*Collection<Acceptance> aceptances = ac.getMaker().getAcceptances();
		aceptances.add(saved);
		ac.getMaker().setAcceptances(aceptances);
		BudgetLine bl = ac.getBudgetLine();
		bl.setAcceptance(ac);
		budgetLineService.save(bl);
		makerService.save(saved.getMaker());*/
		return saved;
	}

	public Collection<Acceptance> findAll() {

		return this.acceptanceRepository.findAll();
	}

	public Acceptance findOne(final int id) {

		return this.acceptanceRepository.findOne(id);
	}

	public void delete(final Acceptance object) {

		this.acceptanceRepository.delete(object);
	}
}
