
package repositories;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Furniture;

@Repository
public interface FurnitureRepository extends JpaRepository<Furniture, Integer> {

	@Query("select f.code from Furniture f order by f.code desc")
	List<String> searchLastCode();

	@Query("select f from Furniture f where f.id =?1")
	Furniture findOne(int furnitureId);

	@Query("select f from Furniture f where f.code = any (select bl.furnitureCode from Budget b left join b.budgetLines bl where b.customer.id = ?1)")
	Collection<Furniture> findAllByCustomer(int customerId);
	
	@Query("select f from Furniture f where f.code =?1")
	Furniture findByCode(String code);
	
	@Query("select f, sum(r.stars) from Furniture f join f.ratings r group by f order by sum(r.stars) desc")
	Collection<Object[]> furnitureOrderByRatingsString();
	
}
