
package controllers.customer;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.BudgetLineService;
import services.BudgetService;
import controllers.AbstractController;
import domain.Budget;
import domain.BudgetLine;

@Controller
@RequestMapping("/budget/customer")
public class BudgetCustomerController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private BudgetService		budgetService;

	@Autowired
	private BudgetLineService	budgetLineService;


	// Constructors ========================================================================

	public BudgetCustomerController() {
		super();
	}

	//List my critiques ========================================================================================

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam final int furnitureId) {
		ModelAndView result;
		Collection<Budget> budgets;

		budgets = this.budgetService.findByPrincipal();

		result = new ModelAndView("/budget/customer/add");

		result.addObject("budgets", budgets);
		result.addObject("furnitureId", furnitureId);
		result.addObject("requestURI", "budget/customer/add");

		return result;
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public ModelAndView add(@RequestParam final int furnitureId, final int quantity, final int budgetId, final String budgetName) {
		ModelAndView result;
		Budget budget = null;
		result = new ModelAndView("redirect:../../furniture/list.do");
		try {
			if (budgetId == 0) {

				budget = this.budgetService.create(budgetName);
				this.budgetService.add(budget, furnitureId, quantity);

			} else {
				budget = this.budgetService.findOne(budgetId);

				this.budgetService.add(budget, furnitureId, quantity);
			}
		} catch (final Exception e) {
			result = new ModelAndView("redirect:add.do?furnitureId=" + furnitureId);
			result.addObject("message", "budget.create.error");
		}

		return result;
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST, params = "changePiece")
	public ModelAndView addAndEdit(@RequestParam final int furnitureId, final int quantity, final int budgetId, final String budgetName) {
		ModelAndView result;
		Budget budget;
		Collection<BudgetLine> budgetsLine;
		try {
			if (budgetId == 0) {
				budget = this.budgetService.create(budgetName);
				budgetsLine = this.budgetService.add(budget, furnitureId, quantity);
			} else {
				budget = this.budgetService.findOne(budgetId);
				this.budgetService.add(budget, furnitureId, quantity);
				budgetsLine = this.budgetLineService.findByFurnitureAndBudget(budget.getId(), furnitureId);
			}

			result = new ModelAndView("/budgetLine/customer/list");

			result.addObject("budgetsLines", budgetsLine);
			result.addObject("requestURI", "/budgetLine/customer/list");
		} catch (final Exception e) {
			result = new ModelAndView("redirect:add.do?furnitureId=" + furnitureId);
			result.addObject("message", "budget.create.error");
		}

		return result;
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		final Collection<Budget> budgets = this.budgetService.findByPrincipal();

		result = new ModelAndView("/budget/customer/list");

		result.addObject("budgets", budgets);
		result.addObject("requestURI", "budget/customer/list.do");

		return result;
	}

}
