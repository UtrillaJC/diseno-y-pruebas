
package controllers.administrator;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.PieceService;
import controllers.AbstractController;
import domain.Piece;

@Controller
@RequestMapping("/piece/administrator")
public class PieceAdministratorController extends AbstractController {

	@Autowired
	private PieceService	pieceService;


	public PieceAdministratorController() {
		super();
	}

	// List ==============================================================

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;

		Collection<Piece> pieces;

		pieces = this.pieceService.findAll();

		result = new ModelAndView("piece/listByFurniture");
		result.addObject("pieces", pieces);
		result.addObject("requestURI", "piece/administrator/list.do");

		return result;
	}

	// Creation ==============================================================

	@RequestMapping(value = "/addPiece", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam final int furnitureId) {
		ModelAndView result;

		Piece piece;

		piece = this.pieceService.create(furnitureId);

		result = this.createEditModelAndView(piece, "addPiece");

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int pieceId) {
		ModelAndView result;

		Piece piece;

		piece = this.pieceService.findOne(pieceId);

		result = this.createEditModelAndView(piece, "edit");

		return result;
	}

	@RequestMapping(value = "/addPiece", method = RequestMethod.POST, params = "save")
	public ModelAndView saveCreate(@ModelAttribute @Valid final Piece piece, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(piece, "addPiece");
		else
			try {
				this.pieceService.save(piece);
				result = new ModelAndView("redirect:/piece/listByFurniture.do?furnitureId=" + piece.getFurniture().getId());

			} catch (final Throwable oops) {
				result = this.createEditModelAndView(piece, "piece.commit.error", "addPiece");
			}
		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView saveEdit(@ModelAttribute @Valid final Piece piece, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(piece, "edit");
		else
			try {
				this.pieceService.update(piece);
				result = new ModelAndView("redirect:/piece/listByFurniture.do?furnitureId=" + piece.getFurniture().getId());

			} catch (final Throwable oops) {
				result = this.createEditModelAndView(piece, "piece.commit.error", "edit");
			}
		return result;
	}
	// Delete furniture ======================================================================================

	@RequestMapping(value = "edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(final Piece piece, final BindingResult binding) {
		ModelAndView result;

		try {
			final Integer idFurniture = piece.getFurniture().getId();

			this.pieceService.delete(piece);

			result = new ModelAndView("redirect:/piece/listByFurniture.do?furnitureId=" + idFurniture);
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(piece, "piece.commit.error", "edit");
		}

		return result;
	}

	// Ancillary Methods============================================================		

	protected ModelAndView createEditModelAndView(final Piece piece, final String selectView) {
		assert piece != null;

		ModelAndView result;

		result = this.createEditModelAndView(piece, null, selectView);

		return result;

	}

	protected ModelAndView createEditModelAndView(final Piece piece, final String message, final String selectView) {
		assert piece != null;

		ModelAndView result;

		result = new ModelAndView("piece/administrator/" + selectView);
		result.addObject("piece", piece);
		result.addObject("message", message);

		return result;
	}
}
