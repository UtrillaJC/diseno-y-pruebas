package repositories;



import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Maker;

@Repository  
public interface MakerRepository extends JpaRepository<Maker, Integer> {

	@Query("select distinct m from Maker m join m.furnitures fs where fs.assembly.assembler.id = ?1")
	Collection<Maker> findMakersToDoReview(int assemblerId);
	
}