
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Back;
import domain.Maker;

@Repository
public interface BackRepository extends JpaRepository<Back, Integer> {

	@Query("select b from Back b where b.maker.id = ?1")
	Collection<Back> findAllByMaker(int budgetId);
	
	
	@Query("select m from Maker m where m.backs.size = (select max(m2.backs.size) from Maker m2)")	
	Collection<Maker> makerMoreBacks();

	@Query("select m from Maker m where m.backs.size = (select min(m2.backs.size) from Maker m2)")	
	Collection<Maker> makerLessBacks();
	
}
