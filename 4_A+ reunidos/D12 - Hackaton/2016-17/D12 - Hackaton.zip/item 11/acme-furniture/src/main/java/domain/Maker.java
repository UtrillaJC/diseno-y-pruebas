
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Transient;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

@Entity
@Access(AccessType.PROPERTY)
public class Maker extends DomainEntity {

	// Constructors -----------------------------------------------------------

	public Maker() {
		super();

	}


	// Attributes -------------------------------------------------------------

	private String	name;
	private String	email;
	private String	phone;
	private double	averageRatings;


	@Digits(integer = 99, fraction = 2)
	@Transient
	public double getAverageRatings() {
		double aux = 0.;

		final Collection<Furniture> furnitures = this.getFurnitures();

		if (furnitures.size() != 0) {
			for (final Furniture f : furnitures) {
				double result2 = 0.;
				int aux2 = 0;

				final Collection<Rating> ratings = f.getRatings();
				if (ratings.size() != 0) {
					for (final Rating r : ratings)
						aux2 += (r.getStars());
					result2 = aux2 / ratings.size();
				} else
					result2 = 0.;
				aux += result2;
			}
			this.averageRatings = aux / furnitures.size();
		} else
			this.averageRatings = 0.;

		return this.averageRatings;
	}

	public void setAverageRatings(final Double averageRatings) {
		this.averageRatings = averageRatings;
	}
	@NotBlank
	public String getName() {
		return this.name;
	}
	public void setName(final String name) {
		this.name = name;
	}

	@NotBlank
	@Email
	public String getEmail() {
		return this.email;
	}
	public void setEmail(final String email) {
		this.email = email;
	}

	@NotBlank
	@Pattern(regexp = "^([+]\\d+\\s)?\\d+$")
	public String getPhone() {
		return this.phone;
	}
	public void setPhone(final String phone) {
		this.phone = phone;
	}


	// Relationships ----------------------------------------------------------

	private Collection<Furniture>	furnitures;
	private Collection<Back>		backs;
	private Collection<Acceptance>	acceptances;


	@Valid
	@OneToMany(mappedBy = "maker", cascade = CascadeType.REMOVE)
	public Collection<Furniture> getFurnitures() {
		return this.furnitures;
	}

	public void setFurnitures(final Collection<Furniture> furnitures) {
		this.furnitures = furnitures;
	}

	@Valid
	@OneToMany(mappedBy = "maker", cascade = CascadeType.REMOVE)
	public Collection<Back> getBacks() {
		return this.backs;
	}
	public void setBacks(final Collection<Back> backs) {
		this.backs = backs;
	}

	@Valid
	@OneToMany(mappedBy = "maker", cascade = CascadeType.REMOVE)
	public Collection<Acceptance> getAcceptances() {
		return this.acceptances;
	}
	public void setAcceptances(final Collection<Acceptance> acceptances) {
		this.acceptances = acceptances;
	}

}
