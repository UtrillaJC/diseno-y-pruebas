package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.Back;

@Component
@Transactional
public class BackToStringConverter implements Converter<Back, String>{
	
	@Override
	public String convert(Back back){
		String result;
		
		if(back == null)
			result = null;
		else
			result = String.valueOf(back.getId());
		
		return result;
	}

}
