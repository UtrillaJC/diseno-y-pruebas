
package controllers.customer;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.FurnitureService;
import controllers.AbstractController;
import domain.Furniture;

@Controller
@RequestMapping("/furniture/customer")
public class FurnitureCustomerController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private FurnitureService	furnitureService;


	// Constructors ========================================================================

	public FurnitureCustomerController() {
		super();
	}

	//List my critiques ========================================================================================

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Furniture> furnitures;
		final boolean purchase = true;

		furnitures = this.furnitureService.findAllByCustomer();

		result = new ModelAndView("furniture/list");

		result.addObject("furnitures", furnitures);
		result.addObject("purchase", purchase);
		result.addObject("requestURI", "furniture/customer/list.do");

		return result;
	}

}
