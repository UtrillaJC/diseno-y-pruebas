package converters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import repositories.BudgetLineRepository;
import domain.BudgetLine;

@Component
@Transactional
public class StringToBudgetLineConverter implements Converter<String, BudgetLine> {
	
	@Autowired BudgetLineRepository budgetLineRepository;
	
	@Override 
	public BudgetLine convert(String text){
		
		BudgetLine result;
		int id;
		
		try{
			if(StringUtils.isEmpty(text))
				result = null;
			else{
				id = Integer.valueOf(text);
				result = budgetLineRepository.findOne(id);
			}
			
		} catch(Throwable oops){
			throw new IllegalArgumentException(oops);
		}
		
		return result;
	}

}
