package converters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import repositories.BudgetRepository;
import domain.Budget;

@Component
@Transactional
public class StringToBudgetConverter implements Converter<String, Budget> {
	
	@Autowired BudgetRepository budgetRepository;
	
	@Override 
	public Budget convert(String text){
		
		Budget result;
		int id;
		
		try{
			if(StringUtils.isEmpty(text))
				result = null;
			else{
				id = Integer.valueOf(text);
				result = budgetRepository.findOne(id);
			}
			
		} catch(Throwable oops){
			throw new IllegalArgumentException(oops);
		}
		
		return result;
	}

}
