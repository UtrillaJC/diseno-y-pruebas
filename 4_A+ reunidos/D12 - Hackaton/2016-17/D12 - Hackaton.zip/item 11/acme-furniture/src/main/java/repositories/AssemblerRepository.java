
package repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Assembler;

@Repository
public interface AssemblerRepository extends JpaRepository<Assembler, Integer> {

	@Query("select a from Assembler a where a.userAccount.id = ?1")
	Assembler findByUserAccountId(int userAccountId);

}
