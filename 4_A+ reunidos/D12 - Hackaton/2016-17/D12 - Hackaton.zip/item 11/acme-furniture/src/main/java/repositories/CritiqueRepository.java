package repositories;



import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Critique;

@Repository  
public interface CritiqueRepository extends JpaRepository<Critique, Integer> {

	@Query("select c from Critique c where c.critic.id = ?1")
	Collection<Critique> findCritiquesByCritic(int cId);

	@Query("select min(f.critiques.size) from Furniture f")
	Integer minCritique();	

	@Query("select max(f.critiques.size) from Furniture f")
	Integer maxCritique();	
	
	@Query("select avg(f.critiques.size) from Furniture f")
	Double avgCritique();	
}