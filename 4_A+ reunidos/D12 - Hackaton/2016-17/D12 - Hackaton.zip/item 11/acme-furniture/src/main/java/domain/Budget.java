package domain;

import java.util.Collection;
import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Access(AccessType.PROPERTY)
public class Budget extends DomainEntity{
	
	// Constructors -----------------------------------------------------------
	
	public Budget(){
		super();
		
	}
	
	// Attributes -------------------------------------------------------------

	private Date moment;
	private Double totalPrice;
	private String name;
	
	
	@NotBlank
	public String getName(){
		return name;
	}
	
	@NotBlank
	public void setName(String name){
		this.name=name;
	}
	
	@NotNull
	@Past
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern="dd/MM/yyyy")
	public Date getMoment() {
		return moment;
	}
	public void setMoment(Date moment) {
		this.moment = moment;
	}
	
	@Transient
	public double getTotalPrice() {
		totalPrice = 0.0;
		
		for(BudgetLine bl : getBudgetLines()){
			totalPrice = totalPrice + (bl.getPiecePrice()*bl.getQuantity());
		
		}
		return totalPrice;
	}



	// Relationships ----------------------------------------------------------

	
	private Customer customer;
	private Collection<BudgetLine> budgetLines;


	@NotNull
	@Valid
	@ManyToOne(optional=false)
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	
	@Valid
	@NotNull
	@OneToMany(cascade = CascadeType.ALL,mappedBy="budget")
	public Collection<BudgetLine> getBudgetLines() {
		return budgetLines;
	}
	public void setBudgetLines(Collection<BudgetLine> budgetLines) {
		this.budgetLines = budgetLines;
	}
	
	
	
	
	
	

}
