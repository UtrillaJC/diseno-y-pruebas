
package controllers.assembler;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.AssemblyService;
import services.FurnitureService;
import controllers.AbstractController;
import domain.Assembly;
import domain.Furniture;

@Controller
@RequestMapping("/furniture/assembler")
public class FurnitureAssemblerController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private FurnitureService	furnitureService;

	@Autowired
	private AssemblyService		assemblyService;


	// Constructors ========================================================================

	public FurnitureAssemblerController() {
		super();
	}

	//List ========================================================================================

	@RequestMapping(value = "/listNotAssembled", method = RequestMethod.GET)
	public ModelAndView listNotAssembled() {
		ModelAndView result;
		Collection<Furniture> furnitures;

		furnitures = this.furnitureService.findNotAssembled();

		result = new ModelAndView("furniture/assembler/listNotAssembled");

		result.addObject("furnitures", furnitures);
		result.addObject("requestURI", "furniture/assembler/listNotAssembled.do");

		return result;
	}

	@RequestMapping(value = "/listAssembledByMe", method = RequestMethod.GET)
	public ModelAndView listAssembledByMe() {
		ModelAndView result;
		Collection<Furniture> furnitures;

		furnitures = this.furnitureService.findAssembledByMe();

		result = new ModelAndView("furniture/assembler/listAssembledByMe");

		result.addObject("furnitures", furnitures);
		result.addObject("requestURI", "furniture/assembler/listAssembledByMe.do");

		return result;
	}

	//Create ===========================================================================================

	@RequestMapping(value = "/assemble", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam final int furnitureId) {
		ModelAndView result;
		Assembly assembly;
		final Furniture furniture = this.furnitureService.findOne(furnitureId);

		assembly = this.assemblyService.create(furniture);

		result = this.createEditModelAndView(assembly);

		return result;
	}

	@RequestMapping(value = "/assemble", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Assembly assembly, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(assembly);
		else
			try {

				this.assemblyService.save(assembly);

				result = new ModelAndView("redirect:listAssembledByMe.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(assembly, "assembly.commit.error");
			}

		return result;
	}

	// Ancillary methods: Create ===========================================================================================

	protected ModelAndView createEditModelAndView(final Assembly assembly) {
		ModelAndView result;
		result = this.createEditModelAndView(assembly, null);
		return result;

	}

	protected ModelAndView createEditModelAndView(final Assembly assembly, final String message) {
		ModelAndView result;

		result = new ModelAndView("furniture/assembler/assemble");

		result.addObject("assembly", assembly);
		result.addObject("message", message);
		return result;
	}

}
