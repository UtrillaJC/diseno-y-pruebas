
package controllers.administrator;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import controllers.AbstractController;
import domain.Furniture;
import domain.Maker;
import services.FurnitureService;
import services.MakerService;

@Controller
@RequestMapping("/furniture/administrator")
public class FurnitureAdministratorController extends AbstractController {

	@Autowired
	private FurnitureService	furnitureService;

	@Autowired
	private MakerService		makerService;


	public FurnitureAdministratorController() {
		super();
	}

	// Creation ==============================================================

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		Furniture furniture;

		furniture = this.furnitureService.create();

		result = this.createEditModelAndView(furniture, "create");

		return result;
	}

	// Edition =================================================================

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int furnitureId) {
		ModelAndView result;
		Furniture furniture;
	try{
		furniture = this.furnitureService.findOne(furnitureId);
		Assert.notNull(furniture);

		result = this.createEditModelAndView(furniture, "edit");
	}catch (Throwable oops) {
		Furniture furnitureError = furnitureService.create();
		result = this.createEditModelAndView(furnitureError, "furniture.commit.error", "edit");
	}
		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@ModelAttribute @Valid final Furniture furniture, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(furniture, "edit");
		else
			try {
				this.furnitureService.save(furniture);
				result = new ModelAndView("redirect:/furniture/list.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(furniture, "furniture.commit.error", "edit");
			}
		return result;
	}
	
	@RequestMapping(value = "/create", method = RequestMethod.POST, params = "save")
	public ModelAndView saveCreate(@ModelAttribute @Valid final Furniture furniture, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(furniture, "create");
		else
			try {
				this.furnitureService.save(furniture);
				result = new ModelAndView("redirect:/furniture/list.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(furniture, "furniture.commit.error", "create");
			}
		return result;
	}
	
	// Delete furniture ======================================================================================

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(final Furniture furniture, final BindingResult binding) {
		ModelAndView result;

		try {
			this.furnitureService.delete(furniture);
			result = new ModelAndView("redirect:/furniture/list.do");
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(furniture, "furniture.commit.error", "edit");
		}

		return result;
	}
	// Ancillary Methods============================================================		

	protected ModelAndView createEditModelAndView(final Furniture furniture, String selectView) {
		assert furniture != null;

		ModelAndView result;

		result = this.createEditModelAndView(furniture, null, selectView);

		return result;

	}

	protected ModelAndView createEditModelAndView(final Furniture furniture, final String message, String selectView) {
		assert furniture != null;

		ModelAndView result;
		final Collection<Maker> makers;

		makers = this.makerService.findAll();
		result = new ModelAndView("furniture/administrator/"+selectView);
		result.addObject("furniture", furniture);
		result.addObject("makers", makers);
		result.addObject("message", message);

		return result;
	}
}
