
package services;

import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Administrator;
import domain.Back;
import domain.Maker;
import domain.Piece;
import repositories.BackRepository;

@Service
@Transactional
public class BackService {

	//Managed Repository =============================================================================

	@Autowired
	private BackRepository			backRepository;

	//Supported Services =============================================================================

	@Autowired
	private AdministratorService	administratorService;


	//Constructor methods ============================================================================

	public BackService() {
		super();
	}

	public Collection<Back> findAll() {
		Collection<Back> result;

		result = this.backRepository.findAll();

		return result;
	}

	public Back findOne(final int backId) {
		Back result;

		result = this.backRepository.findOne(backId);
		Assert.notNull(result);

		return result;
	}

	//Simple CRUD methods ============================================================================

	public Back create(final Piece piece) {
		Assert.notNull(piece);
		Back result;
		final Date momentOldPiece;

		momentOldPiece = new Date(System.currentTimeMillis());

		result = new Back();

		result.setPiece(piece);
		result.setMomentOldPiece(momentOldPiece);
		result.setMaker(piece.getFurniture().getMaker());

		return result;

	}

	public Back save(final Back back) {
		Assert.notNull(back);
		final Back result;
		final Date momentOldPiece;
		Administrator principal;

		principal = this.administratorService.findByPrincipal();
		Assert.notNull(principal);
		Assert.isInstanceOf(Administrator.class, principal);

		momentOldPiece = new Date(System.currentTimeMillis() - 1000);

		if (back.getId() == 0)
			back.setMomentOldPiece(momentOldPiece);

		result = this.backRepository.saveAndFlush(back);

		return result;

	}

	public void delete(final Back back) {
		Assert.notNull(back);

		this.backRepository.delete(back);
	}

	//Other Business Methods =========================================================================

	public Collection<Back> findAllByMaker(final int backId) {
		Collection<Back> result;
		Administrator principal;

		principal = this.administratorService.findByPrincipal();
		Assert.isInstanceOf(Administrator.class, principal);

		result = this.backRepository.findAllByMaker(backId);

		return result;
	}
	
	public Collection<Maker> makerMoreBacks(){
		administratorService.checkPrincipal();
		
		return backRepository.makerMoreBacks();
		
	}

	public Collection<Maker> makerLessBacks(){
		administratorService.checkPrincipal();
		
		return backRepository.makerLessBacks();
		
	}
	
}
