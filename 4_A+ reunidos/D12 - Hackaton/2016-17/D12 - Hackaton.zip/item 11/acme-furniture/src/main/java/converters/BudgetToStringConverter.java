package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.Budget;

@Component
@Transactional
public class BudgetToStringConverter implements Converter<Budget, String>{
	
	@Override
	public String convert(Budget budget){
		String result;
		
		if(budget == null)
			result = null;
		else
			result = String.valueOf(budget.getId());
		
		return result;
	}

}
