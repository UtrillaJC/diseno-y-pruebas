
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Entity
@Access(AccessType.PROPERTY)
public class Customer extends Actor {

	//Constructors====================================================================================

	public Customer() {
		super();
	}


	// Relationships ----------------------------------------------------------

	private Collection<Budget>	budgets;
	private Collection<Rating>	ratings;


	@NotNull
	@Valid
	@OneToMany(mappedBy = "customer")
	public Collection<Budget> getBudgets() {
		return this.budgets;
	}

	public void setBudgets(final Collection<Budget> budgets) {
		this.budgets = budgets;
	}

	@NotNull
	@Valid
	@OneToMany(mappedBy = "customer")
	public Collection<Rating> getRatings() {
		return this.ratings;
	}

	public void setRatings(final Collection<Rating> ratings) {
		this.ratings = ratings;
	}

}
