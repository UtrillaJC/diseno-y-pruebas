
package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.AssemblyRepository;
import domain.Assembler;
import domain.Assembly;
import domain.Furniture;

@Service
@Transactional
public class AssemblyService {

	//Managed Repository =============================================================================

	@Autowired
	private AssemblyRepository	assemblyRepository;

	//Supported Services =============================================================================

	@Autowired
	private AssemblerService	assemblerService;


	//Constructor methods ============================================================================

	public AssemblyService() {
		super();
	}

	//Simple CRUD methods ============================================================================

	public Assembly create(final Furniture furniture) {
		Assembly result;
		Assembler principal;

		principal = this.assemblerService.findByPrincipal();
		result = new Assembly();
		result.setFurniture(furniture);
		result.setAssembler(principal);

		return result;
	}

	public Assembly save(final Assembly assembly) {
		Assembly result;
		Assembler principal;
		Furniture furniture;
		Collection<Assembly> assemblies;

		principal = this.assemblerService.findByPrincipal();
		Assert.isInstanceOf(Assembler.class, principal);
		Assert.notNull(assembly);
		assemblies = principal.getAssemblies();
		result = this.assemblyRepository.saveAndFlush(assembly);

		furniture = result.getFurniture();
		furniture.setAssembly(result);
		assemblies.add(result);
		principal.setAssemblies(assemblies);

		return result;
	}

}
