
package controllers.administrator;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.BackService;
import services.PieceService;
import controllers.AbstractController;
import domain.Back;
import domain.Piece;

@Controller
@RequestMapping("/back/administrator")
public class BackAdministratorController extends AbstractController {

	@Autowired
	private BackService		backService;

	@Autowired
	private PieceService	pieceService;


	public BackAdministratorController() {
		super();
	}

	// List ==============================================================

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;

		Collection<Back> backs;

		backs = this.backService.findAll();

		result = new ModelAndView("back/administrator/list");
		result.addObject("backs", backs);
		result.addObject("requestURI", "back/administrator/list.do");

		return result;
	}

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam final int pieceId) {
		ModelAndView result;

		Piece piece;
		Back back;

		piece = this.pieceService.findOne(pieceId);
		back = this.backService.create(piece);

		result = this.createEditModelAndView(back);

		return result;
	}

	// Edition ---------------------------------------------------------------

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int backId) {
		ModelAndView result;
		Back back;

		back = this.backService.findOne(backId);

		result = this.createEditModelAndView(back);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView saveEdit(@ModelAttribute @Valid final Back back, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(back);
		else
			try {
				this.backService.save(back);
				result = new ModelAndView("redirect:/back/administrator/list.do");

			} catch (final Throwable oops) {
				result = this.createEditModelAndView(back, "back.commit.error");
			}
		return result;
	}

	// Ancillary Methods============================================================		

	protected ModelAndView createEditModelAndView(final Back back) {
		assert back != null;

		ModelAndView result;

		result = this.createEditModelAndView(back, null);

		return result;

	}

	protected ModelAndView createEditModelAndView(final Back back, final String message) {
		assert back != null;

		ModelAndView result;

		result = new ModelAndView("back/administrator/create");
		result.addObject("back", back);
		result.addObject("message", message);

		return result;
	}

}
