package domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Entity
@Access(AccessType.PROPERTY)
public class Acceptance extends DomainEntity{
	
	// Constructors -----------------------------------------------------------
	
	public Acceptance(){
		super();
		
	}
	
	// Attributes -------------------------------------------------------------

	private Boolean accepted;
	
	public Boolean isAccepted() {
		return accepted;
	}
	public void setAccepted(Boolean accepted) {
		this.accepted = accepted;
	}

	

	// Relationships ----------------------------------------------------------
	
	private BudgetLine budgetLine;
	private Maker maker;

	
	
	@NotNull
	@Valid
	@OneToOne(optional=false)
	public BudgetLine getBudgetLine() {
		return budgetLine;
	}
	public void setBudgetLine(BudgetLine budgetLine) {
		this.budgetLine = budgetLine;
	}
	
	
	@NotNull
	@Valid
	@ManyToOne(optional=false)
	public Maker getMaker() {
		return maker;
	}
	public void setMaker(Maker maker) {
		this.maker = maker;
	}
	
	
	
	

}
