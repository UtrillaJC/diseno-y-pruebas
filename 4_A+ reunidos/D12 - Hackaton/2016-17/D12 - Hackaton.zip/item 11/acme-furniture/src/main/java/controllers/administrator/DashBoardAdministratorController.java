
package controllers.administrator;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.BackService;
import services.BudgetService;
import services.CriticService;
import services.CritiqueService;
import services.FurnitureService;
import services.IncidenceService;
import domain.Critic;
import domain.Maker;

@Controller
@RequestMapping("/dashboard/administrator")
public class DashBoardAdministratorController {

	@Autowired
	IncidenceService	incidenceService;

	@Autowired
	CritiqueService		critiqueService;

	@Autowired
	CriticService		criticService;

	@Autowired
	BudgetService		budgetService;

	@Autowired
	BackService		backService;
	
	@Autowired
	FurnitureService	furnitureService;


	public DashBoardAdministratorController() {
		super();
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView dashboard() {

		//The min incidence by furniture.
		final Integer dashboard1 = this.incidenceService.minIncidence();
		//The max incidence by furniture.			
		final Integer dashboard2 = this.incidenceService.maxIncidence();
		//The avg incidence by furniture.		
		final Double dashboard3 = this.incidenceService.avgIncidence();

		//The min budget by customer.
		final Integer dashboard4 = this.budgetService.minBudgetsByCustomer();
		//The max budget by customer.			
		final Integer dashboard5 = this.budgetService.maxBudgetsByCustomer();
		//The avg budget by customer.		
		final Double dashboard6 = this.budgetService.avgBudgetsByCustomer();

		//The min critique by customer.
		final Integer dashboard10 = this.critiqueService.minCritique();
		//The max critique by customer.
		final Integer dashboard11 = this.critiqueService.maxCritique();
		//The avg critique by customer.
		final Double dashboard12 = this.critiqueService.avgCritique();


		//The maker more backs.
		final Collection<Maker> dashboard13 = this.backService.makerMoreBacks();
		//The maker less backs.
		final Collection<Maker> dashboard14= this.backService.makerLessBacks();
		
		//The critic more critique positive.
		final Collection<Critic> dashboard15 = this.criticService.criticMoreCritiquesPositive();

		//The critic more critique neutral.
		final Collection<Critic> dashboard16 = this.criticService.criticMoreCritiquesNeutral();

		//The critic more critique negative.
		final Collection<Critic> dashboard17 = this.criticService.criticMoreCritiquesNegative();
		
		//Furniture order descent by ratings
		Collection<Object[]> dashboard18 = this.furnitureService.furnitureOrderByRatingsString();

		final ModelAndView result = new ModelAndView("dashboard/dashboard");

		result.addObject("dashboard1", dashboard1);
		result.addObject("dashboard2", dashboard2);
		result.addObject("dashboard3", dashboard3);

		result.addObject("dashboard4", dashboard4);
		result.addObject("dashboard5", dashboard5);
		result.addObject("dashboard6", dashboard6);

		result.addObject("dashboard10", dashboard10);
		result.addObject("dashboard11", dashboard11);
		result.addObject("dashboard12", dashboard12);
		
		result.addObject("dashboard13", dashboard13);
		result.addObject("dashboard14", dashboard14);

		result.addObject("dashboard15", dashboard15);

		result.addObject("dashboard16", dashboard16);

		result.addObject("dashboard17", dashboard17);
		
		result.addObject("dashboard18", dashboard18);

		result.addObject("requestURI", "dashboard/administrator/list.do");

		return result;
	}

}
