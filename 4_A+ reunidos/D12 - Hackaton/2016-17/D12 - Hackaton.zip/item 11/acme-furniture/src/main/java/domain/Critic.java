
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Entity
@Access(AccessType.PROPERTY)
public class Critic extends Actor {

	//Constructors====================================================================================

	public Critic() {
		super();
	}


	// Relationships ----------------------------------------------------------

	private CriticCard				criticCard;
	private Collection<Critique>	critiques;
	private Collection<Critique>	votedCritiques;


	@Valid
	@OneToOne(optional = true,mappedBy="critic")
	public CriticCard getCriticCard() {
		return this.criticCard;
	}

	public void setCriticCard(final CriticCard criticCard) {
		this.criticCard = criticCard;
	}

	@NotNull
	@Valid
	@OneToMany(mappedBy = "critic")
	public Collection<Critique> getCritiques() {
		return this.critiques;
	}

	public void setCritiques(final Collection<Critique> critiques) {
		this.critiques = critiques;
	}

	@NotNull
	@Valid
	@ManyToMany(mappedBy = "critics")
	public Collection<Critique> getVotedCritiques() {
		return this.votedCritiques;
	}

	public void setVotedCritiques(final Collection<Critique> votedCritiques) {
		this.votedCritiques = votedCritiques;
	}

}
