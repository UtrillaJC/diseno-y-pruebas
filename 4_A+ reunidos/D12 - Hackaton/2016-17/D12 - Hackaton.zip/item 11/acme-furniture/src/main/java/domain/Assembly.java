
package domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Entity
@Access(AccessType.PROPERTY)
public class Assembly extends DomainEntity {

	// Constructors -----------------------------------------------------------

	public Assembly() {
		super();

	}


	// Attributes -------------------------------------------------------------

	private double	price;


	@Min(0)
	@Digits(integer = 99, fraction = 2)
	public double getPrice() {
		return this.price;
	}

	public void setPrice(final double price) {
		this.price = price;
	}


	// Relationships ----------------------------------------------------------

	private Assembler	assembler;
	private Furniture	furniture;


	@Valid
	@NotNull
	@ManyToOne(optional = false)
	public Assembler getAssembler() {
		return this.assembler;
	}

	public void setAssembler(final Assembler assembler) {
		this.assembler = assembler;
	}

	@Valid
	@NotNull
	@OneToOne(optional = false)
	public Furniture getFurniture() {
		return this.furniture;
	}

	public void setFurniture(final Furniture furniture) {
		this.furniture = furniture;
	}

}
