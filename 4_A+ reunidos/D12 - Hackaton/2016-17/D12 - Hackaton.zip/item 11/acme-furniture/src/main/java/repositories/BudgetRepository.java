
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Budget;

@Repository
public interface BudgetRepository extends JpaRepository<Budget, Integer> {

	@Query("select b from Budget b where b.customer.id=?1")
	Collection<Budget> findAllByCustomer(int customerId);

	@Query("select min(c.budgets.size) from Customer c")
	Integer minBudgetsByCustomer();

	@Query("select avg(c.budgets.size) from Customer c")
	Double avgBudgetsByCustomer();
	
	@Query("select max(c.budgets.size) from Customer c")
	Integer maxBudgetsByCustomer();
}
