package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.CriticCard;

@Component
@Transactional
public class CriticCardToStringConverter implements Converter<CriticCard, String>{
	
	@Override
	public String convert(CriticCard criticCard){
		String result;
		
		if(criticCard == null)
			result = null;
		else
			result = String.valueOf(criticCard.getId());
		
		return result;
	}

}
