
package controllers.customer;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.FurnitureService;
import services.IncidenceService;
import controllers.AbstractController;
import domain.Furniture;
import domain.Incidence;

@Controller
@RequestMapping("/incidence/customer")
public class IncidenceCustomerController extends AbstractController {

	@Autowired
	private IncidenceService	incidenceService;

	@Autowired
	private FurnitureService	furnitureService;


	public IncidenceCustomerController() {
		super();
	}

	// Creation ==============================================================

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam final int furnitureId) {
		ModelAndView result;
		final Incidence incidence;
		final Furniture furniture;

		furniture = this.furnitureService.findOne(furnitureId);

		incidence = this.incidenceService.create(furniture);

		result = this.createEditModelAndView(incidence);

		return result;
	}

	@RequestMapping(value = "/create", method = RequestMethod.POST, params = "save")
	public ModelAndView saveCreate(@ModelAttribute @Valid final Incidence incidence, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(incidence);
		else
			try {
				this.incidenceService.save(incidence);
				result = new ModelAndView("redirect:/furniture/customer/list.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(incidence, "incidence.commit.error");
			}
		return result;
	}

	// Ancillary Methods============================================================		

	protected ModelAndView createEditModelAndView(final Incidence incidence) {
		assert incidence != null;

		ModelAndView result;

		result = this.createEditModelAndView(incidence, null);

		return result;

	}

	protected ModelAndView createEditModelAndView(final Incidence incidence, final String message) {
		assert incidence != null;

		ModelAndView result;

		result = new ModelAndView("incidence/customer/create");
		result.addObject("incidence", incidence);
		result.addObject("message", message);

		return result;
	}
}
