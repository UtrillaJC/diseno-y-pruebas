
package controllers.customer;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.FurnitureService;
import services.RatingService;
import controllers.AbstractController;
import domain.Furniture;
import domain.Rating;

@Controller
@RequestMapping("/rating/customer")
public class RatingCustomerController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private RatingService		ratingService;

	@Autowired
	private FurnitureService	furnitureService;


	// Constructors ========================================================================

	public RatingCustomerController() {
		super();
	}

	//List my ratings ========================================================================================

	@RequestMapping(value = "/myList", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Rating> ratings;

		ratings = this.ratingService.findRatingsByCustomer();

		result = new ModelAndView("rating/customer/list");

		result.addObject("ratings", ratings);
		result.addObject("requestURI", "rating/customer/myList.do");

		return result;
	}

	//List by furniture ========================================================================================

	@RequestMapping(value = "/listByFurniture", method = RequestMethod.GET)
	public ModelAndView listByFurniture(@RequestParam final int furnitureId) {
		ModelAndView result;
		Collection<Rating> ratings;

		ratings = this.ratingService.findRatingsByFurnitureId(furnitureId);

		result = new ModelAndView("rating/customer/listByFurniture");

		result.addObject("ratings", ratings);
		result.addObject("requestURI", "rating/customer/listByFurniture.do");

		return result;
	}

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam final int furnitureId) {
		ModelAndView result;
		Rating rating;
		Furniture furniture;

		furniture = this.furnitureService.findOne(furnitureId);
		rating = this.ratingService.create(furniture);

		result = this.createEditModelAndView(rating);

		return result;
	}

	// Edition ---------------------------------------------------------------
	@RequestMapping(value = "/create", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@ModelAttribute("ratingCustomer") @Valid final Rating ratingCustomer, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(ratingCustomer);
		else
			try {

				this.ratingService.save(ratingCustomer);

				result = new ModelAndView("redirect:myList.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(ratingCustomer, "rating.commit.error");
			}

		return result;
	}

	// Ancillary methods: Create ===========================================================================================

	protected ModelAndView createEditModelAndView(final Rating ratingCustomer) {
		ModelAndView result;
		result = this.createEditModelAndView(ratingCustomer, null);
		return result;

	}

	protected ModelAndView createEditModelAndView(final Rating ratingCustomer, final String message) {
		ModelAndView result;

		result = new ModelAndView("rating/customer/create");

		result.addObject("ratingCustomer", ratingCustomer);
		result.addObject("message", message);
		return result;
	}
}
