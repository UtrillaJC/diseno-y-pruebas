
package controllers.administrator;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.RatingService;
import controllers.AbstractController;
import domain.Rating;

@Controller
@RequestMapping("/rating/administrator")
public class RatingAdministratorController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private RatingService	ratingService;


	// Constructors ========================================================================

	public RatingAdministratorController() {
		super();
	}

	@RequestMapping(value = "/listByFurniture", method = RequestMethod.GET)
	public ModelAndView listByFurniture(@RequestParam final int furnitureId) {
		ModelAndView result;
		Collection<Rating> ratings;

		ratings = this.ratingService.findRatingsByFurnitureId(furnitureId);

		result = new ModelAndView("rating/administrator/listByFurniture");

		result.addObject("ratings", ratings);
		result.addObject("requestURI", "rating/administrator/listByFurniture.do");

		return result;
	}

}
