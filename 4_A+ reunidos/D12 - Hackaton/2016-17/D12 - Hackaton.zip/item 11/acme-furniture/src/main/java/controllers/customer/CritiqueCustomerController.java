
package controllers.customer;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.CritiqueService;
import controllers.AbstractController;
import domain.Critique;

@Controller
@RequestMapping("/critique/customer")
public class CritiqueCustomerController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private CritiqueService	critiqueService;


	// Constructors ========================================================================

	public CritiqueCustomerController() {
		super();
	}

	//List my critiques ========================================================================================

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam final int furnitureId) {
		ModelAndView result;
		Collection<Critique> critiques;

		critiques = this.critiqueService.findByFurnitureId(furnitureId);

		result = new ModelAndView("critique/customer/list");

		result.addObject("critiques", critiques);
		result.addObject("requestURI", "critique/customer/list.do");

		return result;
	}

}
