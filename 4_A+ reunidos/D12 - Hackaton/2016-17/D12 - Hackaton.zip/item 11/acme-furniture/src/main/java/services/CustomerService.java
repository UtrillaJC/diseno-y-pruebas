
package services;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.CustomerRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;
import domain.Budget;
import domain.Customer;
import domain.Folder;
import domain.Message;
import domain.Rating;
import forms.RegistrationForm;

@Service
@Transactional
public class CustomerService {

	//Managed Repository =============================================================================

	@Autowired
	private CustomerRepository	customerRepository;

	//Supported Services =============================================================================
	@Autowired
	private FolderService		folderService;


	//Constructor methods ============================================================================

	public CustomerService() {
		super();
	}

	//Simple CRUD methods ============================================================================
	public Customer create() {

		final Customer c = new Customer();
		final UserAccount ua = new UserAccount();
		Collection<Budget> budgets;
		Collection<Rating> ratings;
		Collection<Folder> folders;
		Collection<Message> sentMessages;
		Collection<Message> receivedMessages;

		ua.setUsername("");
		ua.setPassword("");
		budgets = new ArrayList<Budget>();
		ratings = new ArrayList<Rating>();
		folders = new ArrayList<Folder>();
		sentMessages = new ArrayList<Message>();
		receivedMessages = new ArrayList<Message>();

		final Authority auth = new Authority();
		auth.setAuthority("CUSTOMER");

		ua.addAuthority(auth);
		c.setUserAccount(ua);
		c.setBudgets(budgets);
		c.setRatings(ratings);
		c.setReceivedMessages(receivedMessages);
		c.setSentMessages(sentMessages);
		c.setFolders(folders);

		return c;
	}

	public Customer reconstruct(final RegistrationForm crf) {

		final Customer c = this.create();

		c.getUserAccount().setUsername(crf.getUsername());
		c.getUserAccount().setPassword(crf.getPassword());

		c.setName(crf.getName());
		c.setSurname(crf.getSurname());
		c.setEmail(crf.getEmail());
		c.setPhone(crf.getPhone());
		c.setAddress(crf.getAddress());

		return c;
	}

	public Customer save(final Customer c) {
		Customer result;
		final UserAccount ua = c.getUserAccount();
		final Md5PasswordEncoder md5PasswordEncoder = new Md5PasswordEncoder();
		final String pass = md5PasswordEncoder.encodePassword(ua.getPassword(), null);
		ua.setPassword(pass);
		c.setUserAccount(ua);

		result = this.customerRepository.saveAndFlush(c);
		this.folderService.createDefaultFolders(result);

		return result;
	}
	//Other Business Methods =========================================================================

	public Customer findByPrincipal() {
		Customer result;
		UserAccount userAccount;

		userAccount = LoginService.getPrincipal();
		Assert.notNull(userAccount);
		result = this.findByUserAccount(userAccount);
		Assert.notNull(result);

		return result;
	}

	public Customer findByUserAccount(final UserAccount userAccount) {
		Customer result;

		result = this.customerRepository.findByUserAccountId(userAccount.getId());

		return result;
	}
}
