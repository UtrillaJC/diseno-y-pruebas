
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;

@Entity
@Access(AccessType.PROPERTY)
public class SpamTerm extends DomainEntity {

	//Constructors---------------------------------------------------------------------------------
	public SpamTerm() {
		super();
	}


	//Attributes------------------------------------------------------------------------------------

	private Collection<String>	keywords;


	@ElementCollection
	public Collection<String> getKeywords() {
		return this.keywords;
	}
	public void setKeywords(final Collection<String> keywords) {
		this.keywords = keywords;
	}

	//Relationships------------------------------------------------------------------------------------

}
