
package controllers.customer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.BudgetLineService;
import services.BudgetService;
import services.CustomerService;
import controllers.AbstractController;
import domain.Budget;
import domain.BudgetLine;
import domain.Customer;

@Controller
@RequestMapping("/budgetLine/customer")
public class BudgetLineCustomerController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private BudgetService		budgetService;

	@Autowired
	private BudgetLineService	budgetLineService;

	@Autowired
	private CustomerService		customerService;


	// Constructors ========================================================================

	public BudgetLineCustomerController() {
		super();
	}

	//List my critiques ========================================================================================

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam final int budgetId) {
		ModelAndView result;
		final Budget budget = this.budgetService.findOne(budgetId);
		Customer principal;

		principal = this.customerService.findByPrincipal();
		Assert.isTrue(budget.getCustomer().equals(principal));

		result = new ModelAndView("/budgetLine/customer/list");

		result.addObject("budgetsLines", budget.getBudgetLines());
		result.addObject("requestURI", "budgetLine/customer/list.do");

		return result;
	}
	@RequestMapping(value = "/comment", method = RequestMethod.POST)
	public ModelAndView comment(@RequestParam final int id, final String comment) {
		final BudgetLine bl = this.budgetLineService.findOne(id);
		final ModelAndView result = new ModelAndView("redirect:/budgetLine/customer/list.do?budgetId=" + bl.getBudget().getId());
		try {
			this.budgetLineService.comment(id, comment);
		} catch (final Exception e) {
			result.addObject("CreateError", true);
		}

		return result;
	}
}
