
package controllers.customer;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.MakerService;
import controllers.AbstractController;
import domain.Maker;

@Controller
@RequestMapping("/maker/customer")
public class MakerCustomerController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private MakerService	makerService;


	// Constructors ========================================================================

	public MakerCustomerController() {
		super();
	}

	//List my critiques ========================================================================================

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Maker> makers;

		makers = this.makerService.findAll();
		result = new ModelAndView("maker/customer/list");

		result.addObject("makers", makers);
		result.addObject("requestURI", "maker/customer/list.do");

		return result;
	}

}
