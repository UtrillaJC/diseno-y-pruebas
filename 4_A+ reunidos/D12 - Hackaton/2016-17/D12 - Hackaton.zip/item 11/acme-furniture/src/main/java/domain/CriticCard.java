
package domain;

import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Access(AccessType.PROPERTY)
public class CriticCard extends DomainEntity {

	// Constructors -----------------------------------------------------------

	public CriticCard() {
		super();

	}


	// Attributes -------------------------------------------------------------

	private Date	expirationMoment;
	private String	school;
	private Level	level;
	private String	code;


	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	public Date getExpirationMoment() {
		return this.expirationMoment;
	}
	public void setExpirationMoment(final Date expirationMoment) {
		this.expirationMoment = expirationMoment;
	}

	@NotBlank
	public String getSchool() {
		return this.school;
	}
	public void setSchool(final String school) {
		this.school = school;
	}

	public Level getLevel() {
		return this.level;
	}
	public void setLevel(final Level level) {
		this.level = level;
	}

	@Column(unique = true)
	@Pattern(regexp = "\\w{9}")
	@NotBlank
	public String getCode() {
		return this.code;
	}
	public void setCode(final String code) {
		this.code = code;
	}


	// Relationships ----------------------------------------------------------

	private Critic	critic;


	@Valid
	@NotNull
	@OneToOne(optional = false)
	public Critic getCritic() {
		return this.critic;
	}
	public void setCritic(final Critic critic) {
		this.critic = critic;
	}

}
