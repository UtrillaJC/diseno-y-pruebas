
package repositories;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Piece;

@Repository
public interface PieceRepository extends JpaRepository<Piece, Integer> {

	@Query("select p from Piece p where p.furniture.id=?1")
	Collection<Piece> findAllByFurnitureId(int furnitureId);
	
	@Query("select p.code from Piece p order by p.code desc")
	List<String> searchLastCode();
}
