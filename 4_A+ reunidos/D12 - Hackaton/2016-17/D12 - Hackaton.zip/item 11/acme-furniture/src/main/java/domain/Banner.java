package domain;



import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.URL;

@Entity
@Access(AccessType.PROPERTY)
public class Banner extends DomainEntity{
	//Constructors---------------------------------------------------------------------------------
	public Banner(){
		super();
	}
	//Attributes------------------------------------------------------------------------------------


	private String text;
	
	@NotBlank
	@URL	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	
	

	//Relationships------------------------------------------------------------------------------------


}
