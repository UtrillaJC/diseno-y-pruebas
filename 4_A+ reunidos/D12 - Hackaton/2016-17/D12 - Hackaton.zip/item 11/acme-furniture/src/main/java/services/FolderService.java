
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.FolderRepository;
import domain.Actor;
import domain.Folder;
import domain.Message;

@Service
@Transactional
public class FolderService {

	//Managed Repository =============================================================================

	@Autowired
	private FolderRepository	folderRepository;

	//Supported Services =============================================================================

	@Autowired
	private ActorService		actorService;


	//Constructor methods ============================================================================

	public FolderService() {
		super();
	}

	//Simple CRUD methods ============================================================================

	public Folder findOneByPrincipal(final int folderId) {
		Folder result;
		Actor principal;

		result = this.folderRepository.findOne(folderId);
		principal = this.actorService.findByPrincipal();
		Assert.notNull(principal);

		Assert.isTrue(result.getActor().equals(principal));

		return result;
	}

	public Folder create(final Actor actor) {
		Assert.notNull(actor);
		Folder result;
		Collection<Message> messages;

		messages = new HashSet<Message>();

		result = new Folder();

		result.setActor(actor);
		result.setPredefined(true);
		result.setMessages(messages);
		actor.getFolders().add(result);

		return result;
	}
	public Folder createByActor(final Actor actor) {
		Assert.notNull(actor);
		Folder result;
		Actor principal;
		Collection<Message> messages;

		principal = this.actorService.findByPrincipal();
		Assert.isTrue(principal.equals(actor));
		messages = new HashSet<Message>();

		result = new Folder();

		result.setActor(actor);
		result.setPredefined(false);
		result.setMessages(messages);

		return result;
	}

	public Folder saveBySystem(final Folder folder) {
		Assert.isTrue(folder.getName().equals("Inbox") || folder.getName().equals("Outbox") || folder.getName().equals("Trashbox") || folder.getName().equals("Spambox"));
		Assert.isTrue(folder.getPredefined().equals(true));
		Assert.notNull(folder);
		Assert.notNull(folder.getActor());
		Folder result;

		result = this.folderRepository.save(folder);

		return result;
	}

	public Folder saveFolderByActor(final Folder folder) {
		Assert.isTrue(!folder.getName().equals("Inbox") && !folder.getName().equals("Outbox") && !folder.getName().equals("Trashbox") && !folder.getName().equals("Spambox"));
		Assert.notNull(folder);
		Assert.notNull(folder.getActor());
		Folder result;
		Actor principal;

		principal = this.actorService.findByPrincipal();

		Assert.isTrue(folder.getActor().equals(principal));
		Assert.isTrue(folder.getPredefined() == false);

		result = this.folderRepository.saveAndFlush(folder);

		return result;
	}
	public void delete(final Folder folder) {
		Assert.notNull(folder);

		Actor principal;

		principal = this.actorService.findByPrincipal();

		Assert.isTrue(folder.getActor().equals(principal));
		Assert.isTrue(!folder.getPredefined());
		Assert.isTrue(folder.getMessages().isEmpty());

		this.folderRepository.delete(folder);
	}
	//Other Business Methods =========================================================================

	public Collection<Folder> findAllByActor(final Actor actor) {
		Assert.notNull(actor);
		Collection<Folder> result;
		Actor principal;

		principal = this.actorService.findByPrincipal();
		Assert.notNull(principal);
		Assert.isTrue(actor.equals(principal));

		result = this.folderRepository.findByActor(actor.getId());

		return result;
	}

	public Folder findInboxByActor(final Actor actor) {
		Assert.notNull(actor);
		Folder result;

		result = this.folderRepository.findInboxByActorId(actor.getId());

		return result;
	}

	public Folder findOutboxByActor(final Actor actor) {
		Assert.notNull(actor);
		Folder result;

		result = this.folderRepository.findOutboxByActorId(actor.getId());

		return result;
	}

	public Folder findTrashboxByActor(final Actor actor) {
		Assert.notNull(actor);
		Folder result;

		result = this.folderRepository.findTrashboxByActorId(actor.getId());

		return result;
	}

	public Folder findSpamboxByActor(final Actor actor) {
		Assert.notNull(actor);
		Folder result;

		result = this.folderRepository.findSpamboxByActorId(actor.getId());

		return result;
	}

	public Folder findFolderByActorByName(final Actor actor, final String folderName) {
		Assert.notNull(actor);
		Folder result;

		result = this.folderRepository.findFolderByActorByName(actor.getId(), folderName);

		return result;
	}

	public Folder createForActor(final String name, final Actor actor) {
		final Folder folder = new Folder();
		folder.setName(name);
		folder.setActor(actor);
		folder.setMessages(new ArrayList<Message>());
		folder.setPredefined(false);
		return folder;
	}
	public Folder save(final Folder folder) {
		Assert.notNull(folder);

		return this.folderRepository.saveAndFlush(folder);
	}

	public void createDefaultFolders(final Actor actor) {
		final Folder inFolder = this.createForActor("inbox", actor);
		final Folder outFolder = this.createForActor("outbox", actor);
		final Folder trashFolder = this.createForActor("trashbox", actor);
		final Folder spamFolder = this.createForActor("spambox", actor);

		inFolder.setPredefined(true);
		this.save(inFolder);

		outFolder.setPredefined(true);
		this.save(outFolder);

		trashFolder.setPredefined(true);
		this.save(trashFolder);

		spamFolder.setPredefined(true);
		this.save(spamFolder);
	}

}
