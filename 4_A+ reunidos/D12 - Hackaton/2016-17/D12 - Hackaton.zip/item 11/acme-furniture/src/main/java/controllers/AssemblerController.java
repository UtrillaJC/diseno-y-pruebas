package controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import domain.Assembler;
import forms.RegistrationForm;
import services.AssemblerService;

@Controller
@RequestMapping("/assembler")
public class AssemblerController extends AbstractController {

	@Autowired
	private AssemblerService assemblerService;

	public AssemblerController() {
		super();
	}

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView create() {

		ModelAndView result;
		RegistrationForm urf = new RegistrationForm();
		result = createEditModelAndView(urf);
		return result;
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@ModelAttribute("urf") @Valid RegistrationForm urf, BindingResult binding) {

		ModelAndView result;
		Assembler assembler;

		if (binding.hasErrors()) {
			if (binding.getGlobalError() != null){
				result = createEditModelAndView(urf, binding.getGlobalError().getCode());
			}else{
				result = createEditModelAndView(urf);
			}
		} else {
			try {
				assembler = assemblerService.reconstruct(urf);
				assemblerService.save(assembler);
				result = new ModelAndView("redirect:../welcome/index.do");
			} catch (Throwable oops) {
				result = createEditModelAndView(urf, "register.commit.error");
			}
		}

		return result;
	}

	protected ModelAndView createEditModelAndView(RegistrationForm urf) {

		ModelAndView result;

		result = createEditModelAndView(urf, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(RegistrationForm urf, String message) {

		ModelAndView result = new ModelAndView("assembler/register");
		result.addObject("urf", urf);
		result.addObject("message", message);
		result.addObject("requestURI", "assembler/register.do");
		return result;
	}
}