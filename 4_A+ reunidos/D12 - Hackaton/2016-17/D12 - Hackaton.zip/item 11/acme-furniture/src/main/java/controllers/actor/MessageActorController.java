
package controllers.actor;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ActorService;
import services.FolderService;
import services.MessageService;
import controllers.AbstractController;
import domain.Actor;
import domain.Folder;
import domain.Message;

@Controller
@RequestMapping("/message/actor")
public class MessageActorController extends AbstractController {

	// Services =======================================================================================

	@Autowired
	private MessageService	messageService;

	@Autowired
	private ActorService	actorService;

	@Autowired
	private FolderService	folderService;


	// Constructors =======================================================================================

	public MessageActorController() {
		super();
	}

	//Show message ===========================================================================================

	@RequestMapping(value = "/showMessage", method = RequestMethod.GET)
	public ModelAndView view(@RequestParam final int messageId) {
		ModelAndView result;
		Message message;

		message = this.messageService.findMessage(messageId);

		result = new ModelAndView("message/actor/showMessage");

		result.addObject("mes", message);

		return result;
	}

	//Create ===========================================================================================

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		Message message;
		Actor sender;
		Collection<Actor> actors;

		sender = this.actorService.findByPrincipal();
		message = this.messageService.create(sender);
		actors = this.actorService.findAll();
		actors.remove(sender);

		result = new ModelAndView("message/actor/edit");

		result.addObject("men", message);
		result.addObject("actors", actors);
		result.addObject("requestURI", "message/actor/create.do");

		return result;
	}

	//Save ===========================================================================================

	@RequestMapping(value = "/create", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@ModelAttribute("men") @Valid final Message message, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(message);
		else
			try {
				this.messageService.save(message);

				result = new ModelAndView("redirect:/mailbox/actor/list.do");

			} catch (final Throwable oops) {
				result = this.createEditModelAndView(message, "message.commit.error");
			}
		return result;

	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(final Message message, final BindingResult binding) {
		ModelAndView result;

		try {
			this.messageService.delete(message);
			result = new ModelAndView("redirect:/mailbox/actor/list.do");
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(message, "message.commit.error");
		}

		return result;
	}

	@RequestMapping(value = "/moveTo", method = RequestMethod.GET)
	public ModelAndView moveMessageToFolder(@RequestParam final int targetFolderId, @RequestParam final int messageId, @RequestParam final int sourceFolderId) {
		ModelAndView result;
		Folder targetFolder;
		Folder sourceFolder;
		Message message;

		targetFolder = this.folderService.findOneByPrincipal(targetFolderId);
		sourceFolder = this.folderService.findOneByPrincipal(sourceFolderId);
		message = this.messageService.findMessage(messageId);

		this.messageService.moveMessageToFolder(message, sourceFolder, targetFolder);
		result = new ModelAndView("redirect:/mailbox/actor/list.do");

		return result;

	}

	// Ancillary methods: Create ===========================================================================================

	protected ModelAndView createEditModelAndView(final Message message) {
		ModelAndView result;
		result = this.createEditModelAndView(message, null);
		return result;

	}

	protected ModelAndView createEditModelAndView(final Message men, final String message) {
		ModelAndView result;
		Collection<Actor> actors;
		Actor sender;

		sender = this.actorService.findByPrincipal();
		actors = this.actorService.findAll();
		actors.remove(sender);

		result = new ModelAndView("message/actor/edit");

		result.addObject("actors", actors);
		result.addObject("men", men);
		result.addObject("requestURI", "message/actor/create.do");
		result.addObject("message", message);

		return result;
	}

}
