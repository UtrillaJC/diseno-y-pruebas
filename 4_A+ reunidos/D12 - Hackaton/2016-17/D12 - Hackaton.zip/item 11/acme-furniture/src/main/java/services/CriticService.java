
package services;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Critic;
import domain.Critique;
import domain.Folder;
import domain.Message;
import forms.RegistrationForm;
import repositories.CriticRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;

@Service
@Transactional
public class CriticService {

	//Managed Repository =============================================================================

	@Autowired
	private CriticRepository	criticRepository;


	//Supported Services =============================================================================
	@Autowired
	private FolderService folderService;
	
	@Autowired
	private AdministratorService administratorService;
	//Constructor methods ============================================================================

	public CriticService() {
		super();
	}

	//Simple CRUD methods ============================================================================
	public Critic create() {

		Critic c = new Critic();
		UserAccount ua = new UserAccount();
		Collection<Critique> votedCritiques;
		Collection<Critique> critiques;
		Collection<Folder> folders;
		Collection<Message> sentMessages;
		Collection<Message> receivedMessages;
		
		ua.setUsername("");
		ua.setPassword("");
		critiques = new ArrayList<Critique>();
		votedCritiques = new ArrayList<Critique>();
		folders = new ArrayList<Folder>();
		sentMessages = new ArrayList<Message>();
		receivedMessages = new ArrayList<Message>();

		Authority auth = new Authority();
		auth.setAuthority("CRITIC");

		ua.addAuthority(auth);
		c.setUserAccount(ua);
		c.setCritiques(critiques);
		c.setVotedCritiques(votedCritiques);

		c.setReceivedMessages(receivedMessages);
		c.setSentMessages(sentMessages);
		c.setFolders(folders);
		return c;
	}
	
	public Critic reconstruct(RegistrationForm crf) {
		administratorService.checkPrincipal();
		Critic c = create();
		
		c.getUserAccount().setUsername(crf.getUsername());
		c.getUserAccount().setPassword(crf.getPassword());
		
		c.setName(crf.getName());
		c.setSurname(crf.getSurname());
		c.setEmail(crf.getEmail());
		c.setPhone(crf.getPhone());
		c.setAddress(crf.getAddress());
		
		return c;
	}

	public Critic save(Critic c) {
		Critic result;
		UserAccount ua = c.getUserAccount();
		Md5PasswordEncoder md5PasswordEncoder = new Md5PasswordEncoder();
		String pass = md5PasswordEncoder.encodePassword(ua.getPassword(), null);
		ua.setPassword(pass);
		c.setUserAccount(ua);
		
		result = criticRepository.saveAndFlush(c);
		folderService.createDefaultFolders(result);

		
		return result;
	}
	//Other Business Methods =========================================================================

	public Critic findByPrincipal() {
		Critic result;
		UserAccount userAccount;

		userAccount = LoginService.getPrincipal();
		Assert.notNull(userAccount);
		result = this.findByUserAccount(userAccount);
		Assert.notNull(result);

		return result;
	}

	public Critic findByUserAccount(final UserAccount userAccount) {
		Critic result;

		result = this.criticRepository.findByUserAccountId(userAccount.getId());

		return result;
	}

	
	public Collection<Critic> criticMoreCritiquesPositive(){
		administratorService.checkPrincipal();
		
		return criticRepository.criticMoreCritiquesPositive();
		
	}
	
	public Collection<Critic> criticMoreCritiquesNeutral(){
		administratorService.checkPrincipal();
		
		return criticRepository.criticMoreCritiquesNeutral();
		
	}
	
	public Collection<Critic> criticMoreCritiquesNegative(){
		administratorService.checkPrincipal();
		
		return criticRepository.criticMoreCritiquesNegative();
		
	}
}
