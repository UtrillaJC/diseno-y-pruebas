
package controllers.assembler;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import controllers.AbstractController;
import domain.Confidence;
import domain.Maker;
import domain.Review;
import services.MakerService;
import services.ReviewService;

@Controller
@RequestMapping("/review/assembler")
public class ReviewAssemblerController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private ReviewService		reviewService;

	@Autowired
	private MakerService		makerService;



	// Constructors ========================================================================

	public ReviewAssemblerController() {
		super();
	}

	//List my reviews ========================================================================================

	@RequestMapping(value = "/myList", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Review> reviews;

		reviews = this.reviewService.findReviewsByAssembler();

		result = new ModelAndView("review/assembler/list");

		result.addObject("reviews", reviews);
		result.addObject("requestURI", "review/assembler/myList.do");

		return result;
	}

	//List by maker ========================================================================================

	@RequestMapping(value = "/listByMaker", method = RequestMethod.GET)
	public ModelAndView listByMaker(@RequestParam final int makerId) {
		ModelAndView result;
		Collection<Review> reviews;

		reviews = this.reviewService.findReviewsByMakerId(makerId);

		result = new ModelAndView("review/assembler/listByMaker");

		result.addObject("reviews", reviews);
		result.addObject("requestURI", "review/assembler/listByMaker.do");

		return result;
	}

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam final int makerId) {
		ModelAndView result;
		Review review;
		Maker maker;

		maker = this.makerService.findOne(makerId);
		review = this.reviewService.create(maker);

		result = this.createEditModelAndView(review);

		return result;
	}

	// Edition ---------------------------------------------------------------
	@RequestMapping(value = "/create", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@ModelAttribute("reviewAssembler") @Valid final Review reviewAssembler, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(reviewAssembler);
		else
			try {

				this.reviewService.save(reviewAssembler);

				result = new ModelAndView("redirect:myList.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(reviewAssembler, "review.commit.error");
			}

		return result;
	}

	// Ancillary methods: Create ===========================================================================================

	protected ModelAndView createEditModelAndView(final Review review) {
		ModelAndView result;
		result = this.createEditModelAndView(review, null);
		return result;

	}

	protected ModelAndView createEditModelAndView(final Review review, final String message) {
		ModelAndView result;

		final List<Confidence> confidences = Arrays.asList(Confidence.values());
		result = new ModelAndView("review/assembler/create");

		result.addObject("reviewAssembler", review);
		result.addObject("message", message);
		result.addObject("confidences", confidences);
		return result;
	}

}
