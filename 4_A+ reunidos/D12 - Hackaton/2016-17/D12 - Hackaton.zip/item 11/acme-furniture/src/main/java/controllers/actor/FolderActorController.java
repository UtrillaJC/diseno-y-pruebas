
package controllers.actor;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import controllers.AbstractController;
import domain.Actor;
import domain.Folder;
import services.ActorService;
import services.FolderService;

@Controller
@RequestMapping("/folder/actor")
public class FolderActorController extends AbstractController {

	// Services =======================================================================================

	@Autowired
	private ActorService	actorService;

	@Autowired
	private FolderService	folderService;


	// Constructors =======================================================================================

	public FolderActorController() {
		super();
	}

	// List =======================================================================================

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Folder> folders;
		Actor principal;
		Boolean children;

		principal = this.actorService.findByPrincipal();
		folders = this.folderService.findAllByActor(principal);
		children = false;

		result = new ModelAndView("folder/list");

		result.addObject("folders", folders);
		result.addObject("requestURI", "folder/actor/list.do");
		result.addObject("children", children);

		return result;
	}

	// Create folder =======================================================================================

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		Folder folder;
		Actor principal;
		Boolean isNew;

		principal = this.actorService.findByPrincipal();
		folder = this.folderService.createByActor(principal);
		isNew = true;

		result = new ModelAndView("folder/create");

		result.addObject("folder", folder);
		result.addObject("requestURI", "folder/actor/create.do");
		result.addObject("isNew", isNew);

		return result;
	}

	// Save create folder =======================================================================================

	@RequestMapping(value = "/create", method = RequestMethod.POST, params = "save")
	public ModelAndView saveCreate(@Valid final Folder folder, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors()) {
			System.out.println(binding.getAllErrors());
			result = this.createModelAndView(folder);
		} else
			try {
				this.folderService.saveFolderByActor(folder);

				result = new ModelAndView("redirect:../../folder/actor/list.do");

			} catch (final Throwable oops) {
				result = this.createModelAndView(folder, "folder.commit.error");
			}
		return result;

	}

	// Edit folder =======================================================================================

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int folderId) {
		ModelAndView result;
		Folder folder;
		Actor principal;
		Boolean isNew;
		Boolean isOwner;
		Boolean eraseable;
		Boolean systemFolder;
		
		principal = this.actorService.findByPrincipal();
		
		try {
		folder = this.folderService.findOneByPrincipal(folderId);

		isNew = false;
		isOwner = folder.getActor().equals(principal);
		eraseable = folder.getMessages().isEmpty() && !folder.getPredefined();
		systemFolder = folder.getPredefined();

		result = new ModelAndView("folder/edit");
		
		result.addObject("folder", folder);
		result.addObject("requestURI", "folder/actor/edit.do");
		result.addObject("isNew", isNew);
		result.addObject("isOwner", isOwner);
		result.addObject("eraseable", eraseable);
		result.addObject("folderId", folderId);
		result.addObject("systemFolder", systemFolder);
		} catch (final Throwable oops) {
			Folder folder2 = folderService.create(principal);
			result = new ModelAndView("folder/edit");

			isNew = false;
			isOwner = folder2.getActor().equals(principal);
			eraseable = folder2.getMessages().isEmpty() && !folder2.getPredefined();
			systemFolder = folder2.getPredefined();


			result.addObject("folder2", folder2);
			result.addObject("requestURI", "folder/actor/edit.do");
			result.addObject("isNew", isNew);
			result.addObject("isOwner", isOwner);
			result.addObject("eraseable", eraseable);
			result.addObject("folderId", folderId);
			result.addObject("systemFolder", systemFolder);
		}
		return result;
	}
	// Save edit folder =======================================================================================

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView saveEdit(@Valid final Folder folder, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors()) {
			System.out.println(binding.getAllErrors());
			result = this.editModelAndView(folder);
		} else
			try {
				this.folderService.saveFolderByActor(folder);

				result = new ModelAndView("redirect:../../folder/actor/list.do");

			} catch (final Throwable oops) {
				result = this.editModelAndView(folder, "folder.commit.error");
			}
		return result;

	}

	// Delete folder ======================================================================================

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(final Folder folder, final BindingResult binding) {
		ModelAndView result;

		try {
			this.folderService.delete(folder);
			result = new ModelAndView("redirect:../../folder/actor/list.do");
		} catch (final Throwable oops) {
			result = this.editModelAndView(folder, "folder.commit.error");
		}

		return result;
	}

	// Move message to a folder =======================================================================================

	@RequestMapping(value = "/moveTo", method = RequestMethod.GET)
	public ModelAndView moveMessageToFolder(@RequestParam final int sourceFolderId, @RequestParam final int messageId) {
		ModelAndView result;
		Collection<Folder> folders;
		Actor principal;
		Folder actualFolder;

		principal = this.actorService.findByPrincipal();
		folders = this.folderService.findAllByActor(principal);
		actualFolder = this.folderService.findOneByPrincipal(sourceFolderId);

		folders.remove(actualFolder);

		result = new ModelAndView("folder/moveTo");
		result.addObject("folders", folders);
		result.addObject("requestURI", "folder/actor/moveTo.do?messageId=" + messageId);
		result.addObject("messageId", messageId);
		result.addObject("sourceFolderId", sourceFolderId);

		return result;

	}

	// Ancillary methods: Create folder =======================================================================================

	protected ModelAndView createModelAndView(final Folder folder) {
		ModelAndView result;
		result = this.createModelAndView(folder, null);
		return result;

	}

	protected ModelAndView createModelAndView(final Folder folder, final String message) {
		ModelAndView result;
		Boolean isNew;

		isNew = true;
		result = new ModelAndView("folder/create");

		result.addObject("folder", folder);
		result.addObject("requestURI", "folder/actor/create.do");
		result.addObject("message", message);
		result.addObject("isNew", isNew);

		return result;

	}

	// Ancillary methods: Edition =======================================================================================

	protected ModelAndView editModelAndView(final Folder folder) {
		ModelAndView result;
		result = this.editModelAndView(folder, null);
		return result;

	}

	protected ModelAndView editModelAndView(final Folder folder, final String errorMessage) {
		ModelAndView result;
		Actor principal;
		Boolean isNew;
		Boolean isOwner;
		Boolean eraseable;
		Boolean systemFolder;

		principal = this.actorService.findByPrincipal();
		isNew = false;
		isOwner = folder.getActor().equals(principal);
		eraseable = folder.getMessages().isEmpty() && !folder.getPredefined();
		systemFolder = folder.getPredefined();

		result = new ModelAndView("folder/create");

		result.addObject("errorMessage", errorMessage);
		result.addObject("folder", folder);
		result.addObject("requestURI", "folder/actor/edit.do");
		result.addObject("isNew", isNew);
		result.addObject("isOwner", isOwner);
		result.addObject("eraseable", eraseable);
		result.addObject("systemFolder", systemFolder);

		return result;
	}
}
