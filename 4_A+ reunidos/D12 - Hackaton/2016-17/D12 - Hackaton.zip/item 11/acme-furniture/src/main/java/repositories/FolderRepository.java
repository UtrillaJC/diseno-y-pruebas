
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Folder;

@Repository
public interface FolderRepository extends JpaRepository<Folder, Integer> {

	@Query("select f from Folder f where f.actor.id = ?1")
	Collection<Folder> findByActor(int actorId);

	@Query("select f from Folder f where f.actor.id=?1 and f.name='Inbox'")
	Folder findInboxByActorId(int actorId);

	@Query("select f from Folder f where f.actor.id=?1 and f.name='Outbox'")
	Folder findOutboxByActorId(int actorId);

	@Query("select f from Folder f where f.actor.id=?1 and f.name='Trashbox'")
	Folder findTrashboxByActorId(int actorId);

	@Query("select f from Folder f where f.actor.id=?1 and f.name='Spambox'")
	Folder findSpamboxByActorId(int actorId);

	@Query("select f from Folder f where f.actor.id=?1 and f.name=?2")
	Folder findFolderByActorByName(int actorId, String folderName);

}
