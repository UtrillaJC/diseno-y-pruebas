
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Access(AccessType.PROPERTY)
public class Piece extends DomainEntity {

	// Constructors -----------------------------------------------------------

	public Piece() {
		super();

	}


	// Attributes -------------------------------------------------------------

	private String	code;
	private double	price;
	private String	material;
	private String	description;


	@NotBlank
	@Column(unique = true)
	@Pattern(regexp = "\\d{6}-\\D{4}")
	public String getCode() {
		return this.code;
	}
	public void setCode(final String code) {
		this.code = code;
	}

	@Digits(integer = 99, fraction = 2)
	@Min(0)
	public double getPrice() {
		return this.price;
	}
	public void setPrice(final double price) {
		this.price = price;
	}

	@NotBlank
	public String getMaterial() {
		return this.material;
	}
	public void setMaterial(final String material) {
		this.material = material;
	}

	@NotBlank
	public String getDescription() {
		return this.description;
	}
	public void setDescription(final String description) {
		this.description = description;
	}


	// Relationships ----------------------------------------------------------

	private Furniture			furniture;
	private Collection<Back>	backs;


	@Valid
	@NotNull
	@ManyToOne(optional = false)
	public Furniture getFurniture() {
		return this.furniture;
	}
	public void setFurniture(final Furniture furniture) {
		this.furniture = furniture;
	}

	@Valid
	@NotNull
	@OneToMany(mappedBy = "piece", cascade = CascadeType.REMOVE)
	public Collection<Back> getBacks() {
		return this.backs;
	}

	public void setBacks(final Collection<Back> backs) {
		this.backs = backs;
	}

}
