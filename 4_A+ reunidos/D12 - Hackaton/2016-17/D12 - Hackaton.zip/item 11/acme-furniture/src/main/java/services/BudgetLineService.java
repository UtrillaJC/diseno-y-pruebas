
package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.BudgetLineRepository;
import domain.Acceptance;
import domain.BudgetLine;
import domain.Furniture;
import domain.Maker;

@Service
@Transactional
public class BudgetLineService {

	//Managed Repository =============================================================================

	@Autowired
	private BudgetLineRepository	budgetLineRepository;

	@Autowired
	private FurnitureService		furnitureService;

	@Autowired
	private CustomerService			customerService;

	@Autowired
	private AdministratorService	administratorService;

	@Autowired
	private AcceptanceService		acceptanceService;

	@Autowired
	private MakerService			makerService;


	//Supported Services =============================================================================

	//Constructor methods ============================================================================

	public BudgetLineService() {
		super();
	}

	public BudgetLine create() {
		final BudgetLine bl = new BudgetLine();
		//bl.setAcceptances(new HashSet<Acceptance>());

		return bl;

	}

	public BudgetLine save(final BudgetLine bl) {
		return this.budgetLineRepository.saveAndFlush(bl);

	}

	//Simple CRUD methods ============================================================================

	//Other Business Methods =========================================================================

	public BudgetLine findByPieceCodeAndBudget(final String code, final int budgetId) {
		return this.budgetLineRepository.findByPieceCodeAndBudget(code, budgetId);
	}

	public Collection<BudgetLine> findByFurniture(final int furnitureId) {
		final Furniture furniture = this.furnitureService.findOne(furnitureId);
		return this.budgetLineRepository.findByFurnitureCode(furniture.getCode());
	}

	public Collection<BudgetLine> findByFurnitureAndBudget(final int budgetId, final int furnitureId) {
		final Furniture furniture = this.furnitureService.findOne(furnitureId);
		return this.budgetLineRepository.findByFurnitureAndBudget(budgetId, furniture.getCode());
	}

	public void comment(final int id, final String comment) {

		final BudgetLine bl = this.budgetLineRepository.findOne(id);
		Assert.notNull(bl);
		Assert.isTrue(bl.getBudget().getCustomer().equals(this.customerService.findByPrincipal()));
		Assert.notNull(comment);
		bl.setComment(comment);
		this.save(bl);

	}

	public BudgetLine findOne(final int id) {

		return this.budgetLineRepository.findOne(id);
	}

	public Collection<String> findFurnitureCodeByCustomer(final int customerId) {
		Collection<String> result;

		result = this.budgetLineRepository.findAllFurnitureCodeByCustomerId(customerId);

		return result;
	}

	public Collection<BudgetLine> findAllWithPendingAceptance() {

		return this.budgetLineRepository.findAllWithPendingAceptance();
	}

	public Acceptance accept(final int id) {
		Assert.notNull(this.administratorService.findByPrincipal());
		final BudgetLine bl = this.findOne(id);
		Assert.notNull(bl.getComment());
		Assert.isTrue(!bl.getComment().isEmpty());
		Acceptance ac = this.acceptanceService.create();
		ac.setAccepted(true);
		final Maker m = this.makerService.findByFurnitureCode(bl.getFurnitureCode());
		ac.setMaker(m);
		ac.setBudgetLine(bl);
		ac = this.acceptanceService.save(ac);

		final EmailService emailService = new EmailService();

		final String asunto = "Cambio aceptado";
		final String cuerpo = "El cambio " + bl.getComment() + " para la pieza " + bl.getPieceCode() + " en el presupueto " + bl.getBudget().getName() + " ha sido aceptado";

		try {
			emailService.sendEmail(bl.getBudget().getCustomer().getEmail(), asunto, cuerpo);
		} catch (final Exception e) {
		}

		return ac;
	}
	public Acceptance deny(final int id) {
		Assert.notNull(this.administratorService.findByPrincipal());
		final BudgetLine bl = this.findOne(id);
		Acceptance ac = this.acceptanceService.create();
		ac.setAccepted(false);
		final Maker m = this.makerService.findByFurnitureCode(bl.getFurnitureCode());
		ac.setMaker(m);
		ac.setBudgetLine(bl);
		ac = this.acceptanceService.save(ac);

		final EmailService emailService = new EmailService();

		final String asunto = "Cambio denegado";
		final String cuerpo = "El cambio " + bl.getComment() + " para la pieza " + bl.getPieceCode() + " en el presupueto " + bl.getBudget().getName() + " ha sido denegado";

		try {
			emailService.sendEmail(bl.getBudget().getCustomer().getEmail(), asunto, cuerpo);
		} catch (final Exception e) {
		}

		return ac;
	}

}
