
package controllers.critic;

import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.CriticCardService;
import services.CriticService;
import controllers.AbstractController;
import domain.Critic;
import domain.CriticCard;
import domain.Level;


@Controller
@RequestMapping("/criticCard/critic")
public class CriticCardCriticController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private CriticService	criticService;
	
	@Autowired
	private CriticCardService	criticCardService;
	
	
	
	// Constructors ========================================================================

	public CriticCardCriticController() {
		super();
	}
	
	
	
	

	//List my CriticCard ========================================================================================

	@RequestMapping(value = "/show", method = RequestMethod.GET)
	public ModelAndView show() {
		ModelAndView result;
		CriticCard criticCard;
		Critic critic;
				
		critic = this.criticService.findByPrincipal();
		
		criticCard = this.criticCardService.findCriticCardByCritic();
		
		
		result = new ModelAndView("criticCard/critic/show");

		result.addObject("criticCard", criticCard);
		result.addObject("critic", critic);
		result.addObject("requestURI", "criticCard/critic/show.do");

		return result;
	}

	//Create ===========================================================================================

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		CriticCard criticCard;

				
		criticCard = this.criticCardService.create();

		result = new ModelAndView("criticCard/critic/edit");

		result.addObject("criticCard", criticCard);

		return result;
	}

	// Edition ---------------------------------------------------------------

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit() {
		ModelAndView result;
		CriticCard criticCard;
		
		criticCard = this.criticCardService.findCriticCardByCritic();

		result = this.createEditModelAndView(criticCard);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView edit(@Valid final CriticCard criticCard, final BindingResult binding) {
		ModelAndView result;


		if (binding.hasErrors())
			result = this.createEditModelAndView(criticCard);
		else
			try {
				
				this.criticCardService.save(criticCard);	
								
				result = new ModelAndView("redirect:show.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(criticCard, "criticCard.commit.error");
			}

		return result;
	}
	
	
	

	

	// Ancillary methods: Create ===========================================================================================

	protected ModelAndView createEditModelAndView(final CriticCard criticCard) {
		ModelAndView result;
		result = this.createEditModelAndView(criticCard, null);
		return result;

	}

	protected ModelAndView createEditModelAndView(final CriticCard criticCard, final String message) {
		ModelAndView result;

		final List<Level> levels = Arrays.asList(Level.values());
		result = new ModelAndView("criticCard/critic/edit");

		result.addObject("criticCard", criticCard);
		result.addObject("levels", levels);
		result.addObject("message", message);
		return result;
	}

}
