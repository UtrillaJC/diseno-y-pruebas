
package services;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.RatingRepository;
import domain.Customer;
import domain.Furniture;
import domain.Rating;

@Service
@Transactional
public class RatingService {

	//Managed Repository =============================================================================

	@Autowired
	private RatingRepository	ratingRepository;

	//Supported Services =============================================================================

	@Autowired
	private CustomerService		customerService;

	@Autowired
	private FurnitureService	furnitureService;


	//Constructor methods ============================================================================

	public RatingService() {
		super();
	}

	//Simple CRUD methods ============================================================================

	public Collection<Rating> findAll() {
		Collection<Rating> result;

		result = this.ratingRepository.findAll();

		return result;
	}

	public Rating findOne(final int ratingId) {
		Rating result;

		result = this.ratingRepository.findOne(ratingId);
		Assert.notNull(result);

		return result;
	}

	public Collection<Rating> findRatingsByCustomer() {
		Collection<Rating> result;
		Customer principal;

		principal = this.customerService.findByPrincipal();
		Assert.isInstanceOf(Customer.class, principal);

		result = principal.getRatings();

		return result;
	}

	public Collection<Rating> findRatingsByFurnitureId(final int furnitureId) {
		Collection<Rating> result;

		result = this.ratingRepository.findRatingsByFurnitureId(furnitureId);

		return result;
	}

	public Rating create(final Furniture furniture) {
		Rating result;
		Customer principal;

		principal = this.customerService.findByPrincipal();

		final Collection<Furniture> purchased = this.furnitureService.findAllByCustomer();
		Assert.isTrue(purchased.contains(furniture));

		Collection<Rating> ratings = new ArrayList<Rating>();

		result = new Rating();
		result.setFurniture(furniture);

		result.setCustomer(principal);
		ratings = principal.getRatings();
		ratings.add(result);
		principal.setRatings(ratings);

		return result;
	}

	public Rating save(final Rating rating) {
		Rating result;
		Customer principal;

		principal = this.customerService.findByPrincipal();

		Assert.isInstanceOf(Customer.class, principal);

		result = this.ratingRepository.saveAndFlush(rating);

		return result;
	}

	public void delete(final Rating r) {

		Assert.notNull(r);

		this.ratingRepository.delete(r);

	}

}
