
package controllers.assembler;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.MakerService;
import controllers.AbstractController;
import domain.Maker;

@Controller
@RequestMapping("/maker/assembler")
public class MakerAssemblerController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private MakerService	makerService;


	// Constructors ========================================================================

	public MakerAssemblerController() {
		super();
	}

	//List my critiques ========================================================================================

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Maker> makers;

		makers = this.makerService.findAll();

		result = new ModelAndView("maker/assembler/list");

		result.addObject("makers", makers);
		result.addObject("requestURI", "maker/assembler/list.do");

		return result;
	}
	
	
	//List my critiques ========================================================================================

	@RequestMapping(value = "/listToDoReview", method = RequestMethod.GET)
	public ModelAndView listToDoReview() {
		ModelAndView result;
		Collection<Maker> makers;

		makers = this.makerService.findMakersToDoReview();

		result = new ModelAndView("maker/assembler/listToDoReview");

		result.addObject("makers", makers);
		result.addObject("requestURI", "maker/assembler/listToDoReview.do");

		return result;
	}

}
