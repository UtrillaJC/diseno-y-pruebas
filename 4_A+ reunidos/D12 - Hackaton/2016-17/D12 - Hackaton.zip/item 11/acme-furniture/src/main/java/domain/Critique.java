
package domain;

import java.util.Collection;
import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Access(AccessType.PROPERTY)
@Table(indexes = {
	@Index(columnList = "type")
})
public class Critique extends DomainEntity {

	// Constructors -----------------------------------------------------------

	public Critique() {
		super();

	}


	// Attributes -------------------------------------------------------------

	private String	title;
	private Date	moment;
	private String	text;
	private Type	type;
	private int		fair;
	private int		unfair;
	private boolean	banned;


	@NotBlank
	public String getTitle() {
		return this.title;
	}
	public void setTitle(final String title) {
		this.title = title;
	}

	@Past
	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	public Date getMoment() {
		return this.moment;
	}
	public void setMoment(final Date moment) {
		this.moment = moment;
	}

	@NotBlank
	public String getText() {
		return this.text;
	}
	public void setText(final String text) {
		this.text = text;
	}

	public Type getType() {
		return this.type;
	}
	public void setType(final Type type) {
		this.type = type;
	}

	public int getFair() {
		return this.fair;
	}
	public void setFair(final int fair) {
		this.fair = fair;
	}

	public int getUnfair() {
		return this.unfair;
	}
	public void setUnfair(final int unfair) {
		this.unfair = unfair;
	}

	public boolean isBanned() {
		return this.banned;
	}
	public void setBanned(final boolean banned) {
		this.banned = banned;
	}


	// Relationships ----------------------------------------------------------

	private Critic				critic;
	private Collection<Critic>	critics;
	private Furniture			furniture;


	@Valid
	@ManyToOne(optional = false)
	public Critic getCritic() {
		return this.critic;
	}
	public void setCritic(final Critic critic) {
		this.critic = critic;
	}

	@NotNull
	@Valid
	@ManyToMany
	public Collection<Critic> getCritics() {
		return this.critics;
	}
	public void setCritics(final Collection<Critic> critics) {
		this.critics = critics;
	}

	@Valid
	@ManyToOne(optional = false)
	public Furniture getFurniture() {
		return this.furniture;
	}
	public void setFurniture(final Furniture furniture) {
		this.furniture = furniture;
	}

}
