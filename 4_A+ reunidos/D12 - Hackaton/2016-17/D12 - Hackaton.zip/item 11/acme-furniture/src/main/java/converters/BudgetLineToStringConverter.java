package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.BudgetLine;

@Component
@Transactional
public class BudgetLineToStringConverter implements Converter<BudgetLine, String>{
	
	@Override
	public String convert(BudgetLine budgetLine){
		String result;
		
		if(budgetLine == null)
			result = null;
		else
			result = String.valueOf(budgetLine.getId());
		
		return result;
	}

}
