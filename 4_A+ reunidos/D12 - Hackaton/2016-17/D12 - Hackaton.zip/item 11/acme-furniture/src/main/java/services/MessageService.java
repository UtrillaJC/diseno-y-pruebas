
package services;

import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.MessageRepository;
import domain.Actor;
import domain.Folder;
import domain.Message;
import domain.SpamTerm;

@Service
@Transactional
public class MessageService {

	//Managed Repository =============================================================================

	@Autowired
	private MessageRepository	messageRepository;

	//Supported Services =============================================================================

	@Autowired
	private ActorService		actorService;

	@Autowired
	private FolderService		folderService;

	@Autowired
	private SpamTermService		spamTermService;


	//Constructor methods ============================================================================

	public MessageService() {
		super();
	}

	//Simple CRUD methods ============================================================================

	public Message findOne(final int messageId) {
		Message result;
		Actor principal;

		principal = this.actorService.findByPrincipal();

		result = this.messageRepository.findOne(messageId);

		if (result != null)
			Assert.isTrue(principal.equals(result.getRecipient()) || principal.equals(result.getSender()));

		return result;
	}

	public Message findMessage(final int messageId) {
		Message result;
		Actor principal;

		principal = this.actorService.findByPrincipal();

		result = this.messageRepository.findOne(messageId);

		Assert.isTrue(result.getRecipient().equals(principal) || result.getSender().equals(principal));

		return result;
	}

	public Message create(final Actor sender) {
		Assert.notNull(sender);
		Assert.isTrue(this.actorService.findByPrincipal().equals(sender));
		Message result;
		Folder folder;
		Date currentMoment;

		currentMoment = new Date(System.currentTimeMillis());
		folder = new Folder();
		result = new Message();
		folder = this.folderService.findOutboxByActor(sender);

		result.setSender(sender);
		result.setFolder(folder);
		result.setMoment(currentMoment);

		return result;
	}

	public Message save(final Message message) {
		Assert.notNull(message);
		Assert.notNull(message.getSender());
		Assert.isTrue(!message.getSender().equals(message.getRecipient()));
		Message result;
		Collection<SpamTerm> spamTerms;
		Actor principal;
		Folder inbox;
		Date moment;
		String subject;
		String body;
		boolean spam = false;

		principal = this.actorService.findByPrincipal();
		moment = new Date(System.currentTimeMillis() - 1000);

		message.setMoment(moment);

		if (message.getId() == 0) {
			Assert.isTrue(principal.equals(message.getSender()));
			spamTerms = this.spamTermService.findAll();
			subject = message.getSubject().toLowerCase();
			body = message.getBody().toLowerCase();

			for (final SpamTerm term : spamTerms)
				for (final String keyword : term.getKeywords())
					if (subject.contains(keyword.toLowerCase()) || body.contains(keyword.toLowerCase())) {
						spam = true;
						break;
					}

			if (spam)
				inbox = this.folderService.findSpamboxByActor(message.getRecipient());
			else
				inbox = this.folderService.findInboxByActor(message.getRecipient());

			result = this.messageRepository.save(message);

			message.setFolder(inbox);

			result = this.messageRepository.save(message);
		} else {
			Assert.isTrue(principal.equals(message.getSender()) || principal.equals(message.getRecipient()));
			result = this.messageRepository.save(message);
		}

		final EmailService emailService = new EmailService();
		//Mensaje para emisor

		final String asunto = "Tiene un mensaje nuevo";
		final String cuerpo = "Ha recibido un mensaje nuevo de parte de " + message.getSender().getName() + " en Acme Furniture.\n\nEl mensaje es el siguiente:\n\n" + message.getBody() + "\n\nPor favor, no responda a este email.";

		try {
			emailService.sendEmail(message.getRecipient().getEmail(), asunto, cuerpo);
		} catch (final Exception e) {
			e.printStackTrace();
			System.out.println("Fallo al enviar el email");
		}

		return result;
	}

	public void delete(final Message message) {
		Assert.notNull(message);
		Actor principal;
		Folder folder;

		principal = this.actorService.findByPrincipal();

		Assert.isTrue(principal.equals(message.getSender()) || principal.equals(message.getRecipient()));

		folder = message.getFolder();

		if (folder.getName().toLowerCase().equals("trashbox"))
			this.messageRepository.delete(message);
		else {
			final Folder trashbox = this.folderService.findTrashboxByActor(principal);
			this.moveMessageToFolder(message, folder, trashbox);
		}
	}
	public Message update(final Message message) {
		return this.messageRepository.saveAndFlush(message);
	}

	//Other Business Methods =========================================================================

	public Collection<Message> findByFolder(final Folder folder) {
		Assert.notNull(folder);
		Assert.isTrue(this.actorService.findByPrincipal().equals(folder.getActor()));
		Collection<Message> result;

		result = this.messageRepository.findByFolderId(folder.getId());

		return result;
	}

	public void moveMessageToFolder(final Message message, final Folder sourceFolder, final Folder targetFolder) {
		Assert.notNull(message);
		Assert.notNull(targetFolder);
		Assert.notNull(sourceFolder);

		Assert.isTrue(!targetFolder.equals(sourceFolder));
		Assert.isTrue(sourceFolder.getMessages().contains(message));
		Assert.isTrue(!targetFolder.getMessages().contains(message));

		Actor principal;
		principal = this.actorService.findByPrincipal();
		Assert.notNull(principal);

		Assert.isTrue(message.getSender().equals(principal) || message.getRecipient().equals(principal));
		Assert.isTrue(targetFolder.getActor().equals(principal));
		Assert.isTrue(sourceFolder.getActor().equals(principal));

		message.setFolder(targetFolder);

		this.save(message);
	}
}
