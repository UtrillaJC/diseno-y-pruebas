package utilities.validators;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import forms.RegistrationForm;

public class MatchPasswordsValidator implements ConstraintValidator<MatchPasswords, RegistrationForm> {

	@Override
	public void initialize(MatchPasswords constraintAnnotation) {

	}

	@Override
	public boolean isValid(RegistrationForm urf, ConstraintValidatorContext cvc) {

		return urf.getPassword().equals(urf.getVerifyPassword());
	}
}