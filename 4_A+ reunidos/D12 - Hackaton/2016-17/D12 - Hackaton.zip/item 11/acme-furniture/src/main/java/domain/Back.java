
package domain;

import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Access(AccessType.PROPERTY)
public class Back extends DomainEntity {

	// Constructors -----------------------------------------------------------

	public Back() {
		super();

	}


	// Attributes -------------------------------------------------------------

	private String	description;
	private Date	momentOldPiece;
	private Date	momentNewPiece;


	@Past
	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	public Date getMomentOldPiece() {
		return this.momentOldPiece;
	}
	public void setMomentOldPiece(final Date momentOldPiece) {
		this.momentOldPiece = momentOldPiece;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	public Date getMomentNewPiece() {
		return this.momentNewPiece;
	}
	public void setMomentNewPiece(final Date momentNewPiece) {
		this.momentNewPiece = momentNewPiece;
	}

	@NotBlank
	public String getDescription() {
		return this.description;
	}

	public void setDescription(final String description) {
		this.description = description;
	}


	// Relationships ----------------------------------------------------------

	private Maker	maker;
	private Piece	piece;


	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public Maker getMaker() {
		return this.maker;
	}
	public void setMaker(final Maker maker) {
		this.maker = maker;
	}

	@Valid
	@NotNull
	@ManyToOne(optional = false)
	public Piece getPiece() {
		return this.piece;
	}

	public void setPiece(final Piece piece) {
		this.piece = piece;
	}

}
