
package controllers;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.FurnitureService;
import domain.Furniture;

@Controller
@RequestMapping("/furniture")
public class FurnitureController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private FurnitureService	furnitureService;


	// Constructors ========================================================================

	public FurnitureController() {
		super();
	}

	//List ========================================================================================

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView listFurniture() {
		ModelAndView result;
		Collection<Furniture> furnitures;

		furnitures = this.furnitureService.findAll();

		result = new ModelAndView("furniture/list");

		result.addObject("furnitures", furnitures);
		result.addObject("requestURI", "furniture/list.do");

		return result;
	}

}
