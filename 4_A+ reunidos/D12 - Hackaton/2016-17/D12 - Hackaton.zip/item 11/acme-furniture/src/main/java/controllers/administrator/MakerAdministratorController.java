
package controllers.administrator;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import controllers.AbstractController;
import domain.Maker;
import services.MakerService;

@Controller
@RequestMapping("/maker/administrator")
public class MakerAdministratorController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private MakerService	makerService;


	// Constructors ========================================================================

	public MakerAdministratorController() {
		super();
	}

	//List my critiques ========================================================================================

	@RequestMapping(value = "/listAll", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Maker> makers;

		makers = this.makerService.findAll();

		result = new ModelAndView("maker/administrator/listAll");

		result.addObject("makers", makers);
		result.addObject("requestURI", "maker/administrator/listAll.do");

		return result;
	}

	//Create ===========================================================================================

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		Maker maker;

		maker = this.makerService.create();

		result = new ModelAndView("maker/administrator/edit");

		result.addObject("maker", maker);

		return result;
	}

	// Edition ---------------------------------------------------------------

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int makerId) {
		ModelAndView result;
		Maker maker;

		maker = this.makerService.findOne(makerId);

		result = this.createEditModelAndView(maker);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView edit(@Valid final Maker maker, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(maker);
		else
			try {

				this.makerService.save(maker);

				result = new ModelAndView("redirect:listAll.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(maker, "maker.commit.error");
			}

		return result;
	}

	

	// Ancillary methods: Create ===========================================================================================

	protected ModelAndView createEditModelAndView(final Maker maker) {
		ModelAndView result;
		result = this.createEditModelAndView(maker, null);
		return result;

	}

	protected ModelAndView createEditModelAndView(final Maker maker, final String message) {
		ModelAndView result;

		result = new ModelAndView("maker/administrator/edit");

		result.addObject("maker", maker);
		result.addObject("message", message);
		return result;
	}
}
