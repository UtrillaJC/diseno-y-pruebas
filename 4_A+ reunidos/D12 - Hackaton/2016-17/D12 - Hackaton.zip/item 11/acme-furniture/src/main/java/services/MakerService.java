
package services;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.MakerRepository;
import domain.Administrator;
import domain.Assembler;
import domain.Furniture;
import domain.Maker;

@Service
@Transactional
public class MakerService {

	//Managed Repository =============================================================================

	@Autowired
	private MakerRepository			makerRepository;

	//Supported Services =============================================================================

	@Autowired
	private AdministratorService	administratorService;
	
	@Autowired
	private AssemblerService	assemblerService;

	@Autowired
	private FurnitureService		furnitureService;


	//Constructor methods ============================================================================

	public MakerService() {
		super();
	}

	//Simple CRUD methods ============================================================================

	public Collection<Maker> findAll() {
		Collection<Maker> result;

		result = this.makerRepository.findAll();

		return result;
	}

	public Maker findOne(final int makerId) {
		Maker result;

		result = this.makerRepository.findOne(makerId);
		Assert.notNull(result);

		return result;
	}
	
	public Collection<Maker> findMakersToDoReview() {
		Collection<Maker> result;
		Assembler principal;
				
		principal = assemblerService.findByPrincipal();
		Assert.isInstanceOf(Assembler.class, principal);
		result = this.makerRepository.findMakersToDoReview(principal.getId());

		return result;
	}

	//Other Business Methods =========================================================================

	public Maker create() {
		Maker result;
		Administrator principal;

		final Collection<Furniture> furnitures = new ArrayList<Furniture>();
		principal = this.administratorService.findByPrincipal();
		Assert.isInstanceOf(Administrator.class, principal);
		result = new Maker();

		result.setFurnitures(furnitures);

		return result;
	}

	public Maker save(final Maker maker) {
		Maker result;
		Administrator principal;

		principal = this.administratorService.findByPrincipal();
		Assert.isInstanceOf(Administrator.class, principal);
		result = this.makerRepository.saveAndFlush(maker);

		return result;
	}

	public Maker findByFurnitureCode(final String code) {
		final Furniture f = this.furnitureService.findByCode(code);
		return f.getMaker();
	}

	//	public double averageRatingsPerFurnitureByMaker(final Maker maker) {
	//		double result = 0.;
	//		double aux = 0.;
	//
	//		final Collection<Furniture> furnitures = maker.getFurnitures();
	//
	//		if (furnitures.size() != 0) {
	//			for (final Furniture f : furnitures)
	//				aux += this.furnitureService.averageRatingsPerFurniture(f);
	//			result = aux / furnitures.size();
	//		} else
	//			result = 0.;
	//
	//		return result;
	//	}

}
