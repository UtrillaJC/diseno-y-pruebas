
package domain;

public enum Confidence {

	veryHigh, high, normal, low, veryLow

}
