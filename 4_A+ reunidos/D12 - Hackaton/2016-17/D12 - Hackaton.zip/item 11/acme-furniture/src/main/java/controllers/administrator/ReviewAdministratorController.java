
package controllers.administrator;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ReviewService;
import controllers.AbstractController;
import domain.Review;

@Controller
@RequestMapping("/review/administrator")
public class ReviewAdministratorController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private ReviewService	reviewService;


	// Constructors ========================================================================

	public ReviewAdministratorController() {
		super();
	}

	@RequestMapping(value = "/listByMaker", method = RequestMethod.GET)
	public ModelAndView listByMaker(@RequestParam final int makerId) {
		ModelAndView result;
		Collection<Review> reviews;

		reviews = this.reviewService.findReviewsByMakerId(makerId);

		result = new ModelAndView("review/administrator/listByMaker");

		result.addObject("reviews", reviews);
		result.addObject("requestURI", "review/administrator/listByMaker.do");

		return result;
	}

}
