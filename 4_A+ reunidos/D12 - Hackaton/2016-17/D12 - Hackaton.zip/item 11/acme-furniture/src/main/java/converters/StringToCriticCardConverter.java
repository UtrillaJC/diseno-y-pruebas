package converters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import repositories.CriticCardRepository;
import domain.CriticCard;

@Component
@Transactional
public class StringToCriticCardConverter implements Converter<String, CriticCard> {
	
	@Autowired CriticCardRepository criticCardRepository;
	
	@Override 
	public CriticCard convert(String text){
		
		CriticCard result;
		int id;
		
		try{
			if(StringUtils.isEmpty(text))
				result = null;
			else{
				id = Integer.valueOf(text);
				result = criticCardRepository.findOne(id);
			}
			
		} catch(Throwable oops){
			throw new IllegalArgumentException(oops);
		}
		
		return result;
	}

}
