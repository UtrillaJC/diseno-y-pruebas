
package controllers.critic;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.CritiqueService;
import controllers.AbstractController;
import domain.Critique;
import domain.Type;

@Controller
@RequestMapping("/critique/critic")
public class CritiqueCriticController extends AbstractController {

	// Services ============================================================================

	@Autowired
	private CritiqueService	critiqueService;


	// Constructors ========================================================================

	public CritiqueCriticController() {
		super();
	}

	//List my critiques ========================================================================================

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView listAllExceptMine() {
		ModelAndView result;
		Collection<Critique> critiques;

		critiques = this.critiqueService.findAllExceptMine();

		result = new ModelAndView("critique/critic/list");

		result.addObject("critiques", critiques);
		result.addObject("requestURI", "critique/critic/list.do");

		return result;
	}

	//List my critiques ========================================================================================

	@RequestMapping(value = "/myList", method = RequestMethod.GET)
	public ModelAndView listMyCritiques() {
		ModelAndView result;
		Collection<Critique> critiques;

		critiques = this.critiqueService.findCritiquesByCritic();

		result = new ModelAndView("critique/critic/myList");

		result.addObject("critiques", critiques);
		result.addObject("requestURI", "critique/critic/myList.do");

		return result;
	}

	//Create ===========================================================================================

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam final int furnitureId) {
		ModelAndView result;
		Critique critique;

		critique = this.critiqueService.create(furnitureId);

		result = this.createEditModelAndView(critique);

		return result;
	}

	// Edition ---------------------------------------------------------------

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int critiqueId) {
		ModelAndView result;
		Critique critique;

		critique = this.critiqueService.findOne(critiqueId);

		result = this.createEditModelAndView(critique);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Critique critique, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(critique);
		else
			try {

				this.critiqueService.save(critique);

				result = new ModelAndView("redirect:myList.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(critique, "critique.commit.error");
			}

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "update")
	public ModelAndView update(@Valid final Critique critique, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(critique);
		else
			try {
				this.critiqueService.update(critique);
				result = new ModelAndView("redirect:myList.do");

			} catch (final Throwable oops) {
				result = this.createEditModelAndView(critique, "critique.commit.error");
			}

		return result;
	}

	// Deleting ---------------------------------------------------------------

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(@ModelAttribute final Critique critique, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(critique);
		else
			try {
				this.critiqueService.delete(critique);

				result = new ModelAndView("redirect:myList.do");

			} catch (final Throwable oops) {
				result = this.createEditModelAndView(critique, "critique.commit.error");
			}
		return result;
	}

	// Fair & unfair --------------------------------------------------------------------------------

	@RequestMapping(value = "/fair", method = RequestMethod.GET)
	public ModelAndView fair(@RequestParam final int critiqueId) {
		ModelAndView result;
		final Critique critique = this.critiqueService.findOne(critiqueId);

		try {
			this.critiqueService.fair(critique);
			result = this.listAllExceptMine();
			result.addObject("messageOk", "fair.commit.ok");
		} catch (final Throwable oops) {
			result = this.listAllExceptMine();
			result.addObject("message", "fair.commit.error");
		}

		return result;
	}

	@RequestMapping(value = "/unfair", method = RequestMethod.GET)
	public ModelAndView unfair(@RequestParam final int critiqueId) {
		ModelAndView result;
		final Critique critique = this.critiqueService.findOne(critiqueId);

		try {
			this.critiqueService.unfair(critique);
			result = this.listAllExceptMine();
			result.addObject("messageOk", "unfair.commit.ok");
		} catch (final Throwable oops) {
			result = this.listAllExceptMine();
			result.addObject("message", "unfair.commit.error");
		}

		return result;
	}

	// Ancillary methods: Create ===========================================================================================

	protected ModelAndView createEditModelAndView(final Critique critique) {
		ModelAndView result;
		result = this.createEditModelAndView(critique, null);
		return result;

	}

	protected ModelAndView createEditModelAndView(final Critique critique, final String message) {
		ModelAndView result;

		final List<Type> types = Arrays.asList(Type.values());
		result = new ModelAndView("critique/critic/edit");

		result.addObject("critique", critique);
		result.addObject("message", message);
		result.addObject("types", types);
		return result;
	}

}
