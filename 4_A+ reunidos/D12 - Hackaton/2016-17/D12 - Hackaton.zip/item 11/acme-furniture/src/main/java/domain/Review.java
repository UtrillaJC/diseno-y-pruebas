
package domain;

import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Access(AccessType.PROPERTY)
public class Review extends DomainEntity {

	// Constructors -----------------------------------------------------------

	public Review() {
		super();

	}


	// Attributes -------------------------------------------------------------

	private Date		moment;
	private Confidence	confidence;
	private String		comment;


	@Past
	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	public Date getMoment() {
		return this.moment;
	}

	public void setMoment(final Date moment) {
		this.moment = moment;
	}

	public Confidence getConfidence() {
		return this.confidence;
	}

	public void setConfidence(final Confidence confidence) {
		this.confidence = confidence;
	}

	@NotBlank
	public String getComment() {
		return this.comment;
	}

	public void setComment(final String comment) {
		this.comment = comment;
	}


	// Relationships ------------------------------------------------------------------------------

	private Assembler	assembler;
	private Maker		maker;


	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public Assembler getAssembler() {
		return this.assembler;
	}

	public void setAssembler(final Assembler assembler) {
		this.assembler = assembler;
	}

	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public Maker getMaker() {
		return this.maker;
	}

	public void setMaker(final Maker maker) {
		this.maker = maker;
	}

}
