package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.Assembly;

@Component
@Transactional
public class AssemblyToStringConverter implements Converter<Assembly, String>{
	
	@Override
	public String convert(Assembly assemble){
		String result;
		
		if(assemble == null)
			result = null;
		else
			result = String.valueOf(assemble.getId());
		
		return result;
	}

}
