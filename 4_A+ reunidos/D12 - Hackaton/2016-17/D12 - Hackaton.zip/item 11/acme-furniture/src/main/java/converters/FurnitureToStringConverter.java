package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.Furniture;

@Component
@Transactional
public class FurnitureToStringConverter implements Converter<Furniture, String>{
	
	@Override
	public String convert(Furniture furniture){
		String result;
		
		if(furniture == null)
			result = null;
		else
			result = String.valueOf(furniture.getId());
		
		return result;
	}

}
