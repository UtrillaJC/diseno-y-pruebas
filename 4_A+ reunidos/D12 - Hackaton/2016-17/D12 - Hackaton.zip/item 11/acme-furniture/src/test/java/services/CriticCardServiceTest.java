
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;
import domain.CriticCard;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class CriticCardServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private CriticCardService	criticCardService;


	// Tests =======================================================================================

	//An actor who is authenticated as a critic must be able to:
	//Create a criticCard

	@Test
	public void driverCreateCriticCard() {

		final Object testingData[][] = {
			{
				"critic6", null
			//POSITIVO Critico logueado crea una trajeta de crititco suyo correctamente.
			}, {
				"customer1", IllegalArgumentException.class
			//NEGATIVO Usuario logueado crea una tarjeta de critico cuando no esta permitido hacerlo.
			}, {
				null, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado crea una tarjeta de critico que no es suyo.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateCreateCriticCard((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateCreateCriticCard(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.criticCardService.create();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	
	
	
	//An actor who is authenticated as a critic must be able to:
	//Modify his criticCard

	@Test
	public void driverModifyCriticCard() {

		final Object testingData[][] = {
			{
				"critic1", "Nuevo nombre", null
			//POSITIVO Critico logueado modifica su tarjeta de cr�tico correctamente.
			}, {
				"customer1", "Nuevo nombre",IllegalArgumentException.class
			//NEGATIVO Critico logueado modifica la tarjeta de cr�tico de otro cr�tico que no es �l.
			}, {
				null, "Nuevo nombre",IllegalArgumentException.class
			//NEGATIVO Usuario no logueado borra una tarjeta de cr�tico que no es suya.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateModifyCriticCard((String) testingData[i][0], (String) testingData[i][1],(Class<?>) testingData[i][2]);
	}

	public void templateModifyCriticCard(final String username, final String name, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			CriticCard criticCard;
			criticCard = this.criticCardService.findOne(2136);
			criticCard.setSchool(name);
			
			this.criticCardService.save(criticCard);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	
	

}
