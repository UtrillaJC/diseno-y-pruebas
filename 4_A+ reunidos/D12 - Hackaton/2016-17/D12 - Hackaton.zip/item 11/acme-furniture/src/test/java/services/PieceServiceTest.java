
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;
import domain.Furniture;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class PieceServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private PieceService	pieceService;
	
	@Autowired
	private FurnitureService	furnitureService;


	// Tests =======================================================================================

	//An actor who is not authenticated must be able to:
	//List the pieces of a furniture

	@Test
	public void driverListByFuniture() {

		final Object testingData[][] = {
			{
				2089, null
			//POSITIVO, se le a�ade al m�todo un id de un Furniture
			}, {
				1, IllegalArgumentException.class
			//NEGATIVO, se le a�ade al m�todo un id que no es de un Furniture
			}, {
				2, IllegalArgumentException.class
			//NEGATIVO, se le a�ade al m�todo un id que no es de un Furniture
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateListByFuniture((Integer) testingData[i][0],(Class<?>) testingData[i][1]);
	}

	public void templateListByFuniture(final Integer integer, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			
			Furniture furniture;
			furniture = this.furnitureService.findOne(integer);
			this.pieceService.findAllByFurniture(furniture.getId());
			

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	
	

	

}
