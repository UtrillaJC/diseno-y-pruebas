
package services;

import java.net.MalformedURLException;

import javax.validation.ConstraintViolationException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import domain.Actor;
import domain.Folder;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class FolderServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private ActorService actorService;
	
	@Autowired
	private FolderService folderService;


	// Tests =======================================================================================

	// A user who is authenticated:
	//crear una carpeta
	
	@Test
	public void driverCreateFolder() throws MalformedURLException {

		final Object testingData[][] = {
			{
				"customer1", "nueva", null
			//POSITIVO Usuario logueado como customer1 crea una carpeta.
			},{
				null, "nueva",  IllegalArgumentException.class
			//NEGATIVO1 Usuario NO logueado crea una carpeta.
			},{
				"customer1", null,  ConstraintViolationException.class
			//NEGATIVO1 Usuario NO logueado crea una carpeta.
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.templateCreateFolder((String) testingData[i][0], (String) testingData[i][1], (Class<?>) testingData[i][2]);
	}
	public void templateCreateFolder(final String username,final String nameFolder, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		
		try {
			this.authenticate(username);
			Actor principal = actorService.findByPrincipal();
			
			final Folder folder = this.folderService.create(principal);
			folder.setName(nameFolder);
			this.folderService.save(folder);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	// A user who is authenticated :
	// Delete a folder

	@Test
	public void driverDeleteFolder() {
		

		final Object testingData[][] = {
			{
				"customer1", null
			//POSITIVO Usuario logueado borra una carpeta suya correctamente.
			}, {
				null, IllegalArgumentException.class
			//NEGATIVO1 Usuario no logueado.
			}, {
				"customer2", IllegalArgumentException.class
			//NEGATIVO2 Usuario logueado borra carpeta que no es suya
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateDeleteFolder((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateDeleteFolder(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate("customer1");
			Actor customer1=actorService.findByPrincipal();
			Folder folderCustomer1 = folderService.createByActor(customer1);
			folderCustomer1.setName("folderCustomer1");			
			folderService.save(folderCustomer1);
			this.unauthenticate();
			
			this.authenticate(username);
			this.folderService.delete(folderCustomer1);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}


}
