
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;
import domain.Furniture;
import domain.Rating;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class RatingServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private RatingService		ratingService;

	@Autowired
	private FurnitureService	furnitureService;


	// Tests =======================================================================================

	//An actor who is authenticated as a Customer must be able to:
	//List ratings by customer

	@Test
	public void driverFindRatingsByCustomer() {

		final Object testingData[][] = {
			{
				"customer1", null
			//POSITIVO Customer logueado lista sus ratings correctamente.
			}, {
				"admin", IllegalArgumentException.class
			//NEGATIVO Administrator logueado no puede listar sus ratings.
			}, {
				null, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado no puede listar sus ratings.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateFindRatingsByCustomer((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateFindRatingsByCustomer(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.ratingService.findRatingsByCustomer();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//An actor who is not authenticated must be able to:
	//List ratings by maker

	//	@Test
	//	public void driverFindRatingsByMaker() {
	//
	//		final Object testingData[][] = {
	//			{
	//				1180, null
	//			//POSITIVO, se le a�ade al m�todo un id de un Furniture
	//			}, {
	//				1, IllegalArgumentException.class
	//			//NEGATIVO, se le a�ade al m�todo un id que no es de un Furniture
	//			}, {
	//				2, IllegalArgumentException.class
	//			//NEGATIVO, se le a�ade al m�todo un id que no es de un Furniture
	//			}
	//
	//		};
	//
	//		for (int i = 0; i < testingData.length; i++)
	//			this.templateFindRatingsByMaker((Integer) testingData[i][0],(Class<?>) testingData[i][1]);
	//	}
	//
	//	public void templateFindRatingsByMaker(final Integer integer, final Class<?> expected) {
	//		Class<?> caught;
	//
	//		caught = null;
	//
	//		try {
	//			
	//			Maker maker;
	//			maker = this.makerService.findOne(integer);
	//			this.ratingService.findRatingsByMaker(maker);
	//			
	//
	//		} catch (final Throwable oops) {
	//			caught = oops.getClass();
	//		}
	//		this.checkExceptions(expected, caught);
	//	}
	//	

	//An actor who is authenticated as a customer must be able to:
	//Create a rating

	@Test
	public void driverCreateRating() {

		final Object testingData[][] = {
			{
				"customer1", null
			//POSITIVO Customer logueado crea un rating suyo correctamente.
			}, {
				"admin", IllegalArgumentException.class
			//NEGATIVO Administrador logueado crea un rating cuando no esta permitido hacerlo.
			}, {
				null, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado crea un rating que no es suyo.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateCreateRating((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateCreateRating(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final Furniture furniture = this.furnitureService.findOne(2089);
			this.ratingService.create(furniture);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//An actor who is authenticated as a customer must be able to:
	//Create a rating

	@Test
	public void driverModifyingRating() {

		final Object testingData[][] = {
			{
				"customer1", null
			//POSITIVO Customer logueado crea un rating suyo correctamente.
			}, {
				"admin", IllegalArgumentException.class
			//NEGATIVO Administrador logueado crea un rating cuando no esta permitido hacerlo.
			}, {
				null, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado crea un rating que no es suyo.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateModifyingRating((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateModifyingRating(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			Furniture furniture;
			Rating rating;

			furniture = this.furnitureService.findOne(2089);
			rating = this.ratingService.create(furniture);
			this.ratingService.save(rating);

			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

}
