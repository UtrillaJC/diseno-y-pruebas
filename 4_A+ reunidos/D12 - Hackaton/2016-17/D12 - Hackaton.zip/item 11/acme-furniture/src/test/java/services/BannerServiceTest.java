
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;
import domain.Banner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class BannerServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private BannerService	bannerService;


	// Tests =======================================================================================

	//An actor who is authenticated as a administrator must be able to:
	//Modifying banner

	@Test
	public void driverModifyingBanner() {

		final Object testingData[][] = {
			{
				"admin", "https://revistamuebles.com/wp-content/2013/06/Mesita-noche-y-armario-amarillos.jpg", null
			//POSITIVO Administrator logueado edita un banner correctamente.
			}, 
			{
				"customer1", "https://revistamuebles.com/wp-content/2013/06/Mesita-noche-y-armario-amarillos.jpg", IllegalArgumentException.class
			//NEGATIVO Usuario logueado edita un banner, lo cual no puede hacer.
			}, {
				null, "https://revistamuebles.com/wp-content/2013/06/Mesita-noche-y-armario-amarillos.jpg", IllegalArgumentException.class
			//NEGATIVO Usuario no logueado edita un banner que no es suyo.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateModifyingBanner((String) testingData[i][0], (String) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateModifyingBanner(final String username, final String text, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			Banner banner;
			banner = this.bannerService.findOne(1937);
			banner.setText(text);

			this.bannerService.save(banner);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	

}
