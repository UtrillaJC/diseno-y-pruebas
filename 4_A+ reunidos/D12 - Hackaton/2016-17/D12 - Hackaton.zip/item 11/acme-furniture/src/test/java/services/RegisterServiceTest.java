
package services;

import javax.validation.ConstraintViolationException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import forms.RegistrationForm;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class RegisterServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private CustomerService	customerService;
	

	@Autowired
	private AssemblerService	assemblerService;
	
	@Autowired
	private CriticService	criticService;


	// Tests =======================================================================================



	//	A user who is not authenticated must be able to:
	//	Register to the system as a customer.
	@Test
	public void driverCustomerRegisterForm() {

		final Object testingData[][] = {
			// Register to the system as a user
			{
				true, "customer10", "password1", "password1", "name1", "surname1", "address","+34 636435557", "email@gmail.es", null
			//Nos registramos en el sistema con todos los datos correctos.POSITIVO1.	
	
			},{
				true,  "customer11", "password1", "password1", null, "surname1", "address","+34 636435557", "email@gmail.es", ConstraintViolationException.class
				//No introducimos nombre.NEGATIVO1.			

			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateCustomerRegisterForm((Boolean) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (String) testingData[i][3], (String) testingData[i][4], (String) testingData[i][5], (String) testingData[i][6],
				(String) testingData[i][7], (String) testingData[i][8], (Class<?>) testingData[i][9]);
	}

	public void templateCustomerRegisterForm(final Boolean contractAccepted, final String username, final String password,
			final String verifyPassword, final String name, final String surname,  final String address,
			final String phone, final String email, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			final RegistrationForm urf = new RegistrationForm();
			urf.setAcceptTerms(contractAccepted);
			urf.setUsername(username);
			urf.setPassword(password);
			urf.setVerifyPassword(verifyPassword);
			urf.setName(name);
			urf.setSurname(surname);
			urf.setAddress(address);
			urf.setPhone(phone);
			urf.setEmail(email);

			this.customerService.save(this.customerService.reconstruct(urf));

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}


	//	A user who is not authenticated must be able to:
	//	Register to the system as a assembler.
	@Test
	public void driverAssemblerRegisterForm() {

		final Object testingData[][] = {
			// Register to the system as a assembler
			{
				true, "assembler10", "password1", "password1", "name1", "surname1", "address","+34 636435557", "email@gmail.es", null
			//Nos registramos en el sistema con todos los datos correctos.POSITIVO1.	
	
			},{
				true,  "assembler11", "password1", "password1", null, "surname1", "address","+34 636435557", "email@gmail.es", ConstraintViolationException.class
				//No introducimos nombre.NEGATIVO1.			

			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateAssemblerRegisterForm((Boolean) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (String) testingData[i][3], (String) testingData[i][4], (String) testingData[i][5], (String) testingData[i][6],
				(String) testingData[i][7], (String) testingData[i][8], (Class<?>) testingData[i][9]);
	}

	public void templateAssemblerRegisterForm(final Boolean contractAccepted, final String username, final String password,
			final String verifyPassword, final String name, final String surname,  final String address,
			final String phone, final String email, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			final RegistrationForm urf = new RegistrationForm();
			urf.setAcceptTerms(contractAccepted);
			urf.setUsername(username);
			urf.setPassword(password);
			urf.setVerifyPassword(verifyPassword);
			urf.setName(name);
			urf.setSurname(surname);
			urf.setAddress(address);
			urf.setPhone(phone);
			urf.setEmail(email);

			this.assemblerService.save(this.assemblerService.reconstruct(urf));

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//	A user who is authenticated as administrator must be able to:
	//	Register to the system as a customer.
	@Test
	public void driverCriticRegisterForm() {

		final Object testingData[][] = {
			// Register to the system as a assembler
			{
				true, "critic10", "password1", "password1", "name1", "surname1", "address","+34 636435557", "email@gmail.es","admin", null
			//Nos registramos en el sistema con todos los datos correctos.POSITIVO1.	
	
			},{
				true,  "critic11", "password1", "password1", "name1", "surname1", "address","+34 636435557", "email@gmail.es", null,  IllegalArgumentException.class
			//No logueado.NEGATIVO1.	

			},{
				true,  "critic11", "password1", "password1", "name1", "surname1", "address","+34 636435557", "email@gmail.es", "assembler1",  IllegalArgumentException.class
			//logueado como assembler.NEGATIVO2.			

			},{
				true,  "critic11", "password1", "password1", "name1", "surname1", "address","+34 636435557", "email@gmail.es", "customer1",  IllegalArgumentException.class
			//logueado como customer.NEGATIVO3.			

			},{
				true,  "critic11", "password1", "password1", "name1", "surname1", "address","+34 636435557", "emailgmail.es", "admin",  ConstraintViolationException.class
			//URL inv�lida.NEGATIVO4.			
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.templateCriticRegisterForm((Boolean) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (String) testingData[i][3], (String) testingData[i][4], (String) testingData[i][5], (String) testingData[i][6],
				(String) testingData[i][7], (String) testingData[i][8],  (String) testingData[i][9], (Class<?>) testingData[i][10]);
	}

	public void templateCriticRegisterForm(final Boolean contractAccepted, final String username, final String password,
			final String verifyPassword, final String name, final String surname,  final String address,
			final String phone, final String email, String admin, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			

			this.authenticate(admin);
			final RegistrationForm urf = new RegistrationForm();
			urf.setAcceptTerms(contractAccepted);
			urf.setUsername(username);
			urf.setPassword(password);
			urf.setVerifyPassword(verifyPassword);
			urf.setName(name);
			urf.setSurname(surname);
			urf.setAddress(address);
			urf.setPhone(phone);
			urf.setEmail(email);
			this.criticService.save(this.criticService.reconstruct(urf));

			this.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
}
