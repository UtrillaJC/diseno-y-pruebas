
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;
import domain.Back;
import domain.Piece;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class BackServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private BackService		backService;

	@Autowired
	private PieceService	pieceService;


	// Tests =======================================================================================

	@Test
	public void driverCreateBack() {

		final Object testingData[][] = {
			{
				"admin", "Description", null
			//POSITIVO Administrator logueado crea un Back
			}, {
				"customer1", "Description", IllegalArgumentException.class
			//NEGATIVO Usuario logueado crea un Back, lo cual no puede hacer.
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.templateCreateBack((String) testingData[i][0], (String) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateCreateBack(final String username, final String description, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final Back back;
			final Piece piece = this.pieceService.findOne(2104);
			back = this.backService.create(piece);
			back.setDescription(description);

			this.backService.save(back);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
}
