
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class DashboardServiceTest extends AbstractTest {

	@Autowired
	private IncidenceService incidenceService;

	@Autowired
	private BudgetService budgetService;
	
	@Autowired
	private BackService backService;

	@Autowired
	private CriticService criticService;
	
	@Autowired
	private CritiqueService critiqueService;
	
	// The SUT ====================================================================================

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			El m�ximo de incidencias por mueble
	@Test
	public void driverMaxIncidence() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"customer1", IllegalArgumentException.class
			//logueado como un customer. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateMaxIncidence((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateMaxIncidence(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.incidenceService.maxIncidence();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	// The SUT ====================================================================================

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			El m�nimo de incidencias por mueble
	@Test
	public void driverMinIncidence() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"customer1", IllegalArgumentException.class
			//logueado como un customer. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateMinIncidence((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateMinIncidence(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.incidenceService.minIncidence();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	// The SUT ====================================================================================

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			La media de incidencias por mueble
	@Test
	public void driverAvgIncidence() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"customer1", IllegalArgumentException.class
			//logueado como un customer. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateAvgIncidence((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateAvgIncidence(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.incidenceService.avgIncidence();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	// The SUT ====================================================================================

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			El m�nimo de presupuestos por cliente
	@Test
	public void driverMinBudgetsByCustomer() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"customer1", IllegalArgumentException.class
			//logueado como un customer. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateMinBudgetsByCustomer((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateMinBudgetsByCustomer(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.budgetService.minBudgetsByCustomer();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	// The SUT ====================================================================================

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			El m�ximo de presupuestos por cliente
	@Test
	public void driverMaxBudgetsByCustomer() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"customer1", IllegalArgumentException.class
			//logueado como un customer. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateMaxBudgetsByCustomer((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateMaxBudgetsByCustomer(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.budgetService.maxBudgetsByCustomer();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	
	// The SUT ====================================================================================

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			La media de presupuestos por cliente
	@Test
	public void driverAvgBudgetsByCustomer() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"customer1", IllegalArgumentException.class
			//logueado como un customer. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateAvgBudgetsByCustomer((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateAvgBudgetsByCustomer(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.budgetService.avgBudgetsByCustomer();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	// The SUT ====================================================================================

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			El m�nimo de criticas por mueble
	@Test
	public void driverMinCritique() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"customer1", IllegalArgumentException.class
			//logueado como un customer. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateMinCritique((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateMinCritique(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.critiqueService.minCritique();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	
	// The SUT ====================================================================================

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			El m�ximo de criticas por mueble
	@Test
	public void driverMaxCritique() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"customer1", IllegalArgumentException.class
			//logueado como un customer. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateMaxCritique((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateMaxCritique(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.critiqueService.maxCritique();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	
	// The SUT ====================================================================================

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			La media de criticas por mueble
	@Test
	public void driverAvgCritique() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"customer1", IllegalArgumentException.class
			//logueado como un customer. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateAvgCritique((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateAvgCritique(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.critiqueService.avgCritique();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	// The SUT ====================================================================================

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			El fabricante con m�s devoluciones
	@Test
	public void driverMakerMoreBacks() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"customer1", IllegalArgumentException.class
			//logueado como un customer. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateMakerMoreBacks((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateMakerMoreBacks(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.backService.makerMoreBacks();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	// The SUT ====================================================================================

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			El fabricante con menos devoluciones
	@Test
	public void driverLessMoreBacks() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"customer1", IllegalArgumentException.class
			//logueado como un customer. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateMakerLessBacks((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateMakerLessBacks(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.backService.makerMoreBacks();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	// The SUT ====================================================================================

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			El cr�tico con mas cr�ticas positivas
	@Test
	public void driverCriticMoreCritiquesPositive() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"customer1", IllegalArgumentException.class
			//logueado como un customer. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateCriticMoreCritiquesPositive((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateCriticMoreCritiquesPositive(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.criticService.criticMoreCritiquesPositive();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	// The SUT ====================================================================================

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			El cr�tico con mas cr�ticas neutral
	@Test
	public void driverCriticMoreCritiquesNeutral() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"customer1", IllegalArgumentException.class
			//logueado como un customer. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateCriticMoreCritiquesNeutral((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateCriticMoreCritiquesNeutral(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.criticService.criticMoreCritiquesNeutral();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	// The SUT ====================================================================================

	//	An actor who is authenticated as an administrator must be able to:
	//		Display a dashboard with the following information:
	//			El cr�tico con mas cr�ticas negative
	@Test
	public void driverCriticMoreCritiquesNegative() {
		final Object testingData[][] = {
			{
				"admin", null
			//logueado como un administrador. Positivo
			}, {
				"customer1", IllegalArgumentException.class
			//logueado como un customer. Negativo
			}, {
				null, IllegalArgumentException.class
			//Sin loguear
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateCriticMoreCritiquesNegative((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateCriticMoreCritiquesNegative(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.criticService.criticMoreCritiquesNegative();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
}