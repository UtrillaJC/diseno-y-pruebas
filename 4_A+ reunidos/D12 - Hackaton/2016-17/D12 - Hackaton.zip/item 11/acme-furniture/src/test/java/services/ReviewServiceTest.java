
package services;

import javax.validation.ConstraintViolationException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;
import domain.Confidence;
import domain.Maker;
import domain.Review;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class ReviewServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private ReviewService	reviewService;

	@Autowired
	private MakerService	makerService;


	// Tests =======================================================================================

	//Un usuario autenticado como montador puede:
	//Listar las revisiones que ha hecho.

	@Test
	public void driverList() {

		final Object testingData[][] = {
			{
				"assembler1", null
			//POSITIVO Usuario logueado como assembler lista sus revisiones
			}, {
				null, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta listar "sus" revisiones (no tiene)
			}, {
				"customer1", IllegalArgumentException.class
			//NEGATIVO Usuario logueado como customer intenta listar "sus" revisiones (no tiene)
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateList((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateList(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.reviewService.findReviewsByAssembler();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//Un usuario autenticado como montador puede:
	//Hacer una revisi�n a un fabricante.

	@Test
	public void driverCreate() {

		final Object testingData[][] = {
			{
				"assembler1", 2083, Confidence.normal, "comentario", null
			//POSITIVO Usuario logueado como assembler crea una revision
			}, {
				null, 2084, Confidence.normal, "comentario", IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta crear una revision
			}, {
				"assembler2", 2085, Confidence.normal, "", ConstraintViolationException.class
			//NEGATIVO Usuario logueado como assembler crea una revision con el comentario en blanco
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateCreate((String) testingData[i][0], (int) testingData[i][1], (Confidence) testingData[i][2], (String) testingData[i][3], (Class<?>) testingData[i][4]);
	}

	public void templateCreate(final String username, final int makerId, final Confidence confidence, final String comment, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final Maker maker = this.makerService.findOne(makerId);
			final Review review = this.reviewService.create(maker);
			review.setConfidence(confidence);
			review.setComment(comment);
			this.reviewService.save(review);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

}
