
package services;

import java.net.MalformedURLException;
import java.util.Date;

import javax.validation.ConstraintViolationException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import domain.Actor;
import domain.Message;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class MessageServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private ActorService actorService;
	
	@Autowired
	private MessageService messageService;


	// Tests =======================================================================================

	// A user who is authenticated:
	//send message to another actor
	
	@Test
	public void driverMessage() throws MalformedURLException {

		Actor recipient, recipient2;
		recipient = this.actorService.findOne(1961);
		recipient2 = this.actorService.findOne(1999);
		Date moment = new Date(1/1/2017);
		Date moment2 = new Date(2019/10/10);
		
		final Object testingData[][] = {
			{
				"customer1", "asunto", "texto del mensaje", recipient, moment, null
			//POSITIVO Usuario logueado como customer1 env�a un mensaje a customer2
			},{
				null, "asunto", "texto del mensaje", recipient, moment, IllegalArgumentException.class
			//NEGATIVO1 Usuario no logueado
			},{
				"customer1", "asunto", "texto del mensaje", null, moment, IllegalArgumentException.class
			//NEGATIVO2 sender null
			},{
				"customer1", "asunto", null, recipient, moment, NullPointerException.class
			//NEGATIVO3 body null
			},{
				"customer1", null,  "texto del mensaje", recipient, moment, NullPointerException.class
			//NEGATIVO4 subject null
			},{
				"customer2",  "asunto",  "texto del mensaje", recipient, moment, IllegalArgumentException.class
			//NEGATIVO5 sender = recipient
			},{
				"customer1",  "asunto",  "texto del mensaje", recipient2, moment, IllegalArgumentException.class
			//NEGATIVO6 recipient inexistente
			},{
				"customer29",  "asunto",  "texto del mensaje", recipient, moment, IllegalArgumentException.class
			//NEGATIVO7 sender inexistente
			},{
				"customer1",  "asunto",  "texto del mensaje", recipient, moment2, null
			//NEGATIVO8 moment no v�lido
			},{
				"customer1",  "asunto",  "texto del mensaje", recipient, null, ConstraintViolationException.class
			//NEGATIVO9 moment null
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.templateMessage((String) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (Actor) testingData[i][3], (Date) testingData[i][4], (Class<?>) testingData[i][5]);
	}
	public void templateMessage(final String username,final String subject, final String body, Actor recipient, Date moment, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		
		try {
			this.authenticate(username);
			Actor sender = actorService.findByPrincipal();
			final Message message = this.messageService.create(sender);
			message.setSubject(subject);
			message.setBody(body);
			message.setRecipient(recipient);
			this.messageService.save(message);

			message.setMoment(null);
			message.setMoment(moment);
			messageService.update(message);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	// A user who is authenticated :
	// Delete a message

	@Test
	public void driverDeleteMessage() {

		final Object testingData[][] = {
			{
				"customer1", null
			//POSITIVO Usuario logueado borra un mensaje suyo correctamente.
			}, {
				"customer2", IllegalArgumentException.class
			//NEGATIVO Usuario logueado borra mensaje que no ha enviado ni recibido, es decir, que no es suyo.
			}, {
				null, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta borrar mensaje.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateDeleteMessage((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateDeleteMessage(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			Message message;
			message = this.messageService.findOne(2055);
			this.messageService.delete(message);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}


}
