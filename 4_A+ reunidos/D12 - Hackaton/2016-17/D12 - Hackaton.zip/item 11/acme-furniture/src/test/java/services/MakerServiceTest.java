
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import domain.Maker;

import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class MakerServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private MakerService	makerService;


	// Tests =======================================================================================

	//An actor who is authenticated as a administrator must be able to:
	//Create a maker

	@Test
	public void driverCreateMaker() {

		final Object testingData[][] = {
			{
				"admin", null
			//POSITIVO Administrador logueado crea un fabricante suyo correctamente.
			}, {
				"customer1", IllegalArgumentException.class
			//NEGATIVO Usuario logueado crea un fabricante cuando no esta permitido hacerlo.
			}, {
				null, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado crea un fabricante que no es suyo.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateCreateMaker((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateCreateMaker(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.makerService.create();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	
	//An actor who is authenticated as a administrator must be able to:
	//Modify a maker

	@Test
	public void driverModifyMaker() {

		final Object testingData[][] = {
			{
				"admin", "Nuevo nombre", null
			//POSITIVO Administrator logueado borra un fabricante correctamente.
			}, {
				"customer1", "Nuevo nombre",IllegalArgumentException.class
			//NEGATIVO Usuario logueado borra un fabricante que no es suyo.
			}, {
				null, "Nuevo nombre",IllegalArgumentException.class
			//NEGATIVO Usuario no logueado borra un fabricante que no es suyo.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateModifyMaker((String) testingData[i][0], (String) testingData[i][1],(Class<?>) testingData[i][2]);
	}

	public void templateModifyMaker(final String username, final String name, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			Maker maker;
			maker = this.makerService.findOne(2083);
			maker.setName(name);
			
			this.makerService.save(maker);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	
	
	
	


	

}
