
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;
import domain.Furniture;
import domain.Incidence;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class IncidenceServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private IncidenceService	incidenceService;

	@Autowired
	private FurnitureService	furnitureService;


	// Tests =======================================================================================

	@Test
	public void driverCreateIncidence() {

		final Object testingData[][] = {
			{
				"customer1", "Cause", null
			//POSITIVO Customer logueado crea un Incidence
			}, {
				"admin", "Cause", IllegalArgumentException.class
			//NEGATIVO Usuario logueado crea un Incidence, lo cual no puede hacer.
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.templateCreateIncidence((String) testingData[i][0], (String) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateCreateIncidence(final String username, final String cause, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final Incidence incidence;
			final Furniture furniture = this.furnitureService.findOne(2089);
			incidence = this.incidenceService.create(furniture);
			incidence.setCause(cause);

			this.incidenceService.save(incidence);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

}
