
package services;

import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Budget;
import domain.Customer;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class BudgetServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private BudgetService	budgetService;
	
	@Autowired
	private CustomerService	customerService;

	


	// Tests =======================================================================================

	//An actor who is authenticated as a Customer must be able to:
	//Crear un presupuesto a partir de muebles y sus piezas.

	@Test
	public void driverCreateBudgetByCustomer() {

		final Object testingData[][] = {
			{
				"customer1", "mibudget" , null
			//POSITIVO Customer logueado crea presupuesto correctamente.
			},{
				"admin", "mibudget", IllegalArgumentException.class
			//NEGATIVO Administrator logueado no puede crear presupuesto.
			}, {
				null, "mibudget" ,IllegalArgumentException.class
			//NEGATIVO Usuario no logueado no puede crear presupuesto.
			},{
				"customer1", null , IllegalArgumentException.class
			//Negativo Customer logueado crea presupuesto sin nombre.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateCreateBudgetByCustomer((String) testingData[i][0],(String) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateCreateBudgetByCustomer(final String username,String name, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			Budget bg = this.budgetService.create(name);
			Assert.notNull(bg);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	
	
	@Test
	public void driverAddFurniture() {

		final Object testingData[][] = {
			{
				"customer1", "customer1" , 2089, null
			//POSITIVO Customer logueado crea presupuesto correctamente.
			},
			{
				"customer1", "customer2" , 2089, IllegalArgumentException.class
			//Negativo Customer logueado crea presupuesto correctamente.
			},
			{
				"admin", "admin" , 2089, IllegalArgumentException.class
			//Negativo Customer logueado crea presupuesto correctamente.
			},
			{
				"customer1", "customer1" , 0, IllegalArgumentException.class
			//Negativo Customer logueado crea presupuesto correctamente.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateAddFurnitureToBudget((String) testingData[i][0],(String) testingData[i][1],(int) testingData[i][2], (Class<?>) testingData[i][3]);
	}

	public void templateAddFurnitureToBudget(final String username,final String username2,int furnitureId, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			Customer c = customerService.findByPrincipal();
			Budget b = c.getBudgets().iterator().next();
			this.unauthenticate();
			this.authenticate(username2);
			this.budgetService.add(b, furnitureId, 2);
			
			this.unauthenticate();
			
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	
	
	@Test
	public void driverListBudget() {

		final Object testingData[][] = {
			{
				"customer1",  null
			//POSITIVO Customer logueado crea presupuesto correctamente.
			},
			
			{"admin", IllegalArgumentException.class
			//Negativo Customer logueado crea presupuesto correctamente.
			},
			{
				null, IllegalArgumentException.class
			//Negativo Customer logueado crea presupuesto correctamente.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateListBudget((String) testingData[i][0],(Class<?>) testingData[i][1]);
	}

	public void templateListBudget(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			Collection<Budget> bgs = budgetService.findByPrincipal();
			Assert.notNull(bgs);
			this.unauthenticate();
			
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	
	
	

	
	

}
