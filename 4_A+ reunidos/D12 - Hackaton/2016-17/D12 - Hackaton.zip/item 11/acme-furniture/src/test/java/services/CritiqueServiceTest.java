
package services;

import javax.validation.ConstraintViolationException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;
import domain.Critique;
import domain.Type;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class CritiqueServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private CritiqueService	critiqueService;


	// Tests =======================================================================================

	//Un usuario autenticado como cliente puede:
	//Listar las cr�ticas realizadas a un mueble.

	@Test
	public void driverListByFurniture() {

		final Object testingData[][] = {
			{
				"customer1", 2089, null
			//POSITIVO Usuario logueado como customer lista las cr�ticas del mueble con id 
			}, {
				null, 2089, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta listar las cr�ticas de un mueble
			}, {
				"customer1", 1, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como customer intenta listar las cr�ticas de un mueble que no existe
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateListByFurniture((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateListByFurniture(final String username, final int furnitureId, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.critiqueService.findByFurnitureId(furnitureId);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	//Un usuario autenticado como cr�tico puede:
	//Listar las cr�ticas que ha creado.

	@Test
	public void driverListMine() {

		final Object testingData[][] = {
			{
				"critic1", null
			//POSITIVO Usuario logueado como cr�tico lista las cr�ticas que ha creado
			}, {
				null, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta listar las cr�ticas
			}, {
				"customer1", IllegalArgumentException.class
			//NEGATIVO Usuario logueado como customer intenta listar las cr�ticas que "ha creado"
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateListMine((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateListMine(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.critiqueService.findCritiquesByCritic();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	
	//Un usuario autenticado como cr�tico puede:
	//Crear cr�ticas a un mueble.

	@Test
	public void driverCreate() {

		final Object testingData[][] = {
			{
				"critic1", "titulo", "texto", Type.POSITIVE, 2089, null
			//POSITIVO Usuario logueado como cr�tico crea una cr�tica al mueble con id 
			}, {
				null, "titulo", "texto", Type.NEGATIVE, 2089, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta crear una cr�tica
			}, {
				"customer1", "titulo", "texto", Type.NEUTRAL, 2089, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como customer intenta crear una cr�tica
			}, {
				"critic1", "titulo", "", Type.NEGATIVE, 2089, ConstraintViolationException.class
			//NEGATIVO Usuario logueado como cr�tico intenta crear una cr�tica con texto en blanco
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateCreate((String) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (Type) testingData[i][3], (int) testingData[i][4], (Class<?>) testingData[i][5]);
	}

	public void templateCreate(final String username, final String title, final String text, final Type type, final int furnitureId, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final Critique critique = this.critiqueService.create(furnitureId);
			critique.setTitle(title);
			critique.setText(text);
			critique.setType(type);
			this.critiqueService.save(critique);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	

	//Un usuario autenticado como cr�tico puede:
	//Editar una cr�tica que haya creado.

	@Test
	public void driverEdit() {

		final Object testingData[][] = {
			{
				"critic1", 2090, "titulo", "texto", Type.POSITIVE, null
			//POSITIVO Usuario logueado como cr�tico edita una critica suya
			}, {
				"customer1", 2090, "titulo", "texto", Type.NEUTRAL, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como customer intenta editar una cr�tica
			}, {
				"critic1", 2090, "titulo", "", Type.NEGATIVE, ConstraintViolationException.class
			//NEGATIVO Usuario logueado como cr�tico intenta editar una cr�tica con texto en blanco
			}, {
				"critic2", 2090, "titulo", "texto", Type.NEGATIVE, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como cr�tico intenta editar una critica que no es suya
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateEdit((String) testingData[i][0], (int) testingData[i][1], (String) testingData[i][2], (String) testingData[i][3], (Type) testingData[i][4], (Class<?>) testingData[i][5]);
	}

	public void templateEdit(final String username, final int critiqueId, final String title, final String text, final Type type, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final Critique critique = this.critiqueService.findOne(critiqueId);
			critique.setTitle(title);
			critique.setText(text);
			critique.setType(type);
			this.critiqueService.update(critique);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	//Un usuario autenticado como cr�tico puede:
	//Borrar una cr�tica que haya creado.

	@Test
	public void driverDelete() {

		final Object testingData[][] = {
			{
				"critic1", 2090, null
			//POSITIVO Usuario logueado como cr�tico borra una critica suya
			}, {
				"customer1", 2090, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como customer intenta borrar una cr�tica
			}, {
				"critic2", 2090, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como cr�tico intenta borrar una critica que no es suya
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateDelete((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateDelete(final String username, final int critiqueId, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final Critique critique = this.critiqueService.findOne(critiqueId);
			this.critiqueService.delete(critique);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	


	//Un usuario autenticado como cr�tico puede:
	//Votar una critica que no haya creado como justa.

	@Test
	public void driverFair() {

		final Object testingData[][] = {
			{
				"critic1", 2101, null
			//POSITIVO Usuario logueado como cr�tico vota una critica no suya como justa
			}, {
				"customer1", 2101, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como customer intenta votar una cr�tica
			}, {
				null, 2091, IllegalArgumentException.class
			//NEGATIVO Usuario no autenticado intenta votar como justa una critica no suya
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateFair((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateFair(final String username, final int critiqueId, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final Critique critique = this.critiqueService.findOne(critiqueId);
			this.critiqueService.fair(critique);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	
	//Un usuario autenticado como cr�tico puede:
	//Votar una critica que no haya creado como injusta.

	@Test
	public void driverUnfair() {

		final Object testingData[][] = {
			{
				"critic1", 2101, null
			//POSITIVO Usuario logueado como cr�tico vota una critica no suya como injusta
			}, {
				"customer1", 2101, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como customer intenta votar una cr�tica
			}, {
				null, 2091, IllegalArgumentException.class
			//NEGATIVO Usuario no autenticado intenta votar como injusta una critica no suya
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateUnfair((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateUnfair(final String username, final int critiqueId, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final Critique critique = this.critiqueService.findOne(critiqueId);
			this.critiqueService.unfair(critique);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	


	//Un usuario autenticado como administrador puede:
	//Banear una critica.

	@Test
	public void driverBan() {

		final Object testingData[][] = {
			{
				"admin", 2090, null
			//POSITIVO Usuario logueado como administrador banea una critica
			}, {
				"customer1", 2090, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como customer intenta banear una cr�tica
			}, {
				"admin", 2091, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como admin intenta banear una critica ya baneada
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateBan((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateBan(final String username, final int critiqueId, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final Critique critique = this.critiqueService.findOne(critiqueId);
			this.critiqueService.ban(critique);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	

	//Un usuario autenticado como administrador puede:
	//Desbanear una critica.

	@Test
	public void driverUnban() {

		final Object testingData[][] = {
			{
				"admin", 2091, null
			//POSITIVO Usuario logueado como administrador desbanea una critica
			}, {
				"customer1", 2091, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como customer intenta desbanear una cr�tica
			}, {
				"admin", 2090, IllegalArgumentException.class
			//NEGATIVO Usuario logueado como admin intenta desbanear una critica no baneada
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateUnban((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateUnban(final String username, final int critiqueId, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final Critique critique = this.critiqueService.findOne(critiqueId);
			this.critiqueService.unban(critique);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}	
	
	
	
}