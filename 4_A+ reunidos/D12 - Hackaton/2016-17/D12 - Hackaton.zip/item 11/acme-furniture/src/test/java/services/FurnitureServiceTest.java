
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import utilities.AbstractTest;
import domain.Assembly;
import domain.Furniture;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class FurnitureServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private FurnitureService	furnitureService;

	@Autowired
	private AssemblyService		assemblyService;


	// Tests =======================================================================================

	//Un usuario autenticado como montador puede:
	//Listar los muebles que hay por montar.

	@Test
	public void driverListNotAssembled() {

		final Object testingData[][] = {
			{
				"assembler1", null
			//POSITIVO Usuario logueado como assembler lista los muebles que hay por montar
			}, {
				null, IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta listar los muebles por montar
			}, {
				"customer1", IllegalArgumentException.class
			//NEGATIVO Usuario logueado como customer intenta listar los muebles por montar
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateListNotAssembled((String) testingData[i][0], (Class<?>) testingData[i][1]);
	}

	public void templateListNotAssembled(final String username, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			this.furnitureService.findNotAssembled();
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

	//Un usuario autenticado como montador puede:
	//Marcar un mueble como montado.

	@Test
	public void driverAssemble() {

		final Object testingData[][] = {
			{
				"assembler1", 2089, 50., null
			//POSITIVO Usuario logueado como assembler monta un mueble
			}, {
				null, 2063, 50., IllegalArgumentException.class
			//NEGATIVO Usuario no logueado intenta montar un mueble
			}, {
				"customer1", 2089, 50., IllegalArgumentException.class
			//NEGATIVO Usuario logueado como customer intenta montar un mueble
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateAssemble((String) testingData[i][0], (int) testingData[i][1], (double) testingData[i][2], (Class<?>) testingData[i][3]);
	}

	public void templateAssemble(final String username, final int furnitureId, final double price, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			final Furniture furniture = this.furnitureService.findOne(furnitureId);
			final Assembly assembly = this.assemblyService.create(furniture);
			assembly.setPrice(price);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}

}
