
package services;

import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import domain.Budget;
import domain.BudgetLine;
import domain.Customer;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class BudgetLineServiceTest extends AbstractTest {

	// The SUT ====================================================================================

	@Autowired
	private BudgetService	budgetService;
	
	@Autowired
	private BudgetLineService	budgetLineService;

	@Autowired
	private CustomerService	customerService;


	// Tests =======================================================================================

	//An actor who is authenticated as a Customer must be able to:
	//Crear un presupuesto a partir de muebles y sus piezas.

	@Test
	public void driverChangePiece() {

		final Object testingData[][] = {
				{
					"customer1", "comment" , null
				//POSITIVO Customer logueado crea presupuesto correctamente.
				},{
					"admin", "comment", IllegalArgumentException.class
				//NEGATIVO Administrator logueado no puede crear presupuesto.
				}, {
					null, "comment" ,IllegalArgumentException.class
				//NEGATIVO Usuario no logueado no puede crear presupuesto.
				}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateChangePiece((String) testingData[i][0],(String) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateChangePiece(final String username,String comment, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate("customer1");
			Customer c = customerService.findByPrincipal();
			Budget b = c.getBudgets().iterator().next();
			this.unauthenticate();
			this.authenticate(username);
			Collection<BudgetLine> bls = budgetService.add(b, 2102, 2);
			BudgetLine bl = bls.iterator().next();
			budgetLineService.comment(bl.getId(), comment);
			
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	@Test
	public void driverAcceptChange() {

		final Object testingData[][] = {
			{
				"admin", 2069 , null
			//POSITIVO Customer logueado crea presupuesto correctamente.
			},{
				"customer1", 2069 , IllegalArgumentException.class
			//Negativo Customer logueado crea presupuesto correctamente.
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.templateAcceptChange((String) testingData[i][0],(int) testingData[i][1], (Class<?>) testingData[i][2]);
	}

	public void templateAcceptChange(final String username,int id, final Class<?> expected) {
		Class<?> caught;

		caught = null;

		try {
			this.authenticate(username);
			budgetLineService.accept(id);
			
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		this.checkExceptions(expected, caught);
	}
	
	

}
