
package domain;

public enum Priority {
	HIGH, NEUTRAL, LOW
}
