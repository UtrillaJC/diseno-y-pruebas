package domain;


public class Record {

}
