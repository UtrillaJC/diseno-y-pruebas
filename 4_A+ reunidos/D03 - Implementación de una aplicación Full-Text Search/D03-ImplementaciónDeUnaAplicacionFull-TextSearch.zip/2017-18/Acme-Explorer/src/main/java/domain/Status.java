
package domain;

public enum Status {
	PENDING, REJECTED, DUE, ACCEPTED, CANCELLED
}
